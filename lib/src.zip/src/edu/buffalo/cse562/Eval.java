/*   1:    */ package edu.buffalo.cse562;
/*   2:    */ 
/*   3:    */ import java.sql.SQLException;
/*   4:    */ import java.util.Iterator;
/*   5:    */ import java.util.List;
/*   6:    */ import java.util.regex.Pattern;
/*   7:    */ import net.sf.jsqlparser.expression.AllComparisonExpression;
/*   8:    */ import net.sf.jsqlparser.expression.AnyComparisonExpression;
/*   9:    */ import net.sf.jsqlparser.expression.BinaryExpression;
/*  10:    */ import net.sf.jsqlparser.expression.BooleanValue;
/*  11:    */ import net.sf.jsqlparser.expression.CaseExpression;
/*  12:    */ import net.sf.jsqlparser.expression.DateValue;
/*  13:    */ import net.sf.jsqlparser.expression.DoubleValue;
/*  14:    */ import net.sf.jsqlparser.expression.Expression;
/*  15:    */ import net.sf.jsqlparser.expression.Function;
/*  16:    */ import net.sf.jsqlparser.expression.InverseExpression;
/*  17:    */ import net.sf.jsqlparser.expression.JdbcParameter;
/*  18:    */ import net.sf.jsqlparser.expression.LeafValue;
/*  19:    */ import net.sf.jsqlparser.expression.LeafValue.InvalidLeaf;
/*  20:    */ import net.sf.jsqlparser.expression.LongValue;
/*  21:    */ import net.sf.jsqlparser.expression.NullValue;
/*  22:    */ import net.sf.jsqlparser.expression.Parenthesis;
/*  23:    */ import net.sf.jsqlparser.expression.StringValue;
/*  24:    */ import net.sf.jsqlparser.expression.TimeValue;
/*  25:    */ import net.sf.jsqlparser.expression.TimestampValue;
/*  26:    */ import net.sf.jsqlparser.expression.WhenClause;
/*  27:    */ import net.sf.jsqlparser.expression.operators.arithmetic.Addition;
/*  28:    */ import net.sf.jsqlparser.expression.operators.arithmetic.BitwiseAnd;
/*  29:    */ import net.sf.jsqlparser.expression.operators.arithmetic.BitwiseOr;
/*  30:    */ import net.sf.jsqlparser.expression.operators.arithmetic.BitwiseXor;
/*  31:    */ import net.sf.jsqlparser.expression.operators.arithmetic.Concat;
/*  32:    */ import net.sf.jsqlparser.expression.operators.arithmetic.Division;
/*  33:    */ import net.sf.jsqlparser.expression.operators.arithmetic.Multiplication;
/*  34:    */ import net.sf.jsqlparser.expression.operators.arithmetic.Subtraction;
/*  35:    */ import net.sf.jsqlparser.expression.operators.conditional.AndExpression;
/*  36:    */ import net.sf.jsqlparser.expression.operators.conditional.OrExpression;
/*  37:    */ import net.sf.jsqlparser.expression.operators.relational.Between;
/*  38:    */ import net.sf.jsqlparser.expression.operators.relational.EqualsTo;
/*  39:    */ import net.sf.jsqlparser.expression.operators.relational.ExistsExpression;
/*  40:    */ import net.sf.jsqlparser.expression.operators.relational.ExpressionList;
/*  41:    */ import net.sf.jsqlparser.expression.operators.relational.GreaterThan;
/*  42:    */ import net.sf.jsqlparser.expression.operators.relational.GreaterThanEquals;
/*  43:    */ import net.sf.jsqlparser.expression.operators.relational.InExpression;
/*  44:    */ import net.sf.jsqlparser.expression.operators.relational.IsNullExpression;
/*  45:    */ import net.sf.jsqlparser.expression.operators.relational.LikeExpression;
/*  46:    */ import net.sf.jsqlparser.expression.operators.relational.Matches;
/*  47:    */ import net.sf.jsqlparser.expression.operators.relational.MinorThan;
/*  48:    */ import net.sf.jsqlparser.expression.operators.relational.MinorThanEquals;
/*  49:    */ import net.sf.jsqlparser.expression.operators.relational.NotEqualsTo;
/*  50:    */ import net.sf.jsqlparser.schema.Column;
/*  51:    */ 






























































/*  52:    */ public abstract class Eval
/*  53:    */ {
/*  54:    */   static enum Type
/*  55:    */   {
/*  56: 32 */     LONG,  DOUBLE,  STRING,  BOOL,  DATE,  TIMESTAMP,  TIME;
/*  57:    */     
/*  58:    */     private Type() {}
/*  59:    */   }
/*  60:    */   
/*  61:    */   public Type assertNumeric(Type found)
/*  62:    */     throws SQLException
/*  63:    */   {
/*  64: 38 */     if ((found != Type.LONG) && (found != Type.DOUBLE)) {
/*  65: 39 */       throw new SQLException("Typecheck Error: Found " + found + ", but expected a number");
/*  66:    */     }
/*  67: 42 */     return found;
/*  68:    */   }
/*  69:    */   
/*  70:    */   public Type escalateNumeric(Type lhs, Type rhs)
/*  71:    */     throws SQLException
/*  72:    */   {
/*  73: 48 */     if ((lhs == Type.DATE) && 
/*  74: 49 */       (rhs == Type.DATE)) {
/*  75: 49 */       return Type.DATE;
/*  76:    */     }
/*  77: 51 */     if ((assertNumeric(lhs) == Type.DOUBLE) || 
/*  78: 52 */       (assertNumeric(rhs) == Type.DOUBLE)) {
/*  79: 53 */       return Type.DOUBLE;
/*  80:    */     }
/*  81: 55 */     return Type.LONG;
/*  82:    */   }
/*  83:    */   
/*  84:    */   public LeafValue missing(String element)
/*  85:    */     throws SQLException
/*  86:    */   {
/*  87: 62 */     throw new SQLException("Incomplete expression support (" + element + ")");
/*  88:    */   }
/*  89:    */   
/*  90:    */   public LeafValue eval(Expression e)
/*  91:    */     throws SQLException
/*  92:    */   {
/*  93: 77 */     if ((e instanceof Addition)) {
/*  94: 77 */       return eval((Addition)e);
/*  95:    */     }
/*  96: 78 */     if ((e instanceof Division)) {
/*  97: 78 */       return eval((Division)e);
/*  98:    */     }
/*  99: 79 */     if ((e instanceof Multiplication)) {
/* 100: 79 */       return eval((Multiplication)e);
/* 101:    */     }
/* 102: 80 */     if ((e instanceof Subtraction)) {
/* 103: 80 */       return eval((Subtraction)e);
/* 104:    */     }
/* 105: 81 */     if ((e instanceof AndExpression)) {
/* 106: 81 */       return eval((AndExpression)e);
/* 107:    */     }
/* 108: 82 */     if ((e instanceof OrExpression)) {
/* 109: 82 */       return eval((OrExpression)e);
/* 110:    */     }
/* 111: 83 */     if ((e instanceof EqualsTo)) {
/* 112: 83 */       return eval((EqualsTo)e);
/* 113:    */     }
/* 114: 84 */     if ((e instanceof NotEqualsTo)) {
/* 115: 84 */       return eval((NotEqualsTo)e);
/* 116:    */     }
/* 117: 85 */     if ((e instanceof GreaterThan)) {
/* 118: 85 */       return eval((GreaterThan)e);
/* 119:    */     }
/* 120: 86 */     if ((e instanceof GreaterThanEquals)) {
/* 121: 86 */       return eval((GreaterThanEquals)e);
/* 122:    */     }
/* 123: 87 */     if ((e instanceof MinorThan)) {
/* 124: 87 */       return eval((MinorThan)e);
/* 125:    */     }
/* 126: 88 */     if ((e instanceof MinorThanEquals)) {
/* 127: 88 */       return eval((MinorThanEquals)e);
/* 128:    */     }
/* 129: 89 */     if ((e instanceof DateValue)) {
/* 130: 89 */       return eval((DateValue)e);
/* 131:    */     }
/* 132: 90 */     if ((e instanceof DoubleValue)) {
/* 133: 90 */       return eval((DoubleValue)e);
/* 134:    */     }
/* 135: 91 */     if ((e instanceof LongValue)) {
/* 136: 91 */       return eval((LongValue)e);
/* 137:    */     }
/* 138: 92 */     if ((e instanceof StringValue)) {
/* 139: 92 */       return eval((StringValue)e);
/* 140:    */     }
/* 141: 93 */     if ((e instanceof TimestampValue)) {
/* 142: 93 */       return eval((TimestampValue)e);
/* 143:    */     }
/* 144: 94 */     if ((e instanceof TimeValue)) {
/* 145: 94 */       return eval((TimeValue)e);
/* 146:    */     }
/* 147: 95 */     if ((e instanceof CaseExpression)) {
/* 148: 95 */       return eval((CaseExpression)e);
/* 149:    */     }
/* 150: 96 */     if ((e instanceof Parenthesis)) {
/* 151: 96 */       return eval((Parenthesis)e);
/* 152:    */     }
/* 153: 97 */     if ((e instanceof Column)) {
/* 154: 97 */       return eval((Column)e);
/* 155:    */     }
/* 156: 98 */     if ((e instanceof WhenClause)) {
/* 157: 98 */       return eval((WhenClause)e);
/* 158:    */     }
/* 159: 99 */     if ((e instanceof AllComparisonExpression)) {
/* 160: 99 */       return eval((AllComparisonExpression)e);
/* 161:    */     }
/* 162:100 */     if ((e instanceof AnyComparisonExpression)) {
/* 163:100 */       return eval((AnyComparisonExpression)e);
/* 164:    */     }
/* 165:101 */     if ((e instanceof Between)) {
/* 166:101 */       return eval((Between)e);
/* 167:    */     }
/* 168:102 */     if ((e instanceof ExistsExpression)) {
/* 169:102 */       return eval((ExistsExpression)e);
/* 170:    */     }
/* 171:103 */     if ((e instanceof InExpression)) {
/* 172:103 */       return eval((InExpression)e);
/* 173:    */     }
/* 174:104 */     if ((e instanceof LikeExpression)) {
/* 175:104 */       return eval((LikeExpression)e);
/* 176:    */     }
/* 177:105 */     if ((e instanceof Matches)) {
/* 178:105 */       return eval((Matches)e);
/* 179:    */     }
/* 180:106 */     if ((e instanceof BitwiseXor)) {
/* 181:106 */       return eval((BitwiseXor)e);
/* 182:    */     }
/* 183:107 */     if ((e instanceof BitwiseOr)) {
/* 184:107 */       return eval((BitwiseOr)e);
/* 185:    */     }
/* 186:108 */     if ((e instanceof BitwiseAnd)) {
/* 187:108 */       return eval((BitwiseAnd)e);
/* 188:    */     }
/* 189:109 */     if ((e instanceof Concat)) {
/* 190:109 */       return eval((Concat)e);
/* 191:    */     }
/* 192:110 */     if ((e instanceof Function)) {
/* 193:110 */       return eval((Function)e);
/* 194:    */     }
/* 195:111 */     if ((e instanceof InverseExpression)) {
/* 196:111 */       return eval((InverseExpression)e);
/* 197:    */     }
/* 198:112 */     if ((e instanceof IsNullExpression)) {
/* 199:112 */       return eval((IsNullExpression)e);
/* 200:    */     }
/* 201:113 */     if ((e instanceof JdbcParameter)) {
/* 202:113 */       return eval((JdbcParameter)e);
/* 203:    */     }
/* 204:114 */     if ((e instanceof NullValue)) {
/* 205:114 */       return eval((NullValue)e);
/* 206:    */     }
/* 207:115 */     throw new SQLException("Invalid operator: " + e);
/* 208:    */   }
/* 209:    */   
/* 210:    */   public Type getType(LeafValue e)
/* 211:    */     throws SQLException
/* 212:    */   {
/* 213:121 */     if ((e instanceof LongValue)) {
/* 214:121 */       return Type.LONG;
/* 215:    */     }
/* 216:122 */     if ((e instanceof DoubleValue)) {
/* 217:122 */       return Type.DOUBLE;
/* 218:    */     }
/* 219:123 */     if ((e instanceof StringValue)) {
/* 220:123 */       return Type.STRING;
/* 221:    */     }
/* 222:124 */     if ((e instanceof DateValue)) {
/* 223:124 */       return Type.DATE;
/* 224:    */     }
/* 225:125 */     if ((e instanceof TimeValue)) {
/* 226:125 */       return Type.TIME;
/* 227:    */     }
/* 228:126 */     if ((e instanceof TimestampValue)) {
/* 229:126 */       return Type.TIMESTAMP;
/* 230:    */     }
/* 231:127 */     if ((e instanceof BooleanValue)) {
/* 232:127 */       return Type.BOOL;
/* 233:    */     }
/* 234:128 */     return null;
/* 235:    */   }
/* 236:    */   
/* 237:    */   public LeafValue arith(BinaryExpression e, ArithOp op)
/* 238:    */     throws SQLException
/* 239:    */   {
/* 240:    */     try
/* 241:    */     {
/* 242:136 */       LeafValue lhs = eval(e.getLeftExpression());
/* 243:137 */       LeafValue rhs = eval(e.getRightExpression());
/* 244:138 */       if ((lhs == null) || (rhs == null)) {
/* 245:138 */         return null;
/* 246:    */       }
/* 247:140 */       switch (11.$SwitchMap$edu$buffalo$cse562$Eval$Type[escalateNumeric(getType(lhs), getType(rhs)).ordinal()])
/* 248:    */       {
/* 249:    */       case 1: 
/* 250:142 */         return new DoubleValue(op.op(lhs.toDouble(), rhs.toDouble()));
/* 251:    */       case 2: 
/* 252:144 */         return new LongValue(op.op(lhs.toLong(), rhs.toLong()));
/* 253:    */       case 3: 
/* 254:146 */         throw new SQLException("Arithmetic on dates");
/* 255:    */       }
/* 256:    */     }
/* 257:    */     catch (LeafValue.InvalidLeaf ex)
/* 258:    */     {
/* 259:149 */       throw new SQLException("Invalid leaf value", ex);
/* 260:    */     }
/* 261:151 */     throw new SQLException("Invalid type escalation");
/* 262:    */   }
/* 263:    */   
/* 264:    */   public LeafValue cmp(BinaryExpression e, CmpOp op)
/* 265:    */     throws SQLException
/* 266:    */   {
/* 267:    */     try
/* 268:    */     {
/* 269:157 */       LeafValue lhs = eval(e.getLeftExpression());
/* 270:158 */       LeafValue rhs = eval(e.getRightExpression());
/* 271:159 */       if ((lhs == null) || (rhs == null)) {
/* 272:159 */         return null;
/* 273:    */       }
/* 274:    */       boolean ret;
/* 275:    */       boolean ret;
/* 276:    */       boolean ret;
/* 277:162 */       switch (11.$SwitchMap$edu$buffalo$cse562$Eval$Type[escalateNumeric(getType(lhs), getType(rhs)).ordinal()])
/* 278:    */       {
/* 279:    */       case 1: 
/* 280:164 */         ret = op.op(lhs.toDouble(), rhs.toDouble());
/* 281:165 */         break;
/* 282:    */       case 2: 
/* 283:167 */         ret = op.op(lhs.toLong(), rhs.toLong());
/* 284:168 */         break;
/* 285:    */       case 3: 
/* 286:170 */         ret = op.op(lhs.toLong(), rhs.toLong());
/* 287:171 */         break;
/* 288:    */       default: 
/* 289:173 */         throw new SQLException("Invalid type escalation");
/* 290:    */       }
/* 291:    */       boolean ret;
/* 292:175 */       return ret ? BooleanValue.TRUE : BooleanValue.FALSE;
/* 293:    */     }
/* 294:    */     catch (LeafValue.InvalidLeaf ex)
/* 295:    */     {
/* 296:177 */       throw new SQLException("Invalid leaf value", ex);
/* 297:    */     }
/* 298:    */   }
/* 299:    */   
/* 300:    */   public LeafValue bool(BinaryExpression e, BoolOp op)
/* 301:    */     throws SQLException
/* 302:    */   {
/* 303:183 */     BooleanValue lhs = (BooleanValue)eval(e.getLeftExpression());
/* 304:184 */     BooleanValue rhs = (BooleanValue)eval(e.getRightExpression());
/* 305:185 */     if ((lhs == null) || (rhs == null)) {
/* 306:185 */       return null;
/* 307:    */     }
/* 308:187 */     return op.op(lhs.getValue(), rhs.getValue()) ? BooleanValue.TRUE : BooleanValue.FALSE;
/* 309:    */   }
/* 310:    */   
/* 311:    */   public LeafValue eval(Addition a)
/* 312:    */     throws SQLException
/* 313:    */   {
/* 314:194 */     arith(a, new ArithOp()
/* 315:    */     {
/* 316:    */       public long op(long a, long b)
/* 317:    */       {
/* 318:195 */         return a + b;
/* 319:    */       }
/* 320:    */       
/* 321:    */       public double op(double a, double b)
/* 322:    */       {
/* 323:196 */         return a + b;
/* 324:    */       }
/* 325:    */     });
/* 326:    */   }
/* 327:    */   
/* 328:    */   public LeafValue eval(Division a)
/* 329:    */     throws SQLException
/* 330:    */   {
/* 331:202 */     arith(a, new ArithOp()
/* 332:    */     {
/* 333:    */       public long op(long a, long b)
/* 334:    */       {
/* 335:203 */         return a / b;
/* 336:    */       }
/* 337:    */       
/* 338:    */       public double op(double a, double b)
/* 339:    */       {
/* 340:204 */         return a / b;
/* 341:    */       }
/* 342:    */     });
/* 343:    */   }
/* 344:    */   
/* 345:    */   public LeafValue eval(Multiplication a)
/* 346:    */     throws SQLException
/* 347:    */   {
/* 348:210 */     arith(a, new ArithOp()
/* 349:    */     {
/* 350:    */       public long op(long a, long b)
/* 351:    */       {
/* 352:211 */         return a * b;
/* 353:    */       }
/* 354:    */       
/* 355:    */       public double op(double a, double b)
/* 356:    */       {
/* 357:212 */         return a * b;
/* 358:    */       }
/* 359:    */     });
/* 360:    */   }
/* 361:    */   
/* 362:    */   public LeafValue eval(Subtraction a)
/* 363:    */     throws SQLException
/* 364:    */   {
/* 365:218 */     arith(a, new ArithOp()
/* 366:    */     {
/* 367:    */       public long op(long a, long b)
/* 368:    */       {
/* 369:219 */         return a - b;
/* 370:    */       }
/* 371:    */       
/* 372:    */       public double op(double a, double b)
/* 373:    */       {
/* 374:220 */         return a - b;
/* 375:    */       }
/* 376:    */     });
/* 377:    */   }
/* 378:    */   
/* 379:    */   public LeafValue eval(AndExpression a)
/* 380:    */     throws SQLException
/* 381:    */   {
/* 382:227 */     bool(a, new BoolOp()
/* 383:    */     {
/* 384:    */       public boolean op(boolean a, boolean b)
/* 385:    */       {
/* 386:227 */         return (a) && (b);
/* 387:    */       }
/* 388:    */     });
/* 389:    */   }
/* 390:    */   
/* 391:    */   public LeafValue eval(OrExpression a)
/* 392:    */     throws SQLException
/* 393:    */   {
/* 394:232 */     bool(a, new BoolOp()
/* 395:    */     {
/* 396:    */       public boolean op(boolean a, boolean b)
/* 397:    */       {
/* 398:232 */         return (a) || (b);
/* 399:    */       }
/* 400:    */     });
/* 401:    */   }
/* 402:    */   
/* 403:    */   public LeafValue eval(EqualsTo a)
/* 404:    */     throws SQLException
/* 405:    */   {
/* 406:238 */     LeafValue lhs = eval(a.getLeftExpression());
/* 407:239 */     LeafValue rhs = eval(a.getRightExpression());
/* 408:240 */     if ((lhs == null) || (rhs == null)) {
/* 409:240 */       return null;
/* 410:    */     }
/* 411:241 */     return lhs.equals(rhs) ? BooleanValue.TRUE : BooleanValue.FALSE;
/* 412:    */   }
/* 413:    */   
/* 414:    */   public LeafValue eval(NotEqualsTo a)
/* 415:    */     throws SQLException
/* 416:    */   {
/* 417:246 */     LeafValue lhs = eval(a.getLeftExpression());
/* 418:247 */     LeafValue rhs = eval(a.getRightExpression());
/* 419:248 */     if ((lhs == null) || (rhs == null)) {
/* 420:248 */       return null;
/* 421:    */     }
/* 422:249 */     return lhs.equals(rhs) ? BooleanValue.FALSE : BooleanValue.TRUE;
/* 423:    */   }
/* 424:    */   
/* 425:    */   public LeafValue eval(GreaterThan a)
/* 426:    */     throws SQLException
/* 427:    */   {
/* 428:254 */     cmp(a, new CmpOp()
/* 429:    */     {
/* 430:    */       public boolean op(long a, long b)
/* 431:    */       {
/* 432:255 */         return a > b;
/* 433:    */       }
/* 434:    */       
/* 435:    */       public boolean op(double a, double b)
/* 436:    */       {
/* 437:256 */         return a > b;
/* 438:    */       }
/* 439:    */       
/* 440:    */       public String toString()
/* 441:    */       {
/* 442:257 */         return ">";
/* 443:    */       }
/* 444:    */     });
/* 445:    */   }
/* 446:    */   
/* 447:    */   public LeafValue eval(GreaterThanEquals a)
/* 448:    */     throws SQLException
/* 449:    */   {
/* 450:263 */     cmp(a, new CmpOp()
/* 451:    */     {
/* 452:    */       public boolean op(long a, long b)
/* 453:    */       {
/* 454:264 */         return a >= b;
/* 455:    */       }
/* 456:    */       
/* 457:    */       public boolean op(double a, double b)
/* 458:    */       {
/* 459:265 */         return a >= b;
/* 460:    */       }
/* 461:    */       
/* 462:    */       public String toString()
/* 463:    */       {
/* 464:266 */         return ">=";
/* 465:    */       }
/* 466:    */     });
/* 467:    */   }
/* 468:    */   
/* 469:    */   public LeafValue eval(MinorThan a)
/* 470:    */     throws SQLException
/* 471:    */   {
/* 472:272 */     cmp(a, new CmpOp()
/* 473:    */     {
/* 474:    */       public boolean op(long a, long b)
/* 475:    */       {
/* 476:273 */         return a < b;
/* 477:    */       }
/* 478:    */       
/* 479:    */       public boolean op(double a, double b)
/* 480:    */       {
/* 481:274 */         return a < b;
/* 482:    */       }
/* 483:    */       
/* 484:    */       public String toString()
/* 485:    */       {
/* 486:275 */         return "<";
/* 487:    */       }
/* 488:    */     });
/* 489:    */   }
/* 490:    */   
/* 491:    */   public LeafValue eval(MinorThanEquals a)
/* 492:    */     throws SQLException
/* 493:    */   {
/* 494:281 */     cmp(a, new CmpOp()
/* 495:    */     {
/* 496:    */       public boolean op(long a, long b)
/* 497:    */       {
/* 498:282 */         return a <= b;
/* 499:    */       }
/* 500:    */       
/* 501:    */       public boolean op(double a, double b)
/* 502:    */       {
/* 503:283 */         return a <= b;
/* 504:    */       }
/* 505:    */       
/* 506:    */       public String toString()
/* 507:    */       {
/* 508:284 */         return "<=";
/* 509:    */       }
/* 510:    */     });
/* 511:    */   }
/* 512:    */   
/* 513:    */   public LeafValue eval(DateValue v)
/* 514:    */   {
/* 515:289 */     return v;
/* 516:    */   }
/* 517:    */   
/* 518:    */   public LeafValue eval(DoubleValue v)
/* 519:    */   {
/* 520:292 */     return v;
/* 521:    */   }
/* 522:    */   
/* 523:    */   public LeafValue eval(LongValue v)
/* 524:    */   {
/* 525:295 */     return v;
/* 526:    */   }
/* 527:    */   
/* 528:    */   public LeafValue eval(StringValue v)
/* 529:    */   {
/* 530:298 */     return v;
/* 531:    */   }
/* 532:    */   
/* 533:    */   public LeafValue eval(TimestampValue v)
/* 534:    */   {
/* 535:301 */     return v;
/* 536:    */   }
/* 537:    */   
/* 538:    */   public LeafValue eval(TimeValue v)
/* 539:    */   {
/* 540:304 */     return v;
/* 541:    */   }
/* 542:    */   
/* 543:    */   public LeafValue eval(CaseExpression c)
/* 544:    */     throws SQLException
/* 545:    */   {
/* 546:    */     Iterator localIterator;
/* 547:    */     Object ow;
/* 548:    */     LeafValue sw;
/* 549:310 */     if (c.getSwitchExpression() == null)
/* 550:    */     {
/* 551:311 */       for (localIterator = c.getWhenClauses().iterator(); localIterator.hasNext();)
/* 552:    */       {
/* 553:311 */         ow = localIterator.next();
/* 554:312 */         WhenClause w = (WhenClause)ow;
/* 555:313 */         BooleanValue cmp = (BooleanValue)eval(w.getWhenExpression());
/* 556:314 */         if (cmp.getValue()) {
/* 557:315 */           return eval(w.getThenExpression());
/* 558:    */         }
/* 559:    */       }
/* 560:    */     }
/* 561:    */     else
/* 562:    */     {
/* 563:319 */       sw = eval(c.getSwitchExpression());
/* 564:320 */       for (Object ow : c.getWhenClauses())
/* 565:    */       {
/* 566:321 */         WhenClause w = (WhenClause)ow;
/* 567:322 */         BooleanValue cmp = (BooleanValue)eval(w.getWhenExpression());
/* 568:323 */         if (sw.equals(cmp)) {
/* 569:324 */           return eval(w.getThenExpression());
/* 570:    */         }
/* 571:    */       }
/* 572:    */     }
/* 573:328 */     if (c.getElseExpression() != null) {
/* 574:329 */       return eval(c.getElseExpression());
/* 575:    */     }
/* 576:331 */     throw new SQLException("Unhandled CASE statement");
/* 577:    */   }
/* 578:    */   
/* 579:    */   public LeafValue eval(Parenthesis parenthesis)
/* 580:    */     throws SQLException
/* 581:    */   {
/* 582:334 */     return eval(parenthesis.getExpression());
/* 583:    */   }
/* 584:    */   
/* 585:    */   public abstract LeafValue eval(Column paramColumn)
/* 586:    */     throws SQLException;
/* 587:    */   
/* 588:    */   public LeafValue eval(WhenClause whenClause)
/* 589:    */     throws SQLException
/* 590:    */   {
/* 591:353 */     throw new SQLException("Stand-alone WhenClause");
/* 592:    */   }
/* 593:    */   
/* 594:    */   public LeafValue eval(AllComparisonExpression all)
/* 595:    */     throws SQLException
/* 596:    */   {
/* 597:364 */     return missing("AllComparisonExpression");
/* 598:    */   }
/* 599:    */   
/* 600:    */   public LeafValue eval(AnyComparisonExpression any)
/* 601:    */     throws SQLException
/* 602:    */   {
/* 603:374 */     return missing("AnyComparisonExpression");
/* 604:    */   }
/* 605:    */   
/* 606:    */   public LeafValue eval(ExistsExpression exists)
/* 607:    */     throws SQLException
/* 608:    */   {
/* 609:384 */     return missing("ExistsExpression");
/* 610:    */   }
/* 611:    */   
/* 612:    */   public LeafValue eval(InExpression in)
/* 613:    */     throws SQLException
/* 614:    */   {
/* 615:394 */     return missing("InExpression");
/* 616:    */   }
/* 617:    */   
/* 618:    */   public LeafValue eval(Between between)
/* 619:    */     throws SQLException
/* 620:    */   {
/* 621:396 */     return eval(new AndExpression(new GreaterThanEquals(between
/* 622:    */     
/* 623:398 */       .getLeftExpression(), between
/* 624:399 */       .getBetweenExpressionStart()), new MinorThan(between
/* 625:    */       
/* 626:    */ 
/* 627:402 */       .getLeftExpression(), between
/* 628:403 */       .getBetweenExpressionEnd())));
/* 629:    */   }
/* 630:    */   
/* 631:    */   public LeafValue eval(LikeExpression like)
/* 632:    */     throws SQLException
/* 633:    */   {
/* 634:409 */     String pattern = eval(like.getRightExpression()).toString().replaceAll("%", ".*");
/* 635:410 */     String cmp = eval(like.getLeftExpression()).toString();
/* 636:    */     
/* 637:412 */     return Pattern.matches(pattern, cmp) ? BooleanValue.TRUE : BooleanValue.FALSE;
/* 638:    */   }
/* 639:    */   
/* 640:    */   public LeafValue eval(Matches matches)
/* 641:    */     throws SQLException
/* 642:    */   {
/* 643:415 */     return missing("Matches");
/* 644:    */   }
/* 645:    */   
/* 646:    */   public LeafValue eval(BitwiseXor a)
/* 647:    */     throws SQLException
/* 648:    */   {
/* 649:418 */     return missing("BitwiseXor");
/* 650:    */   }
/* 651:    */   
/* 652:    */   public LeafValue eval(BitwiseOr a)
/* 653:    */     throws SQLException
/* 654:    */   {
/* 655:420 */     return missing("BitwiseOr");
/* 656:    */   }
/* 657:    */   
/* 658:    */   public LeafValue eval(BitwiseAnd a)
/* 659:    */     throws SQLException
/* 660:    */   {
/* 661:422 */     return missing("BitwiseAnd");
/* 662:    */   }
/* 663:    */   
/* 664:    */   public LeafValue eval(Concat a)
/* 665:    */     throws SQLException
/* 666:    */   {
/* 667:425 */     return missing("Concat");
/* 668:    */   }
/* 669:    */   
/* 670:    */   public LeafValue eval(Function function)
/* 671:    */     throws SQLException
/* 672:    */   {
/* 673:429 */     String fn = function.getName().toUpperCase();
/* 674:430 */     if ("DATE".equals(fn))
/* 675:    */     {
/* 676:431 */       List args = function.getParameters().getExpressions();
/* 677:432 */       if (args.size() != 1) {
/* 678:433 */         throw new SQLException("DATE() takes exactly one argument");
/* 679:    */       }
/* 680:435 */       return new DateValue(eval((Expression)args.get(0)).toString());
/* 681:    */     }
/* 682:438 */     return missing("Function:" + fn);
/* 683:    */   }
/* 684:    */   
/* 685:    */   public LeafValue eval(InverseExpression inverse)
/* 686:    */     throws SQLException
/* 687:    */   {
/* 688:441 */     return missing("InverseExpression");
/* 689:    */   }
/* 690:    */   
/* 691:    */   public LeafValue eval(IsNullExpression isNull)
/* 692:    */     throws SQLException
/* 693:    */   {
/* 694:443 */     return missing("IsNull");
/* 695:    */   }
/* 696:    */   
/* 697:    */   public LeafValue eval(JdbcParameter jdbcParameter)
/* 698:    */     throws SQLException
/* 699:    */   {
/* 700:445 */     return missing("JdbcParameter");
/* 701:    */   }
/* 702:    */   
/* 703:    */   public LeafValue eval(NullValue nullValue)
/* 704:    */     throws SQLException
/* 705:    */   {
/* 706:447 */     return missing("NullValue");
/* 707:    */   }
/* 708:    */   
/* 709:    */   public static abstract class ArithOp
/* 710:    */   {
/* 711:    */     public abstract long op(long paramLong1, long paramLong2);
/* 712:    */     
/* 713:    */     public abstract double op(double paramDouble1, double paramDouble2);
/* 714:    */   }
/* 715:    */   
/* 716:    */   public static abstract class CmpOp
/* 717:    */   {
/* 718:    */     public abstract boolean op(long paramLong1, long paramLong2);
/* 719:    */     
/* 720:    */     public abstract boolean op(double paramDouble1, double paramDouble2);
/* 721:    */   }
/* 722:    */   
/* 723:    */   public static abstract class BoolOp
/* 724:    */   {
/* 725:    */     public abstract boolean op(boolean paramBoolean1, boolean paramBoolean2);
/* 726:    */   }
/* 727:    */   
/* 728:    */   public static class ScopeException
/* 729:    */     extends SQLException
/* 730:    */   {
/* 731:    */     public ScopeException(String msg)
/* 732:    */     {
/* 733:462 */       super();
/* 734:    */     }
/* 735:    */   }
/* 736:    */ }


/* Location:           E:\workspace\java\db\lib\expression.jar
 * Qualified Name:     edu.buffalo.cse562.Eval
 * JD-Core Version:    0.7.0.1
 */