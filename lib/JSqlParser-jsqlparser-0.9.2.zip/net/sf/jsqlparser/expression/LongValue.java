/*  1:   */ package net.sf.jsqlparser.expression;
/*  2:   */ 
/*  3:   */ public class LongValue
/*  4:   */   implements Expression, LeafValue
/*  5:   */ {
/*  6:   */   private long value;
/*  7:   */   private String stringValue;
/*  8:   */   
/*  9:   */   public LongValue(long value)
/* 10:   */   {
/* 11:32 */     this.value = value;
/* 12:   */   }
/* 13:   */   
/* 14:   */   public LongValue(String value)
/* 15:   */   {
/* 16:35 */     if (value.charAt(0) == '+') {
/* 17:36 */       value = value.substring(1);
/* 18:   */     }
/* 19:38 */     this.value = Long.parseLong(value);
/* 20:39 */     setStringValue(value);
/* 21:   */   }
/* 22:   */   
/* 23:   */   public void accept(ExpressionVisitor expressionVisitor)
/* 24:   */   {
/* 25:43 */     expressionVisitor.visit(this);
/* 26:   */   }
/* 27:   */   
/* 28:   */   public long getValue()
/* 29:   */   {
/* 30:47 */     return this.value;
/* 31:   */   }
/* 32:   */   
/* 33:   */   public void setValue(long d)
/* 34:   */   {
/* 35:51 */     this.value = d;
/* 36:   */   }
/* 37:   */   
/* 38:   */   public String getStringValue()
/* 39:   */   {
/* 40:55 */     return this.stringValue;
/* 41:   */   }
/* 42:   */   
/* 43:   */   public void setStringValue(String string)
/* 44:   */   {
/* 45:59 */     this.stringValue = string;
/* 46:   */   }
/* 47:   */   
/* 48:   */   public String toString()
/* 49:   */   {
/* 50:63 */     return getStringValue();
/* 51:   */   }
/* 52:   */   
/* 53:   */   public long toLong()
/* 54:   */   {
/* 55:66 */     return getValue();
/* 56:   */   }
/* 57:   */   
/* 58:   */   public double toDouble()
/* 59:   */   {
/* 60:67 */     return getValue();
/* 61:   */   }
/* 62:   */ }


/* Location:           E:\workspace\java\db\lib\jsqlparser.jar
 * Qualified Name:     net.sf.jsqlparser.expression.LongValue
 * JD-Core Version:    0.7.0.1
 */