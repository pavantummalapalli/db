package net.sf.jsqlparser.expression;

public abstract interface LeafValue
{
  public abstract long toLong()
    throws LeafValue.InvalidLeaf;
  
  public abstract double toDouble()
    throws LeafValue.InvalidLeaf;
  
  public static class InvalidLeaf
    extends Exception
  {}
}


/* Location:           E:\workspace\java\db\lib\jsqlparser.jar
 * Qualified Name:     net.sf.jsqlparser.expression.LeafValue
 * JD-Core Version:    0.7.0.1
 */