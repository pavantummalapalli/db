/*  1:   */ package net.sf.jsqlparser.expression;
/*  2:   */ 
/*  3:   */ public abstract class BinaryExpression
/*  4:   */   implements Expression
/*  5:   */ {
/*  6:   */   private Expression leftExpression;
/*  7:   */   private Expression rightExpression;
/*  8:33 */   private boolean not = false;
/*  9:   */   
/* 10:   */   public BinaryExpression(Expression leftExpression, Expression rightExpression)
/* 11:   */   {
/* 12:36 */     this.leftExpression = leftExpression;
/* 13:37 */     this.rightExpression = rightExpression;
/* 14:   */   }
/* 15:   */   
/* 16:   */   public BinaryExpression() {}
/* 17:   */   
/* 18:   */   public Expression getLeftExpression()
/* 19:   */   {
/* 20:44 */     return this.leftExpression;
/* 21:   */   }
/* 22:   */   
/* 23:   */   public Expression getRightExpression()
/* 24:   */   {
/* 25:48 */     return this.rightExpression;
/* 26:   */   }
/* 27:   */   
/* 28:   */   public void setLeftExpression(Expression expression)
/* 29:   */   {
/* 30:52 */     this.leftExpression = expression;
/* 31:   */   }
/* 32:   */   
/* 33:   */   public void setRightExpression(Expression expression)
/* 34:   */   {
/* 35:56 */     this.rightExpression = expression;
/* 36:   */   }
/* 37:   */   
/* 38:   */   public void setNot()
/* 39:   */   {
/* 40:60 */     this.not = true;
/* 41:   */   }
/* 42:   */   
/* 43:   */   public boolean isNot()
/* 44:   */   {
/* 45:64 */     return this.not;
/* 46:   */   }
/* 47:   */   
/* 48:   */   public String toString()
/* 49:   */   {
/* 50:68 */     return (this.not ? "NOT " : "") + getLeftExpression() + " " + getStringExpression() + " " + getRightExpression();
/* 51:   */   }
/* 52:   */   
/* 53:   */   public abstract String getStringExpression();
/* 54:   */ }


/* Location:           E:\workspace\java\db\lib\jsqlparser.jar
 * Qualified Name:     net.sf.jsqlparser.expression.BinaryExpression
 * JD-Core Version:    0.7.0.1
 */