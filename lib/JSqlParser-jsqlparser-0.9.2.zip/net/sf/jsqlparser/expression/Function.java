/*   1:    */ package net.sf.jsqlparser.expression;
/*   2:    */ 
/*   3:    */ import net.sf.jsqlparser.expression.operators.relational.ExpressionList;
/*   4:    */ 
/*   5:    */ public class Function
/*   6:    */   implements Expression
/*   7:    */ {
/*   8:    */   private String name;
/*   9:    */   private ExpressionList parameters;
/*  10: 34 */   private boolean allColumns = false;
/*  11: 35 */   private boolean distinct = false;
/*  12: 36 */   private boolean isEscaped = false;
/*  13:    */   
/*  14:    */   public void accept(ExpressionVisitor expressionVisitor)
/*  15:    */   {
/*  16: 39 */     expressionVisitor.visit(this);
/*  17:    */   }
/*  18:    */   
/*  19:    */   public String getName()
/*  20:    */   {
/*  21: 47 */     return this.name;
/*  22:    */   }
/*  23:    */   
/*  24:    */   public void setName(String string)
/*  25:    */   {
/*  26: 51 */     this.name = string;
/*  27:    */   }
/*  28:    */   
/*  29:    */   public boolean isAllColumns()
/*  30:    */   {
/*  31: 59 */     return this.allColumns;
/*  32:    */   }
/*  33:    */   
/*  34:    */   public void setAllColumns(boolean b)
/*  35:    */   {
/*  36: 63 */     this.allColumns = b;
/*  37:    */   }
/*  38:    */   
/*  39:    */   public boolean isDistinct()
/*  40:    */   {
/*  41: 71 */     return this.distinct;
/*  42:    */   }
/*  43:    */   
/*  44:    */   public void setDistinct(boolean b)
/*  45:    */   {
/*  46: 75 */     this.distinct = b;
/*  47:    */   }
/*  48:    */   
/*  49:    */   public ExpressionList getParameters()
/*  50:    */   {
/*  51: 84 */     return this.parameters;
/*  52:    */   }
/*  53:    */   
/*  54:    */   public void setParameters(ExpressionList list)
/*  55:    */   {
/*  56: 88 */     this.parameters = list;
/*  57:    */   }
/*  58:    */   
/*  59:    */   public boolean isEscaped()
/*  60:    */   {
/*  61: 96 */     return this.isEscaped;
/*  62:    */   }
/*  63:    */   
/*  64:    */   public void setEscaped(boolean isEscaped)
/*  65:    */   {
/*  66:100 */     this.isEscaped = isEscaped;
/*  67:    */   }
/*  68:    */   
/*  69:    */   public String toString()
/*  70:    */   {
/*  71:104 */     String params = "";
/*  72:106 */     if (this.allColumns)
/*  73:    */     {
/*  74:107 */       params = "(*)";
/*  75:    */     }
/*  76:109 */     else if (this.parameters != null)
/*  77:    */     {
/*  78:110 */       params = this.parameters.toString();
/*  79:111 */       if (isDistinct()) {
/*  80:112 */         params = params.replaceFirst("\\(", "(DISTINCT ");
/*  81:    */       }
/*  82:    */     }
/*  83:116 */     String ans = this.name + "" + params + "";
/*  84:118 */     if (this.isEscaped) {
/*  85:119 */       ans = "{fn " + ans + "}";
/*  86:    */     }
/*  87:122 */     return ans;
/*  88:    */   }
/*  89:    */ }


/* Location:           E:\workspace\java\db\lib\jsqlparser.jar
 * Qualified Name:     net.sf.jsqlparser.expression.Function
 * JD-Core Version:    0.7.0.1
 */