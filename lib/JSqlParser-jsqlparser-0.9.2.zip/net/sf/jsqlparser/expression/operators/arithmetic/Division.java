/*  1:   */ package net.sf.jsqlparser.expression.operators.arithmetic;
/*  2:   */ 
/*  3:   */ import net.sf.jsqlparser.expression.BinaryExpression;
/*  4:   */ import net.sf.jsqlparser.expression.Expression;
/*  5:   */ import net.sf.jsqlparser.expression.ExpressionVisitor;
/*  6:   */ 
/*  7:   */ public class Division
/*  8:   */   extends BinaryExpression
/*  9:   */ {
/* 10:   */   public Division() {}
/* 11:   */   
/* 12:   */   public Division(Expression lhs, Expression rhs)
/* 13:   */   {
/* 14:32 */     super(lhs, rhs);
/* 15:   */   }
/* 16:   */   
/* 17:   */   public void accept(ExpressionVisitor expressionVisitor)
/* 18:   */   {
/* 19:35 */     expressionVisitor.visit(this);
/* 20:   */   }
/* 21:   */   
/* 22:   */   public String getStringExpression()
/* 23:   */   {
/* 24:39 */     return "/";
/* 25:   */   }
/* 26:   */ }


/* Location:           E:\workspace\java\db\lib\jsqlparser.jar
 * Qualified Name:     net.sf.jsqlparser.expression.operators.arithmetic.Division
 * JD-Core Version:    0.7.0.1
 */