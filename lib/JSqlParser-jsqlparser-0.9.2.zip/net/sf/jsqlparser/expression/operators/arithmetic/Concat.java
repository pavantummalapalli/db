/*  1:   */ package net.sf.jsqlparser.expression.operators.arithmetic;
/*  2:   */ 
/*  3:   */ import net.sf.jsqlparser.expression.BinaryExpression;
/*  4:   */ import net.sf.jsqlparser.expression.Expression;
/*  5:   */ import net.sf.jsqlparser.expression.ExpressionVisitor;
/*  6:   */ 
/*  7:   */ public class Concat
/*  8:   */   extends BinaryExpression
/*  9:   */ {
/* 10:   */   public Concat() {}
/* 11:   */   
/* 12:   */   public Concat(Expression lhs, Expression rhs)
/* 13:   */   {
/* 14:10 */     super(lhs, rhs);
/* 15:   */   }
/* 16:   */   
/* 17:   */   public void accept(ExpressionVisitor expressionVisitor)
/* 18:   */   {
/* 19:13 */     expressionVisitor.visit(this);
/* 20:   */   }
/* 21:   */   
/* 22:   */   public String getStringExpression()
/* 23:   */   {
/* 24:17 */     return "||";
/* 25:   */   }
/* 26:   */ }


/* Location:           E:\workspace\java\db\lib\jsqlparser.jar
 * Qualified Name:     net.sf.jsqlparser.expression.operators.arithmetic.Concat
 * JD-Core Version:    0.7.0.1
 */