/*  1:   */ package net.sf.jsqlparser.expression.operators.relational;
/*  2:   */ 
/*  3:   */ import java.util.List;
/*  4:   */ import net.sf.jsqlparser.statement.select.PlainSelect;
/*  5:   */ 
/*  6:   */ public class ExpressionList
/*  7:   */   implements ItemsList
/*  8:   */ {
/*  9:   */   private List expressions;
/* 10:   */   
/* 11:   */   public ExpressionList() {}
/* 12:   */   
/* 13:   */   public ExpressionList(List expressions)
/* 14:   */   {
/* 15:39 */     this.expressions = expressions;
/* 16:   */   }
/* 17:   */   
/* 18:   */   public List getExpressions()
/* 19:   */   {
/* 20:43 */     return this.expressions;
/* 21:   */   }
/* 22:   */   
/* 23:   */   public void setExpressions(List list)
/* 24:   */   {
/* 25:47 */     this.expressions = list;
/* 26:   */   }
/* 27:   */   
/* 28:   */   public void accept(ItemsListVisitor itemsListVisitor)
/* 29:   */   {
/* 30:51 */     itemsListVisitor.visit(this);
/* 31:   */   }
/* 32:   */   
/* 33:   */   public String toString()
/* 34:   */   {
/* 35:55 */     return PlainSelect.getStringList(this.expressions, true, true);
/* 36:   */   }
/* 37:   */ }


/* Location:           E:\workspace\java\db\lib\jsqlparser.jar
 * Qualified Name:     net.sf.jsqlparser.expression.operators.relational.ExpressionList
 * JD-Core Version:    0.7.0.1
 */