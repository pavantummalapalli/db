/*  1:   */ package net.sf.jsqlparser.expression.operators.relational;
/*  2:   */ 
/*  3:   */ import net.sf.jsqlparser.expression.Expression;
/*  4:   */ import net.sf.jsqlparser.expression.ExpressionVisitor;
/*  5:   */ 
/*  6:   */ public class InExpression
/*  7:   */   implements Expression
/*  8:   */ {
/*  9:   */   private Expression leftExpression;
/* 10:   */   private ItemsList itemsList;
/* 11:35 */   private boolean not = false;
/* 12:   */   
/* 13:   */   public InExpression() {}
/* 14:   */   
/* 15:   */   public InExpression(Expression leftExpression, ItemsList itemsList)
/* 16:   */   {
/* 17:41 */     setLeftExpression(leftExpression);
/* 18:42 */     setItemsList(itemsList);
/* 19:   */   }
/* 20:   */   
/* 21:   */   public ItemsList getItemsList()
/* 22:   */   {
/* 23:46 */     return this.itemsList;
/* 24:   */   }
/* 25:   */   
/* 26:   */   public Expression getLeftExpression()
/* 27:   */   {
/* 28:50 */     return this.leftExpression;
/* 29:   */   }
/* 30:   */   
/* 31:   */   public void setItemsList(ItemsList list)
/* 32:   */   {
/* 33:54 */     this.itemsList = list;
/* 34:   */   }
/* 35:   */   
/* 36:   */   public void setLeftExpression(Expression expression)
/* 37:   */   {
/* 38:58 */     this.leftExpression = expression;
/* 39:   */   }
/* 40:   */   
/* 41:   */   public boolean isNot()
/* 42:   */   {
/* 43:62 */     return this.not;
/* 44:   */   }
/* 45:   */   
/* 46:   */   public void setNot(boolean b)
/* 47:   */   {
/* 48:66 */     this.not = b;
/* 49:   */   }
/* 50:   */   
/* 51:   */   public void accept(ExpressionVisitor expressionVisitor)
/* 52:   */   {
/* 53:70 */     expressionVisitor.visit(this);
/* 54:   */   }
/* 55:   */   
/* 56:   */   public String toString()
/* 57:   */   {
/* 58:74 */     return this.leftExpression + " " + (this.not ? "NOT " : "") + "IN " + this.itemsList + "";
/* 59:   */   }
/* 60:   */ }


/* Location:           E:\workspace\java\db\lib\jsqlparser.jar
 * Qualified Name:     net.sf.jsqlparser.expression.operators.relational.InExpression
 * JD-Core Version:    0.7.0.1
 */