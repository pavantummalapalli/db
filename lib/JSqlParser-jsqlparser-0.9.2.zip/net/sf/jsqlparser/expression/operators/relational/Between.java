/*  1:   */ package net.sf.jsqlparser.expression.operators.relational;
/*  2:   */ 
/*  3:   */ import net.sf.jsqlparser.expression.Expression;
/*  4:   */ import net.sf.jsqlparser.expression.ExpressionVisitor;
/*  5:   */ 
/*  6:   */ public class Between
/*  7:   */   implements Expression
/*  8:   */ {
/*  9:   */   private Expression leftExpression;
/* 10:34 */   private boolean not = false;
/* 11:   */   private Expression betweenExpressionStart;
/* 12:   */   private Expression betweenExpressionEnd;
/* 13:   */   
/* 14:   */   public Expression getBetweenExpressionEnd()
/* 15:   */   {
/* 16:39 */     return this.betweenExpressionEnd;
/* 17:   */   }
/* 18:   */   
/* 19:   */   public Expression getBetweenExpressionStart()
/* 20:   */   {
/* 21:43 */     return this.betweenExpressionStart;
/* 22:   */   }
/* 23:   */   
/* 24:   */   public Expression getLeftExpression()
/* 25:   */   {
/* 26:47 */     return this.leftExpression;
/* 27:   */   }
/* 28:   */   
/* 29:   */   public boolean isNot()
/* 30:   */   {
/* 31:51 */     return this.not;
/* 32:   */   }
/* 33:   */   
/* 34:   */   public void setBetweenExpressionEnd(Expression expression)
/* 35:   */   {
/* 36:55 */     this.betweenExpressionEnd = expression;
/* 37:   */   }
/* 38:   */   
/* 39:   */   public void setBetweenExpressionStart(Expression expression)
/* 40:   */   {
/* 41:59 */     this.betweenExpressionStart = expression;
/* 42:   */   }
/* 43:   */   
/* 44:   */   public void setLeftExpression(Expression expression)
/* 45:   */   {
/* 46:63 */     this.leftExpression = expression;
/* 47:   */   }
/* 48:   */   
/* 49:   */   public void setNot(boolean b)
/* 50:   */   {
/* 51:67 */     this.not = b;
/* 52:   */   }
/* 53:   */   
/* 54:   */   public void accept(ExpressionVisitor expressionVisitor)
/* 55:   */   {
/* 56:71 */     expressionVisitor.visit(this);
/* 57:   */   }
/* 58:   */   
/* 59:   */   public String toString()
/* 60:   */   {
/* 61:75 */     return this.leftExpression + " " + (this.not ? "NOT " : "") + "BETWEEN " + this.betweenExpressionStart + " AND " + this.betweenExpressionEnd;
/* 62:   */   }
/* 63:   */ }


/* Location:           E:\workspace\java\db\lib\jsqlparser.jar
 * Qualified Name:     net.sf.jsqlparser.expression.operators.relational.Between
 * JD-Core Version:    0.7.0.1
 */