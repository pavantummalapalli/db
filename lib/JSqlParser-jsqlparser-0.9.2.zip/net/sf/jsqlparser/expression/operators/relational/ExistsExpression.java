/*  1:   */ package net.sf.jsqlparser.expression.operators.relational;
/*  2:   */ 
/*  3:   */ import net.sf.jsqlparser.expression.Expression;
/*  4:   */ import net.sf.jsqlparser.expression.ExpressionVisitor;
/*  5:   */ 
/*  6:   */ public class ExistsExpression
/*  7:   */   implements Expression
/*  8:   */ {
/*  9:   */   private Expression rightExpression;
/* 10:31 */   private boolean not = false;
/* 11:   */   
/* 12:   */   public Expression getRightExpression()
/* 13:   */   {
/* 14:34 */     return this.rightExpression;
/* 15:   */   }
/* 16:   */   
/* 17:   */   public void setRightExpression(Expression expression)
/* 18:   */   {
/* 19:38 */     this.rightExpression = expression;
/* 20:   */   }
/* 21:   */   
/* 22:   */   public boolean isNot()
/* 23:   */   {
/* 24:42 */     return this.not;
/* 25:   */   }
/* 26:   */   
/* 27:   */   public void setNot(boolean b)
/* 28:   */   {
/* 29:46 */     this.not = b;
/* 30:   */   }
/* 31:   */   
/* 32:   */   public void accept(ExpressionVisitor expressionVisitor)
/* 33:   */   {
/* 34:50 */     expressionVisitor.visit(this);
/* 35:   */   }
/* 36:   */   
/* 37:   */   public String getStringExpression()
/* 38:   */   {
/* 39:54 */     return (this.not ? "NOT " : "") + "EXISTS";
/* 40:   */   }
/* 41:   */   
/* 42:   */   public String toString()
/* 43:   */   {
/* 44:58 */     return getStringExpression() + " " + this.rightExpression.toString();
/* 45:   */   }
/* 46:   */ }


/* Location:           E:\workspace\java\db\lib\jsqlparser.jar
 * Qualified Name:     net.sf.jsqlparser.expression.operators.relational.ExistsExpression
 * JD-Core Version:    0.7.0.1
 */