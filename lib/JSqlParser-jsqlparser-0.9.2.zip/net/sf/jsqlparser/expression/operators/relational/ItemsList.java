package net.sf.jsqlparser.expression.operators.relational;

public abstract interface ItemsList
{
  public abstract void accept(ItemsListVisitor paramItemsListVisitor);
}


/* Location:           E:\workspace\java\db\lib\jsqlparser.jar
 * Qualified Name:     net.sf.jsqlparser.expression.operators.relational.ItemsList
 * JD-Core Version:    0.7.0.1
 */