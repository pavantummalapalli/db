/*  1:   */ package net.sf.jsqlparser.expression.operators.relational;
/*  2:   */ 
/*  3:   */ import net.sf.jsqlparser.expression.BinaryExpression;
/*  4:   */ import net.sf.jsqlparser.expression.ExpressionVisitor;
/*  5:   */ 
/*  6:   */ public class Matches
/*  7:   */   extends BinaryExpression
/*  8:   */ {
/*  9:   */   public void accept(ExpressionVisitor expressionVisitor)
/* 10:   */   {
/* 11: 8 */     expressionVisitor.visit(this);
/* 12:   */   }
/* 13:   */   
/* 14:   */   public String getStringExpression()
/* 15:   */   {
/* 16:12 */     return "@@";
/* 17:   */   }
/* 18:   */ }


/* Location:           E:\workspace\java\db\lib\jsqlparser.jar
 * Qualified Name:     net.sf.jsqlparser.expression.operators.relational.Matches
 * JD-Core Version:    0.7.0.1
 */