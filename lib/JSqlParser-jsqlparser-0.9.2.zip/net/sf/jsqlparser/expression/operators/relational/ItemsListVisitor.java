package net.sf.jsqlparser.expression.operators.relational;

import net.sf.jsqlparser.statement.select.SubSelect;

public abstract interface ItemsListVisitor
{
  public abstract void visit(SubSelect paramSubSelect);
  
  public abstract void visit(ExpressionList paramExpressionList);
}


/* Location:           E:\workspace\java\db\lib\jsqlparser.jar
 * Qualified Name:     net.sf.jsqlparser.expression.operators.relational.ItemsListVisitor
 * JD-Core Version:    0.7.0.1
 */