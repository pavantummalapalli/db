/*  1:   */ package net.sf.jsqlparser.expression.operators.relational;
/*  2:   */ 
/*  3:   */ import net.sf.jsqlparser.expression.Expression;
/*  4:   */ import net.sf.jsqlparser.expression.ExpressionVisitor;
/*  5:   */ 
/*  6:   */ public class IsNullExpression
/*  7:   */   implements Expression
/*  8:   */ {
/*  9:   */   private Expression leftExpression;
/* 10:31 */   private boolean not = false;
/* 11:   */   
/* 12:   */   public Expression getLeftExpression()
/* 13:   */   {
/* 14:34 */     return this.leftExpression;
/* 15:   */   }
/* 16:   */   
/* 17:   */   public boolean isNot()
/* 18:   */   {
/* 19:38 */     return this.not;
/* 20:   */   }
/* 21:   */   
/* 22:   */   public void setLeftExpression(Expression expression)
/* 23:   */   {
/* 24:42 */     this.leftExpression = expression;
/* 25:   */   }
/* 26:   */   
/* 27:   */   public void setNot(boolean b)
/* 28:   */   {
/* 29:46 */     this.not = b;
/* 30:   */   }
/* 31:   */   
/* 32:   */   public void accept(ExpressionVisitor expressionVisitor)
/* 33:   */   {
/* 34:50 */     expressionVisitor.visit(this);
/* 35:   */   }
/* 36:   */   
/* 37:   */   public String toString()
/* 38:   */   {
/* 39:54 */     return this.leftExpression + " IS " + (this.not ? "NOT " : "") + "NULL";
/* 40:   */   }
/* 41:   */ }


/* Location:           E:\workspace\java\db\lib\jsqlparser.jar
 * Qualified Name:     net.sf.jsqlparser.expression.operators.relational.IsNullExpression
 * JD-Core Version:    0.7.0.1
 */