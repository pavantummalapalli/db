/*  1:   */ package net.sf.jsqlparser.expression.operators.relational;
/*  2:   */ 
/*  3:   */ import net.sf.jsqlparser.expression.BinaryExpression;
/*  4:   */ import net.sf.jsqlparser.expression.ExpressionVisitor;
/*  5:   */ 
/*  6:   */ public class LikeExpression
/*  7:   */   extends BinaryExpression
/*  8:   */ {
/*  9:30 */   private boolean not = false;
/* 10:31 */   private String escape = null;
/* 11:   */   
/* 12:   */   public boolean isNot()
/* 13:   */   {
/* 14:34 */     return this.not;
/* 15:   */   }
/* 16:   */   
/* 17:   */   public void setNot(boolean b)
/* 18:   */   {
/* 19:38 */     this.not = b;
/* 20:   */   }
/* 21:   */   
/* 22:   */   public void accept(ExpressionVisitor expressionVisitor)
/* 23:   */   {
/* 24:42 */     expressionVisitor.visit(this);
/* 25:   */   }
/* 26:   */   
/* 27:   */   public String getStringExpression()
/* 28:   */   {
/* 29:47 */     return (this.not ? "NOT " : "") + "LIKE";
/* 30:   */   }
/* 31:   */   
/* 32:   */   public String toString()
/* 33:   */   {
/* 34:52 */     String retval = super.toString();
/* 35:53 */     if (this.escape != null) {
/* 36:54 */       retval = retval + " ESCAPE '" + this.escape + "'";
/* 37:   */     }
/* 38:57 */     return retval;
/* 39:   */   }
/* 40:   */   
/* 41:   */   public String getEscape()
/* 42:   */   {
/* 43:61 */     return this.escape;
/* 44:   */   }
/* 45:   */   
/* 46:   */   public void setEscape(String escape)
/* 47:   */   {
/* 48:65 */     this.escape = escape;
/* 49:   */   }
/* 50:   */ }


/* Location:           E:\workspace\java\db\lib\jsqlparser.jar
 * Qualified Name:     net.sf.jsqlparser.expression.operators.relational.LikeExpression
 * JD-Core Version:    0.7.0.1
 */