/*  1:   */ package net.sf.jsqlparser.expression.operators.relational;
/*  2:   */ 
/*  3:   */ import net.sf.jsqlparser.expression.BinaryExpression;
/*  4:   */ import net.sf.jsqlparser.expression.Expression;
/*  5:   */ import net.sf.jsqlparser.expression.ExpressionVisitor;
/*  6:   */ 
/*  7:   */ public class MinorThanEquals
/*  8:   */   extends BinaryExpression
/*  9:   */ {
/* 10:   */   public MinorThanEquals() {}
/* 11:   */   
/* 12:   */   public MinorThanEquals(Expression lhs, Expression rhs)
/* 13:   */   {
/* 14:33 */     super(lhs, rhs);
/* 15:   */   }
/* 16:   */   
/* 17:   */   public void accept(ExpressionVisitor expressionVisitor)
/* 18:   */   {
/* 19:36 */     expressionVisitor.visit(this);
/* 20:   */   }
/* 21:   */   
/* 22:   */   public String getStringExpression()
/* 23:   */   {
/* 24:41 */     return "<=";
/* 25:   */   }
/* 26:   */ }


/* Location:           E:\workspace\java\db\lib\jsqlparser.jar
 * Qualified Name:     net.sf.jsqlparser.expression.operators.relational.MinorThanEquals
 * JD-Core Version:    0.7.0.1
 */