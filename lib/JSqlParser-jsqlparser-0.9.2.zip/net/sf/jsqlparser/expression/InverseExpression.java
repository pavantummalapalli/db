/*  1:   */ package net.sf.jsqlparser.expression;
/*  2:   */ 
/*  3:   */ public class InverseExpression
/*  4:   */   implements Expression
/*  5:   */ {
/*  6:   */   private Expression expression;
/*  7:   */   
/*  8:   */   public InverseExpression() {}
/*  9:   */   
/* 10:   */   public InverseExpression(Expression expression)
/* 11:   */   {
/* 12:35 */     setExpression(expression);
/* 13:   */   }
/* 14:   */   
/* 15:   */   public Expression getExpression()
/* 16:   */   {
/* 17:39 */     return this.expression;
/* 18:   */   }
/* 19:   */   
/* 20:   */   public void setExpression(Expression expression)
/* 21:   */   {
/* 22:43 */     this.expression = expression;
/* 23:   */   }
/* 24:   */   
/* 25:   */   public void accept(ExpressionVisitor expressionVisitor)
/* 26:   */   {
/* 27:47 */     expressionVisitor.visit(this);
/* 28:   */   }
/* 29:   */ }


/* Location:           E:\workspace\java\db\lib\jsqlparser.jar
 * Qualified Name:     net.sf.jsqlparser.expression.InverseExpression
 * JD-Core Version:    0.7.0.1
 */