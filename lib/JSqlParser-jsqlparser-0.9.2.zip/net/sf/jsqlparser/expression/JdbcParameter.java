/*  1:   */ package net.sf.jsqlparser.expression;
/*  2:   */ 
/*  3:   */ public class JdbcParameter
/*  4:   */   implements Expression
/*  5:   */ {
/*  6:   */   public void accept(ExpressionVisitor expressionVisitor)
/*  7:   */   {
/*  8:30 */     expressionVisitor.visit(this);
/*  9:   */   }
/* 10:   */   
/* 11:   */   public String toString()
/* 12:   */   {
/* 13:34 */     return "?";
/* 14:   */   }
/* 15:   */ }


/* Location:           E:\workspace\java\db\lib\jsqlparser.jar
 * Qualified Name:     net.sf.jsqlparser.expression.JdbcParameter
 * JD-Core Version:    0.7.0.1
 */