package net.sf.jsqlparser.expression;

public abstract interface Expression
{
  public abstract void accept(ExpressionVisitor paramExpressionVisitor);
}


/* Location:           E:\workspace\java\db\lib\jsqlparser.jar
 * Qualified Name:     net.sf.jsqlparser.expression.Expression
 * JD-Core Version:    0.7.0.1
 */