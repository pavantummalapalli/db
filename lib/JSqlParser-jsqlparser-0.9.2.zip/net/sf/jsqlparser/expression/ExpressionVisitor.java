package net.sf.jsqlparser.expression;

import net.sf.jsqlparser.expression.operators.arithmetic.Addition;
import net.sf.jsqlparser.expression.operators.arithmetic.BitwiseAnd;
import net.sf.jsqlparser.expression.operators.arithmetic.BitwiseOr;
import net.sf.jsqlparser.expression.operators.arithmetic.BitwiseXor;
import net.sf.jsqlparser.expression.operators.arithmetic.Concat;
import net.sf.jsqlparser.expression.operators.arithmetic.Division;
import net.sf.jsqlparser.expression.operators.arithmetic.Multiplication;
import net.sf.jsqlparser.expression.operators.arithmetic.Subtraction;
import net.sf.jsqlparser.expression.operators.conditional.AndExpression;
import net.sf.jsqlparser.expression.operators.conditional.OrExpression;
import net.sf.jsqlparser.expression.operators.relational.Between;
import net.sf.jsqlparser.expression.operators.relational.EqualsTo;
import net.sf.jsqlparser.expression.operators.relational.ExistsExpression;
import net.sf.jsqlparser.expression.operators.relational.GreaterThan;
import net.sf.jsqlparser.expression.operators.relational.GreaterThanEquals;
import net.sf.jsqlparser.expression.operators.relational.InExpression;
import net.sf.jsqlparser.expression.operators.relational.IsNullExpression;
import net.sf.jsqlparser.expression.operators.relational.LikeExpression;
import net.sf.jsqlparser.expression.operators.relational.Matches;
import net.sf.jsqlparser.expression.operators.relational.MinorThan;
import net.sf.jsqlparser.expression.operators.relational.MinorThanEquals;
import net.sf.jsqlparser.expression.operators.relational.NotEqualsTo;
import net.sf.jsqlparser.schema.Column;
import net.sf.jsqlparser.statement.select.SubSelect;

public abstract interface ExpressionVisitor
{
  public abstract void visit(NullValue paramNullValue);
  
  public abstract void visit(Function paramFunction);
  
  public abstract void visit(InverseExpression paramInverseExpression);
  
  public abstract void visit(JdbcParameter paramJdbcParameter);
  
  public abstract void visit(DoubleValue paramDoubleValue);
  
  public abstract void visit(LongValue paramLongValue);
  
  public abstract void visit(DateValue paramDateValue);
  
  public abstract void visit(TimeValue paramTimeValue);
  
  public abstract void visit(TimestampValue paramTimestampValue);
  
  public abstract void visit(Parenthesis paramParenthesis);
  
  public abstract void visit(StringValue paramStringValue);
  
  public abstract void visit(Addition paramAddition);
  
  public abstract void visit(Division paramDivision);
  
  public abstract void visit(Multiplication paramMultiplication);
  
  public abstract void visit(Subtraction paramSubtraction);
  
  public abstract void visit(AndExpression paramAndExpression);
  
  public abstract void visit(OrExpression paramOrExpression);
  
  public abstract void visit(Between paramBetween);
  
  public abstract void visit(EqualsTo paramEqualsTo);
  
  public abstract void visit(GreaterThan paramGreaterThan);
  
  public abstract void visit(GreaterThanEquals paramGreaterThanEquals);
  
  public abstract void visit(InExpression paramInExpression);
  
  public abstract void visit(IsNullExpression paramIsNullExpression);
  
  public abstract void visit(LikeExpression paramLikeExpression);
  
  public abstract void visit(MinorThan paramMinorThan);
  
  public abstract void visit(MinorThanEquals paramMinorThanEquals);
  
  public abstract void visit(NotEqualsTo paramNotEqualsTo);
  
  public abstract void visit(Column paramColumn);
  
  public abstract void visit(SubSelect paramSubSelect);
  
  public abstract void visit(CaseExpression paramCaseExpression);
  
  public abstract void visit(WhenClause paramWhenClause);
  
  public abstract void visit(ExistsExpression paramExistsExpression);
  
  public abstract void visit(AllComparisonExpression paramAllComparisonExpression);
  
  public abstract void visit(AnyComparisonExpression paramAnyComparisonExpression);
  
  public abstract void visit(Concat paramConcat);
  
  public abstract void visit(Matches paramMatches);
  
  public abstract void visit(BitwiseAnd paramBitwiseAnd);
  
  public abstract void visit(BitwiseOr paramBitwiseOr);
  
  public abstract void visit(BitwiseXor paramBitwiseXor);
}


/* Location:           E:\workspace\java\db\lib\jsqlparser.jar
 * Qualified Name:     net.sf.jsqlparser.expression.ExpressionVisitor
 * JD-Core Version:    0.7.0.1
 */