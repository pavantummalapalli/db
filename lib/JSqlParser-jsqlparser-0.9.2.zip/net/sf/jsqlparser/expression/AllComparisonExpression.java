/*  1:   */ package net.sf.jsqlparser.expression;
/*  2:   */ 
/*  3:   */ import net.sf.jsqlparser.statement.select.SubSelect;
/*  4:   */ 
/*  5:   */ public class AllComparisonExpression
/*  6:   */   implements Expression
/*  7:   */ {
/*  8:   */   private SubSelect subSelect;
/*  9:   */   
/* 10:   */   public AllComparisonExpression(SubSelect subSelect)
/* 11:   */   {
/* 12: 9 */     this.subSelect = subSelect;
/* 13:   */   }
/* 14:   */   
/* 15:   */   public SubSelect getSubSelect()
/* 16:   */   {
/* 17:13 */     return this.subSelect;
/* 18:   */   }
/* 19:   */   
/* 20:   */   public void accept(ExpressionVisitor expressionVisitor)
/* 21:   */   {
/* 22:17 */     expressionVisitor.visit(this);
/* 23:   */   }
/* 24:   */ }


/* Location:           E:\workspace\java\db\lib\jsqlparser.jar
 * Qualified Name:     net.sf.jsqlparser.expression.AllComparisonExpression
 * JD-Core Version:    0.7.0.1
 */