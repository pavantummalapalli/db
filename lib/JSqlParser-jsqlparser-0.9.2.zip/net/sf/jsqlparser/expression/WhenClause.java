/*  1:   */ package net.sf.jsqlparser.expression;
/*  2:   */ 
/*  3:   */ public class WhenClause
/*  4:   */   implements Expression
/*  5:   */ {
/*  6:   */   private Expression whenExpression;
/*  7:   */   private Expression thenExpression;
/*  8:   */   
/*  9:   */   public void accept(ExpressionVisitor expressionVisitor)
/* 10:   */   {
/* 11:41 */     expressionVisitor.visit(this);
/* 12:   */   }
/* 13:   */   
/* 14:   */   public Expression getThenExpression()
/* 15:   */   {
/* 16:48 */     return this.thenExpression;
/* 17:   */   }
/* 18:   */   
/* 19:   */   public void setThenExpression(Expression thenExpression)
/* 20:   */   {
/* 21:54 */     this.thenExpression = thenExpression;
/* 22:   */   }
/* 23:   */   
/* 24:   */   public Expression getWhenExpression()
/* 25:   */   {
/* 26:60 */     return this.whenExpression;
/* 27:   */   }
/* 28:   */   
/* 29:   */   public void setWhenExpression(Expression whenExpression)
/* 30:   */   {
/* 31:66 */     this.whenExpression = whenExpression;
/* 32:   */   }
/* 33:   */   
/* 34:   */   public String toString()
/* 35:   */   {
/* 36:70 */     return "WHEN " + this.whenExpression + " THEN " + this.thenExpression;
/* 37:   */   }
/* 38:   */ }


/* Location:           E:\workspace\java\db\lib\jsqlparser.jar
 * Qualified Name:     net.sf.jsqlparser.expression.WhenClause
 * JD-Core Version:    0.7.0.1
 */