/*  1:   */ package net.sf.jsqlparser.expression;
/*  2:   */ 
/*  3:   */ public class StringValue
/*  4:   */   implements Expression, LeafValue
/*  5:   */ {
/*  6:29 */   private String value = "";
/*  7:   */   
/*  8:   */   public StringValue(String escapedValue)
/*  9:   */   {
/* 10:33 */     this.value = escapedValue.substring(1, escapedValue.length() - 1);
/* 11:   */   }
/* 12:   */   
/* 13:   */   public String getValue()
/* 14:   */   {
/* 15:37 */     return this.value;
/* 16:   */   }
/* 17:   */   
/* 18:   */   public String getNotExcapedValue()
/* 19:   */   {
/* 20:41 */     StringBuffer buffer = new StringBuffer(this.value);
/* 21:42 */     int index = 0;
/* 22:43 */     int deletesNum = 0;
/* 23:44 */     while ((index = this.value.indexOf("''", index)) != -1)
/* 24:   */     {
/* 25:45 */       buffer.deleteCharAt(index - deletesNum);
/* 26:46 */       index += 2;
/* 27:47 */       deletesNum++;
/* 28:   */     }
/* 29:49 */     return buffer.toString();
/* 30:   */   }
/* 31:   */   
/* 32:   */   public void setValue(String string)
/* 33:   */   {
/* 34:53 */     this.value = string;
/* 35:   */   }
/* 36:   */   
/* 37:   */   public void accept(ExpressionVisitor expressionVisitor)
/* 38:   */   {
/* 39:57 */     expressionVisitor.visit(this);
/* 40:   */   }
/* 41:   */   
/* 42:   */   public String toString()
/* 43:   */   {
/* 44:61 */     return "'" + this.value + "'";
/* 45:   */   }
/* 46:   */   
/* 47:   */   public long toLong()
/* 48:   */     throws LeafValue.InvalidLeaf
/* 49:   */   {
/* 50:64 */     throw new LeafValue.InvalidLeaf();
/* 51:   */   }
/* 52:   */   
/* 53:   */   public double toDouble()
/* 54:   */     throws LeafValue.InvalidLeaf
/* 55:   */   {
/* 56:65 */     throw new LeafValue.InvalidLeaf();
/* 57:   */   }
/* 58:   */ }


/* Location:           E:\workspace\java\db\lib\jsqlparser.jar
 * Qualified Name:     net.sf.jsqlparser.expression.StringValue
 * JD-Core Version:    0.7.0.1
 */