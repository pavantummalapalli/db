/*  1:   */ package net.sf.jsqlparser.expression;
/*  2:   */ 
/*  3:   */ public class NullValue
/*  4:   */   implements Expression, LeafValue
/*  5:   */ {
/*  6:   */   public void accept(ExpressionVisitor expressionVisitor)
/*  7:   */   {
/*  8:30 */     expressionVisitor.visit(this);
/*  9:   */   }
/* 10:   */   
/* 11:   */   public String toString()
/* 12:   */   {
/* 13:34 */     return "NULL";
/* 14:   */   }
/* 15:   */   
/* 16:   */   public long toLong()
/* 17:   */     throws LeafValue.InvalidLeaf
/* 18:   */   {
/* 19:37 */     throw new LeafValue.InvalidLeaf();
/* 20:   */   }
/* 21:   */   
/* 22:   */   public double toDouble()
/* 23:   */     throws LeafValue.InvalidLeaf
/* 24:   */   {
/* 25:38 */     throw new LeafValue.InvalidLeaf();
/* 26:   */   }
/* 27:   */ }


/* Location:           E:\workspace\java\db\lib\jsqlparser.jar
 * Qualified Name:     net.sf.jsqlparser.expression.NullValue
 * JD-Core Version:    0.7.0.1
 */