/*  1:   */ package net.sf.jsqlparser.expression;
/*  2:   */ 
/*  3:   */ import java.sql.Date;
/*  4:   */ 
/*  5:   */ public class DateValue
/*  6:   */   implements Expression, LeafValue
/*  7:   */ {
/*  8:   */   private Date value;
/*  9:   */   
/* 10:   */   public DateValue(String value)
/* 11:   */   {
/* 12:35 */     this.value = Date.valueOf(value.substring(1, value.length() - 1));
/* 13:   */   }
/* 14:   */   
/* 15:   */   public void accept(ExpressionVisitor expressionVisitor)
/* 16:   */   {
/* 17:39 */     expressionVisitor.visit(this);
/* 18:   */   }
/* 19:   */   
/* 20:   */   public int getYear()
/* 21:   */   {
/* 22:43 */     return this.value.getYear();
/* 23:   */   }
/* 24:   */   
/* 25:   */   public int getMonth()
/* 26:   */   {
/* 27:46 */     return this.value.getMonth();
/* 28:   */   }
/* 29:   */   
/* 30:   */   public int getDate()
/* 31:   */   {
/* 32:49 */     return this.value.getDate();
/* 33:   */   }
/* 34:   */   
/* 35:   */   public Date getValue()
/* 36:   */   {
/* 37:53 */     return this.value;
/* 38:   */   }
/* 39:   */   
/* 40:   */   public void setValue(Date d)
/* 41:   */   {
/* 42:57 */     this.value = d;
/* 43:   */   }
/* 44:   */   
/* 45:   */   public String toString()
/* 46:   */   {
/* 47:62 */     return this.value.toString();
/* 48:   */   }
/* 49:   */   
/* 50:   */   public long toLong()
/* 51:   */     throws LeafValue.InvalidLeaf
/* 52:   */   {
/* 53:65 */     throw new LeafValue.InvalidLeaf();
/* 54:   */   }
/* 55:   */   
/* 56:   */   public double toDouble()
/* 57:   */     throws LeafValue.InvalidLeaf
/* 58:   */   {
/* 59:66 */     throw new LeafValue.InvalidLeaf();
/* 60:   */   }
/* 61:   */ }


/* Location:           E:\workspace\java\db\lib\jsqlparser.jar
 * Qualified Name:     net.sf.jsqlparser.expression.DateValue
 * JD-Core Version:    0.7.0.1
 */