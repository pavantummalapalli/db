/*  1:   */ package net.sf.jsqlparser.expression;
/*  2:   */ 
/*  3:   */ public class DoubleValue
/*  4:   */   implements Expression, LeafValue
/*  5:   */ {
/*  6:   */   private double value;
/*  7:   */   private String stringValue;
/*  8:   */   
/*  9:   */   public DoubleValue(double value)
/* 10:   */   {
/* 11:32 */     this.value = value;
/* 12:   */   }
/* 13:   */   
/* 14:   */   public DoubleValue(String value)
/* 15:   */   {
/* 16:35 */     if (value.charAt(0) == '+') {
/* 17:36 */       value = value.substring(1);
/* 18:   */     }
/* 19:38 */     this.value = Double.parseDouble(value);
/* 20:39 */     this.stringValue = value;
/* 21:   */   }
/* 22:   */   
/* 23:   */   public void accept(ExpressionVisitor expressionVisitor)
/* 24:   */   {
/* 25:43 */     expressionVisitor.visit(this);
/* 26:   */   }
/* 27:   */   
/* 28:   */   public double getValue()
/* 29:   */   {
/* 30:48 */     return this.value;
/* 31:   */   }
/* 32:   */   
/* 33:   */   public void setValue(double d)
/* 34:   */   {
/* 35:52 */     this.value = d;
/* 36:   */   }
/* 37:   */   
/* 38:   */   public String toString()
/* 39:   */   {
/* 40:56 */     return this.stringValue;
/* 41:   */   }
/* 42:   */   
/* 43:   */   public long toLong()
/* 44:   */     throws LeafValue.InvalidLeaf
/* 45:   */   {
/* 46:59 */     throw new LeafValue.InvalidLeaf();
/* 47:   */   }
/* 48:   */   
/* 49:   */   public double toDouble()
/* 50:   */   {
/* 51:60 */     return getValue();
/* 52:   */   }
/* 53:   */ }


/* Location:           E:\workspace\java\db\lib\jsqlparser.jar
 * Qualified Name:     net.sf.jsqlparser.expression.DoubleValue
 * JD-Core Version:    0.7.0.1
 */