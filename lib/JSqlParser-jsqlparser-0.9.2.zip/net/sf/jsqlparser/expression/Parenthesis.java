/*  1:   */ package net.sf.jsqlparser.expression;
/*  2:   */ 
/*  3:   */ public class Parenthesis
/*  4:   */   implements Expression
/*  5:   */ {
/*  6:   */   private Expression expression;
/*  7:30 */   private boolean not = false;
/*  8:   */   
/*  9:   */   public Parenthesis() {}
/* 10:   */   
/* 11:   */   public Parenthesis(Expression expression)
/* 12:   */   {
/* 13:37 */     setExpression(expression);
/* 14:   */   }
/* 15:   */   
/* 16:   */   public Expression getExpression()
/* 17:   */   {
/* 18:41 */     return this.expression;
/* 19:   */   }
/* 20:   */   
/* 21:   */   public void setExpression(Expression expression)
/* 22:   */   {
/* 23:45 */     this.expression = expression;
/* 24:   */   }
/* 25:   */   
/* 26:   */   public void accept(ExpressionVisitor expressionVisitor)
/* 27:   */   {
/* 28:49 */     expressionVisitor.visit(this);
/* 29:   */   }
/* 30:   */   
/* 31:   */   public void setNot()
/* 32:   */   {
/* 33:53 */     this.not = true;
/* 34:   */   }
/* 35:   */   
/* 36:   */   public boolean isNot()
/* 37:   */   {
/* 38:57 */     return this.not;
/* 39:   */   }
/* 40:   */   
/* 41:   */   public String toString()
/* 42:   */   {
/* 43:61 */     return (this.not ? "NOT " : "") + "(" + this.expression + ")";
/* 44:   */   }
/* 45:   */ }


/* Location:           E:\workspace\java\db\lib\jsqlparser.jar
 * Qualified Name:     net.sf.jsqlparser.expression.Parenthesis
 * JD-Core Version:    0.7.0.1
 */