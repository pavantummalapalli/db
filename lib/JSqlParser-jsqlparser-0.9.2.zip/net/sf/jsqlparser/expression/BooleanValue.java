/*  1:   */ package net.sf.jsqlparser.expression;
/*  2:   */ 
/*  3:   */ public class BooleanValue
/*  4:   */   implements LeafValue
/*  5:   */ {
/*  6:   */   private boolean value;
/*  7:   */   
/*  8:   */   private BooleanValue(boolean value)
/*  9:   */   {
/* 10:32 */     this.value = value;
/* 11:   */   }
/* 12:   */   
/* 13:   */   public boolean getValue()
/* 14:   */   {
/* 15:34 */     return this.value;
/* 16:   */   }
/* 17:   */   
/* 18:37 */   public static final BooleanValue TRUE = new BooleanValue(true);
/* 19:38 */   public static final BooleanValue FALSE = new BooleanValue(false);
/* 20:   */   
/* 21:   */   public long toLong()
/* 22:   */   {
/* 23:40 */     return this.value ? 1L : 0L;
/* 24:   */   }
/* 25:   */   
/* 26:   */   public double toDouble()
/* 27:   */   {
/* 28:41 */     return this.value ? 1.0D : 0.0D;
/* 29:   */   }
/* 30:   */   
/* 31:   */   public String toString()
/* 32:   */   {
/* 33:44 */     return this.value ? "TRUE" : "FALSE";
/* 34:   */   }
/* 35:   */ }


/* Location:           E:\workspace\java\db\lib\jsqlparser.jar
 * Qualified Name:     net.sf.jsqlparser.expression.BooleanValue
 * JD-Core Version:    0.7.0.1
 */