/*  1:   */ package net.sf.jsqlparser.expression;
/*  2:   */ 
/*  3:   */ import java.sql.Timestamp;
/*  4:   */ 
/*  5:   */ public class TimestampValue
/*  6:   */   implements Expression, LeafValue
/*  7:   */ {
/*  8:   */   private Timestamp value;
/*  9:   */   
/* 10:   */   public TimestampValue(String value)
/* 11:   */   {
/* 12:35 */     this.value = Timestamp.valueOf(value.substring(1, value.length() - 1));
/* 13:   */   }
/* 14:   */   
/* 15:   */   public void accept(ExpressionVisitor expressionVisitor)
/* 16:   */   {
/* 17:39 */     expressionVisitor.visit(this);
/* 18:   */   }
/* 19:   */   
/* 20:   */   public Timestamp getValue()
/* 21:   */   {
/* 22:44 */     return this.value;
/* 23:   */   }
/* 24:   */   
/* 25:   */   public void setValue(Timestamp d)
/* 26:   */   {
/* 27:48 */     this.value = d;
/* 28:   */   }
/* 29:   */   
/* 30:   */   public String toString()
/* 31:   */   {
/* 32:52 */     return "{ts '" + this.value + "'}";
/* 33:   */   }
/* 34:   */   
/* 35:   */   public long toLong()
/* 36:   */     throws LeafValue.InvalidLeaf
/* 37:   */   {
/* 38:55 */     throw new LeafValue.InvalidLeaf();
/* 39:   */   }
/* 40:   */   
/* 41:   */   public double toDouble()
/* 42:   */     throws LeafValue.InvalidLeaf
/* 43:   */   {
/* 44:56 */     throw new LeafValue.InvalidLeaf();
/* 45:   */   }
/* 46:   */ }


/* Location:           E:\workspace\java\db\lib\jsqlparser.jar
 * Qualified Name:     net.sf.jsqlparser.expression.TimestampValue
 * JD-Core Version:    0.7.0.1
 */