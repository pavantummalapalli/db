/*   1:    */ package net.sf.jsqlparser.expression;
/*   2:    */ 
/*   3:    */ import java.util.List;
/*   4:    */ import net.sf.jsqlparser.statement.select.PlainSelect;
/*   5:    */ 
/*   6:    */ public class CaseExpression
/*   7:    */   implements Expression
/*   8:    */ {
/*   9:    */   private Expression switchExpression;
/*  10:    */   private List whenClauses;
/*  11:    */   private Expression elseExpression;
/*  12:    */   
/*  13:    */   public void accept(ExpressionVisitor expressionVisitor)
/*  14:    */   {
/*  15: 72 */     expressionVisitor.visit(this);
/*  16:    */   }
/*  17:    */   
/*  18:    */   public Expression getSwitchExpression()
/*  19:    */   {
/*  20: 79 */     return this.switchExpression;
/*  21:    */   }
/*  22:    */   
/*  23:    */   public void setSwitchExpression(Expression switchExpression)
/*  24:    */   {
/*  25: 85 */     this.switchExpression = switchExpression;
/*  26:    */   }
/*  27:    */   
/*  28:    */   public Expression getElseExpression()
/*  29:    */   {
/*  30: 92 */     return this.elseExpression;
/*  31:    */   }
/*  32:    */   
/*  33:    */   public void setElseExpression(Expression elseExpression)
/*  34:    */   {
/*  35: 98 */     this.elseExpression = elseExpression;
/*  36:    */   }
/*  37:    */   
/*  38:    */   public List getWhenClauses()
/*  39:    */   {
/*  40:104 */     return this.whenClauses;
/*  41:    */   }
/*  42:    */   
/*  43:    */   public void setWhenClauses(List whenClauses)
/*  44:    */   {
/*  45:111 */     this.whenClauses = whenClauses;
/*  46:    */   }
/*  47:    */   
/*  48:    */   public String toString()
/*  49:    */   {
/*  50:116 */     return "CASE " + (this.switchExpression != null ? this.switchExpression + " " : "") + PlainSelect.getStringList(this.whenClauses, false, false) + " " + (this.elseExpression != null ? "ELSE " + this.elseExpression + " " : "") + "END";
/*  51:    */   }
/*  52:    */ }


/* Location:           E:\workspace\java\db\lib\jsqlparser.jar
 * Qualified Name:     net.sf.jsqlparser.expression.CaseExpression
 * JD-Core Version:    0.7.0.1
 */