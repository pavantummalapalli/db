/*  1:   */ package net.sf.jsqlparser.statement.drop;
/*  2:   */ 
/*  3:   */ import java.util.List;
/*  4:   */ import net.sf.jsqlparser.statement.Statement;
/*  5:   */ import net.sf.jsqlparser.statement.StatementVisitor;
/*  6:   */ import net.sf.jsqlparser.statement.select.PlainSelect;
/*  7:   */ 
/*  8:   */ public class Drop
/*  9:   */   implements Statement
/* 10:   */ {
/* 11:   */   private String type;
/* 12:   */   private String name;
/* 13:   */   private List parameters;
/* 14:   */   
/* 15:   */   public void accept(StatementVisitor statementVisitor)
/* 16:   */   {
/* 17:15 */     statementVisitor.visit(this);
/* 18:   */   }
/* 19:   */   
/* 20:   */   public String getName()
/* 21:   */   {
/* 22:19 */     return this.name;
/* 23:   */   }
/* 24:   */   
/* 25:   */   public List getParameters()
/* 26:   */   {
/* 27:23 */     return this.parameters;
/* 28:   */   }
/* 29:   */   
/* 30:   */   public String getType()
/* 31:   */   {
/* 32:27 */     return this.type;
/* 33:   */   }
/* 34:   */   
/* 35:   */   public void setName(String string)
/* 36:   */   {
/* 37:31 */     this.name = string;
/* 38:   */   }
/* 39:   */   
/* 40:   */   public void setParameters(List list)
/* 41:   */   {
/* 42:35 */     this.parameters = list;
/* 43:   */   }
/* 44:   */   
/* 45:   */   public void setType(String string)
/* 46:   */   {
/* 47:39 */     this.type = string;
/* 48:   */   }
/* 49:   */   
/* 50:   */   public String toString()
/* 51:   */   {
/* 52:43 */     String sql = "DROP " + this.type + " " + this.name;
/* 53:45 */     if ((this.parameters != null) && (this.parameters.size() > 0)) {
/* 54:46 */       sql = sql + " " + PlainSelect.getStringList(this.parameters);
/* 55:   */     }
/* 56:49 */     return sql;
/* 57:   */   }
/* 58:   */ }


/* Location:           E:\workspace\java\db\lib\jsqlparser.jar
 * Qualified Name:     net.sf.jsqlparser.statement.drop.Drop
 * JD-Core Version:    0.7.0.1
 */