/*  1:   */ package net.sf.jsqlparser.statement.delete;
/*  2:   */ 
/*  3:   */ import net.sf.jsqlparser.expression.Expression;
/*  4:   */ import net.sf.jsqlparser.schema.Table;
/*  5:   */ import net.sf.jsqlparser.statement.Statement;
/*  6:   */ import net.sf.jsqlparser.statement.StatementVisitor;
/*  7:   */ 
/*  8:   */ public class Delete
/*  9:   */   implements Statement
/* 10:   */ {
/* 11:   */   private Table table;
/* 12:   */   private Expression where;
/* 13:   */   
/* 14:   */   public void accept(StatementVisitor statementVisitor)
/* 15:   */   {
/* 16:35 */     statementVisitor.visit(this);
/* 17:   */   }
/* 18:   */   
/* 19:   */   public Table getTable()
/* 20:   */   {
/* 21:39 */     return this.table;
/* 22:   */   }
/* 23:   */   
/* 24:   */   public Expression getWhere()
/* 25:   */   {
/* 26:43 */     return this.where;
/* 27:   */   }
/* 28:   */   
/* 29:   */   public void setTable(Table name)
/* 30:   */   {
/* 31:47 */     this.table = name;
/* 32:   */   }
/* 33:   */   
/* 34:   */   public void setWhere(Expression expression)
/* 35:   */   {
/* 36:51 */     this.where = expression;
/* 37:   */   }
/* 38:   */   
/* 39:   */   public String toString()
/* 40:   */   {
/* 41:55 */     return "DELETE FROM " + this.table + (this.where != null ? " WHERE " + this.where : "");
/* 42:   */   }
/* 43:   */ }


/* Location:           E:\workspace\java\db\lib\jsqlparser.jar
 * Qualified Name:     net.sf.jsqlparser.statement.delete.Delete
 * JD-Core Version:    0.7.0.1
 */