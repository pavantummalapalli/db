/*  1:   */ package net.sf.jsqlparser.statement.select;
/*  2:   */ 
/*  3:   */ import net.sf.jsqlparser.expression.Expression;
/*  4:   */ 
/*  5:   */ public class OrderByElement
/*  6:   */ {
/*  7:   */   private Expression expression;
/*  8:33 */   private boolean asc = true;
/*  9:   */   
/* 10:   */   public boolean isAsc()
/* 11:   */   {
/* 12:37 */     return this.asc;
/* 13:   */   }
/* 14:   */   
/* 15:   */   public void setAsc(boolean b)
/* 16:   */   {
/* 17:41 */     this.asc = b;
/* 18:   */   }
/* 19:   */   
/* 20:   */   public void accept(OrderByVisitor orderByVisitor)
/* 21:   */   {
/* 22:46 */     orderByVisitor.visit(this);
/* 23:   */   }
/* 24:   */   
/* 25:   */   public Expression getExpression()
/* 26:   */   {
/* 27:50 */     return this.expression;
/* 28:   */   }
/* 29:   */   
/* 30:   */   public void setExpression(Expression expression)
/* 31:   */   {
/* 32:54 */     this.expression = expression;
/* 33:   */   }
/* 34:   */   
/* 35:   */   public String toString()
/* 36:   */   {
/* 37:58 */     return "" + this.expression + (this.asc ? "" : " DESC");
/* 38:   */   }
/* 39:   */ }


/* Location:           E:\workspace\java\db\lib\jsqlparser.jar
 * Qualified Name:     net.sf.jsqlparser.statement.select.OrderByElement
 * JD-Core Version:    0.7.0.1
 */