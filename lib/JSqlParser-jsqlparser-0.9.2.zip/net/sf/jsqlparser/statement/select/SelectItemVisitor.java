package net.sf.jsqlparser.statement.select;

public abstract interface SelectItemVisitor
{
  public abstract void visit(AllColumns paramAllColumns);
  
  public abstract void visit(AllTableColumns paramAllTableColumns);
  
  public abstract void visit(SelectExpressionItem paramSelectExpressionItem);
}


/* Location:           E:\workspace\java\db\lib\jsqlparser.jar
 * Qualified Name:     net.sf.jsqlparser.statement.select.SelectItemVisitor
 * JD-Core Version:    0.7.0.1
 */