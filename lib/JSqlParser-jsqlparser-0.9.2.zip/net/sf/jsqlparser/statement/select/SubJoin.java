/*  1:   */ package net.sf.jsqlparser.statement.select;
/*  2:   */ 
/*  3:   */ public class SubJoin
/*  4:   */   implements FromItem
/*  5:   */ {
/*  6:   */   private FromItem left;
/*  7:   */   private Join join;
/*  8:   */   private String alias;
/*  9:   */   
/* 10:   */   public void accept(FromItemVisitor fromItemVisitor)
/* 11:   */   {
/* 12:35 */     fromItemVisitor.visit(this);
/* 13:   */   }
/* 14:   */   
/* 15:   */   public FromItem getLeft()
/* 16:   */   {
/* 17:39 */     return this.left;
/* 18:   */   }
/* 19:   */   
/* 20:   */   public void setLeft(FromItem l)
/* 21:   */   {
/* 22:43 */     this.left = l;
/* 23:   */   }
/* 24:   */   
/* 25:   */   public Join getJoin()
/* 26:   */   {
/* 27:47 */     return this.join;
/* 28:   */   }
/* 29:   */   
/* 30:   */   public void setJoin(Join j)
/* 31:   */   {
/* 32:51 */     this.join = j;
/* 33:   */   }
/* 34:   */   
/* 35:   */   public String getAlias()
/* 36:   */   {
/* 37:55 */     return this.alias;
/* 38:   */   }
/* 39:   */   
/* 40:   */   public void setAlias(String string)
/* 41:   */   {
/* 42:59 */     this.alias = string;
/* 43:   */   }
/* 44:   */   
/* 45:   */   public String toString()
/* 46:   */   {
/* 47:63 */     return "(" + this.left + " " + this.join + ")" + (this.alias != null ? " AS " + this.alias : "");
/* 48:   */   }
/* 49:   */ }


/* Location:           E:\workspace\java\db\lib\jsqlparser.jar
 * Qualified Name:     net.sf.jsqlparser.statement.select.SubJoin
 * JD-Core Version:    0.7.0.1
 */