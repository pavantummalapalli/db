/*  1:   */ package net.sf.jsqlparser.statement.select;
/*  2:   */ 
/*  3:   */ import java.util.List;
/*  4:   */ 
/*  5:   */ public class WithItem
/*  6:   */ {
/*  7:   */   private String name;
/*  8:   */   private List withItemList;
/*  9:   */   private SelectBody selectBody;
/* 10:   */   
/* 11:   */   public String getName()
/* 12:   */   {
/* 13:18 */     return this.name;
/* 14:   */   }
/* 15:   */   
/* 16:   */   public void setName(String name)
/* 17:   */   {
/* 18:21 */     this.name = name;
/* 19:   */   }
/* 20:   */   
/* 21:   */   public SelectBody getSelectBody()
/* 22:   */   {
/* 23:29 */     return this.selectBody;
/* 24:   */   }
/* 25:   */   
/* 26:   */   public void setSelectBody(SelectBody selectBody)
/* 27:   */   {
/* 28:32 */     this.selectBody = selectBody;
/* 29:   */   }
/* 30:   */   
/* 31:   */   public List getWithItemList()
/* 32:   */   {
/* 33:40 */     return this.withItemList;
/* 34:   */   }
/* 35:   */   
/* 36:   */   public void setWithItemList(List withItemList)
/* 37:   */   {
/* 38:43 */     this.withItemList = withItemList;
/* 39:   */   }
/* 40:   */   
/* 41:   */   public String toString()
/* 42:   */   {
/* 43:47 */     return this.name + (this.withItemList != null ? " " + PlainSelect.getStringList(this.withItemList, true, true) : "") + " AS (" + this.selectBody + ")";
/* 44:   */   }
/* 45:   */ }


/* Location:           E:\workspace\java\db\lib\jsqlparser.jar
 * Qualified Name:     net.sf.jsqlparser.statement.select.WithItem
 * JD-Core Version:    0.7.0.1
 */