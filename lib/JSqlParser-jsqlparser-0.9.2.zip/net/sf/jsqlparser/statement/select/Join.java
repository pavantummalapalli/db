/*   1:    */ package net.sf.jsqlparser.statement.select;
/*   2:    */ 
/*   3:    */ import java.util.List;
/*   4:    */ import net.sf.jsqlparser.expression.Expression;
/*   5:    */ 
/*   6:    */ public class Join
/*   7:    */ {
/*   8: 33 */   private boolean outer = false;
/*   9: 34 */   private boolean right = false;
/*  10: 35 */   private boolean left = false;
/*  11: 36 */   private boolean natural = false;
/*  12: 37 */   private boolean full = false;
/*  13: 38 */   private boolean inner = false;
/*  14: 39 */   private boolean simple = false;
/*  15:    */   private FromItem rightItem;
/*  16:    */   private Expression onExpression;
/*  17:    */   private List usingColumns;
/*  18:    */   
/*  19:    */   public boolean isSimple()
/*  20:    */   {
/*  21: 49 */     return this.simple;
/*  22:    */   }
/*  23:    */   
/*  24:    */   public void setSimple(boolean b)
/*  25:    */   {
/*  26: 53 */     this.simple = b;
/*  27:    */   }
/*  28:    */   
/*  29:    */   public boolean isInner()
/*  30:    */   {
/*  31: 60 */     return this.inner;
/*  32:    */   }
/*  33:    */   
/*  34:    */   public void setInner(boolean b)
/*  35:    */   {
/*  36: 64 */     this.inner = b;
/*  37:    */   }
/*  38:    */   
/*  39:    */   public boolean isOuter()
/*  40:    */   {
/*  41: 72 */     return this.outer;
/*  42:    */   }
/*  43:    */   
/*  44:    */   public void setOuter(boolean b)
/*  45:    */   {
/*  46: 76 */     this.outer = b;
/*  47:    */   }
/*  48:    */   
/*  49:    */   public boolean isLeft()
/*  50:    */   {
/*  51: 84 */     return this.left;
/*  52:    */   }
/*  53:    */   
/*  54:    */   public void setLeft(boolean b)
/*  55:    */   {
/*  56: 88 */     this.left = b;
/*  57:    */   }
/*  58:    */   
/*  59:    */   public boolean isRight()
/*  60:    */   {
/*  61: 96 */     return this.right;
/*  62:    */   }
/*  63:    */   
/*  64:    */   public void setRight(boolean b)
/*  65:    */   {
/*  66:100 */     this.right = b;
/*  67:    */   }
/*  68:    */   
/*  69:    */   public boolean isNatural()
/*  70:    */   {
/*  71:108 */     return this.natural;
/*  72:    */   }
/*  73:    */   
/*  74:    */   public void setNatural(boolean b)
/*  75:    */   {
/*  76:112 */     this.natural = b;
/*  77:    */   }
/*  78:    */   
/*  79:    */   public boolean isFull()
/*  80:    */   {
/*  81:120 */     return this.full;
/*  82:    */   }
/*  83:    */   
/*  84:    */   public void setFull(boolean b)
/*  85:    */   {
/*  86:124 */     this.full = b;
/*  87:    */   }
/*  88:    */   
/*  89:    */   public FromItem getRightItem()
/*  90:    */   {
/*  91:131 */     return this.rightItem;
/*  92:    */   }
/*  93:    */   
/*  94:    */   public void setRightItem(FromItem item)
/*  95:    */   {
/*  96:135 */     this.rightItem = item;
/*  97:    */   }
/*  98:    */   
/*  99:    */   public Expression getOnExpression()
/* 100:    */   {
/* 101:142 */     return this.onExpression;
/* 102:    */   }
/* 103:    */   
/* 104:    */   public void setOnExpression(Expression expression)
/* 105:    */   {
/* 106:146 */     this.onExpression = expression;
/* 107:    */   }
/* 108:    */   
/* 109:    */   public List getUsingColumns()
/* 110:    */   {
/* 111:153 */     return this.usingColumns;
/* 112:    */   }
/* 113:    */   
/* 114:    */   public void setUsingColumns(List list)
/* 115:    */   {
/* 116:157 */     this.usingColumns = list;
/* 117:    */   }
/* 118:    */   
/* 119:    */   public String toString()
/* 120:    */   {
/* 121:161 */     if (isSimple()) {
/* 122:162 */       return "" + this.rightItem;
/* 123:    */     }
/* 124:165 */     String type = "";
/* 125:167 */     if (isRight()) {
/* 126:168 */       type = type + "RIGHT ";
/* 127:169 */     } else if (isNatural()) {
/* 128:170 */       type = type + "NATURAL ";
/* 129:171 */     } else if (isFull()) {
/* 130:172 */       type = type + "FULL ";
/* 131:173 */     } else if (isLeft()) {
/* 132:174 */       type = type + "LEFT ";
/* 133:    */     }
/* 134:176 */     if (isOuter()) {
/* 135:177 */       type = type + "OUTER ";
/* 136:178 */     } else if (isInner()) {
/* 137:179 */       type = type + "INNER ";
/* 138:    */     }
/* 139:184 */     return type + "JOIN " + this.rightItem + (this.onExpression != null ? " ON " + this.onExpression + "" : "") + PlainSelect.getFormatedList(this.usingColumns, "USING", true, true);
/* 140:    */   }
/* 141:    */ }


/* Location:           E:\workspace\java\db\lib\jsqlparser.jar
 * Qualified Name:     net.sf.jsqlparser.statement.select.Join
 * JD-Core Version:    0.7.0.1
 */