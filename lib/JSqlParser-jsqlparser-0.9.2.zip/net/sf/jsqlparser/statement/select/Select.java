/*  1:   */ package net.sf.jsqlparser.statement.select;
/*  2:   */ 
/*  3:   */ import java.util.Iterator;
/*  4:   */ import java.util.List;
/*  5:   */ import net.sf.jsqlparser.statement.Statement;
/*  6:   */ import net.sf.jsqlparser.statement.StatementVisitor;
/*  7:   */ 
/*  8:   */ public class Select
/*  9:   */   implements Statement
/* 10:   */ {
/* 11:   */   private SelectBody selectBody;
/* 12:   */   private List withItemsList;
/* 13:   */   
/* 14:   */   public void accept(StatementVisitor statementVisitor)
/* 15:   */   {
/* 16:36 */     statementVisitor.visit(this);
/* 17:   */   }
/* 18:   */   
/* 19:   */   public SelectBody getSelectBody()
/* 20:   */   {
/* 21:40 */     return this.selectBody;
/* 22:   */   }
/* 23:   */   
/* 24:   */   public void setSelectBody(SelectBody body)
/* 25:   */   {
/* 26:44 */     this.selectBody = body;
/* 27:   */   }
/* 28:   */   
/* 29:   */   public String toString()
/* 30:   */   {
/* 31:48 */     StringBuffer retval = new StringBuffer();
/* 32:   */     Iterator iter;
/* 33:49 */     if ((this.withItemsList != null) && (!this.withItemsList.isEmpty()))
/* 34:   */     {
/* 35:50 */       retval.append("WITH ");
/* 36:51 */       for (iter = this.withItemsList.iterator(); iter.hasNext();)
/* 37:   */       {
/* 38:52 */         WithItem withItem = (WithItem)iter.next();
/* 39:53 */         retval.append(withItem);
/* 40:54 */         if (iter.hasNext()) {
/* 41:55 */           retval.append(",");
/* 42:   */         }
/* 43:56 */         retval.append(" ");
/* 44:   */       }
/* 45:   */     }
/* 46:59 */     retval.append(this.selectBody);
/* 47:60 */     return retval.toString();
/* 48:   */   }
/* 49:   */   
/* 50:   */   public List getWithItemsList()
/* 51:   */   {
/* 52:64 */     return this.withItemsList;
/* 53:   */   }
/* 54:   */   
/* 55:   */   public void setWithItemsList(List withItemsList)
/* 56:   */   {
/* 57:68 */     this.withItemsList = withItemsList;
/* 58:   */   }
/* 59:   */ }


/* Location:           E:\workspace\java\db\lib\jsqlparser.jar
 * Qualified Name:     net.sf.jsqlparser.statement.select.Select
 * JD-Core Version:    0.7.0.1
 */