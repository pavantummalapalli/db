/*  1:   */ package net.sf.jsqlparser.statement.select;
/*  2:   */ 
/*  3:   */ import net.sf.jsqlparser.expression.Expression;
/*  4:   */ 
/*  5:   */ public class SelectExpressionItem
/*  6:   */   implements SelectItem
/*  7:   */ {
/*  8:   */   private Expression expression;
/*  9:   */   private String alias;
/* 10:   */   
/* 11:   */   public String getAlias()
/* 12:   */   {
/* 13:36 */     return this.alias;
/* 14:   */   }
/* 15:   */   
/* 16:   */   public Expression getExpression()
/* 17:   */   {
/* 18:40 */     return this.expression;
/* 19:   */   }
/* 20:   */   
/* 21:   */   public void setAlias(String string)
/* 22:   */   {
/* 23:44 */     this.alias = string;
/* 24:   */   }
/* 25:   */   
/* 26:   */   public void setExpression(Expression expression)
/* 27:   */   {
/* 28:48 */     this.expression = expression;
/* 29:   */   }
/* 30:   */   
/* 31:   */   public void accept(SelectItemVisitor selectItemVisitor)
/* 32:   */   {
/* 33:52 */     selectItemVisitor.visit(this);
/* 34:   */   }
/* 35:   */   
/* 36:   */   public String toString()
/* 37:   */   {
/* 38:56 */     return this.expression + (this.alias != null ? " AS " + this.alias : "");
/* 39:   */   }
/* 40:   */ }


/* Location:           E:\workspace\java\db\lib\jsqlparser.jar
 * Qualified Name:     net.sf.jsqlparser.statement.select.SelectExpressionItem
 * JD-Core Version:    0.7.0.1
 */