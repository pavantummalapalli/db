package net.sf.jsqlparser.statement.select;

public abstract interface OrderByVisitor
{
  public abstract void visit(OrderByElement paramOrderByElement);
}


/* Location:           E:\workspace\java\db\lib\jsqlparser.jar
 * Qualified Name:     net.sf.jsqlparser.statement.select.OrderByVisitor
 * JD-Core Version:    0.7.0.1
 */