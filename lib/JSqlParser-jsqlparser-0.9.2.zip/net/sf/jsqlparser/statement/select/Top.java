/*  1:   */ package net.sf.jsqlparser.statement.select;
/*  2:   */ 
/*  3:   */ public class Top
/*  4:   */ {
/*  5:   */   private long rowCount;
/*  6: 8 */   private boolean rowCountJdbcParameter = false;
/*  7:   */   
/*  8:   */   public long getRowCount()
/*  9:   */   {
/* 10:11 */     return this.rowCount;
/* 11:   */   }
/* 12:   */   
/* 13:   */   public void setRowCount(long l)
/* 14:   */   {
/* 15:16 */     this.rowCount = l;
/* 16:   */   }
/* 17:   */   
/* 18:   */   public boolean isRowCountJdbcParameter()
/* 19:   */   {
/* 20:20 */     return this.rowCountJdbcParameter;
/* 21:   */   }
/* 22:   */   
/* 23:   */   public void setRowCountJdbcParameter(boolean b)
/* 24:   */   {
/* 25:24 */     this.rowCountJdbcParameter = b;
/* 26:   */   }
/* 27:   */   
/* 28:   */   public String toString()
/* 29:   */   {
/* 30:28 */     return "TOP " + (this.rowCountJdbcParameter ? "?" : new StringBuilder().append(this.rowCount).append("").toString());
/* 31:   */   }
/* 32:   */ }


/* Location:           E:\workspace\java\db\lib\jsqlparser.jar
 * Qualified Name:     net.sf.jsqlparser.statement.select.Top
 * JD-Core Version:    0.7.0.1
 */