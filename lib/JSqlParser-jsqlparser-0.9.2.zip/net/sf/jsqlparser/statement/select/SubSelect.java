/*  1:   */ package net.sf.jsqlparser.statement.select;
/*  2:   */ 
/*  3:   */ import net.sf.jsqlparser.expression.Expression;
/*  4:   */ import net.sf.jsqlparser.expression.ExpressionVisitor;
/*  5:   */ import net.sf.jsqlparser.expression.operators.relational.ItemsList;
/*  6:   */ import net.sf.jsqlparser.expression.operators.relational.ItemsListVisitor;
/*  7:   */ 
/*  8:   */ public class SubSelect
/*  9:   */   implements FromItem, Expression, ItemsList
/* 10:   */ {
/* 11:   */   private SelectBody selectBody;
/* 12:   */   private String alias;
/* 13:   */   
/* 14:   */   public void accept(FromItemVisitor fromItemVisitor)
/* 15:   */   {
/* 16:39 */     fromItemVisitor.visit(this);
/* 17:   */   }
/* 18:   */   
/* 19:   */   public SelectBody getSelectBody()
/* 20:   */   {
/* 21:43 */     return this.selectBody;
/* 22:   */   }
/* 23:   */   
/* 24:   */   public void setSelectBody(SelectBody body)
/* 25:   */   {
/* 26:47 */     this.selectBody = body;
/* 27:   */   }
/* 28:   */   
/* 29:   */   public void accept(ExpressionVisitor expressionVisitor)
/* 30:   */   {
/* 31:51 */     expressionVisitor.visit(this);
/* 32:   */   }
/* 33:   */   
/* 34:   */   public String getAlias()
/* 35:   */   {
/* 36:55 */     return this.alias;
/* 37:   */   }
/* 38:   */   
/* 39:   */   public void setAlias(String string)
/* 40:   */   {
/* 41:59 */     this.alias = string;
/* 42:   */   }
/* 43:   */   
/* 44:   */   public void accept(ItemsListVisitor itemsListVisitor)
/* 45:   */   {
/* 46:63 */     itemsListVisitor.visit(this);
/* 47:   */   }
/* 48:   */   
/* 49:   */   public String toString()
/* 50:   */   {
/* 51:67 */     return "(" + this.selectBody + ")" + (this.alias != null ? " " + this.alias : "");
/* 52:   */   }
/* 53:   */ }


/* Location:           E:\workspace\java\db\lib\jsqlparser.jar
 * Qualified Name:     net.sf.jsqlparser.statement.select.SubSelect
 * JD-Core Version:    0.7.0.1
 */