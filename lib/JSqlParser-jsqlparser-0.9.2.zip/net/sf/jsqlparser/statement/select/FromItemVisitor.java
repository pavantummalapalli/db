package net.sf.jsqlparser.statement.select;

import net.sf.jsqlparser.schema.Table;

public abstract interface FromItemVisitor
{
  public abstract void visit(Table paramTable);
  
  public abstract void visit(SubSelect paramSubSelect);
  
  public abstract void visit(SubJoin paramSubJoin);
}


/* Location:           E:\workspace\java\db\lib\jsqlparser.jar
 * Qualified Name:     net.sf.jsqlparser.statement.select.FromItemVisitor
 * JD-Core Version:    0.7.0.1
 */