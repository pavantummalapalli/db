/*  1:   */ package net.sf.jsqlparser.statement.select;
/*  2:   */ 
/*  3:   */ public class Limit
/*  4:   */ {
/*  5:   */   private long offset;
/*  6:   */   private long rowCount;
/*  7: 9 */   private boolean rowCountJdbcParameter = false;
/*  8:10 */   private boolean offsetJdbcParameter = false;
/*  9:   */   private boolean limitAll;
/* 10:   */   
/* 11:   */   public long getOffset()
/* 12:   */   {
/* 13:14 */     return this.offset;
/* 14:   */   }
/* 15:   */   
/* 16:   */   public long getRowCount()
/* 17:   */   {
/* 18:18 */     return this.rowCount;
/* 19:   */   }
/* 20:   */   
/* 21:   */   public void setOffset(long l)
/* 22:   */   {
/* 23:22 */     this.offset = l;
/* 24:   */   }
/* 25:   */   
/* 26:   */   public void setRowCount(long l)
/* 27:   */   {
/* 28:26 */     this.rowCount = l;
/* 29:   */   }
/* 30:   */   
/* 31:   */   public boolean isOffsetJdbcParameter()
/* 32:   */   {
/* 33:30 */     return this.offsetJdbcParameter;
/* 34:   */   }
/* 35:   */   
/* 36:   */   public boolean isRowCountJdbcParameter()
/* 37:   */   {
/* 38:34 */     return this.rowCountJdbcParameter;
/* 39:   */   }
/* 40:   */   
/* 41:   */   public void setOffsetJdbcParameter(boolean b)
/* 42:   */   {
/* 43:38 */     this.offsetJdbcParameter = b;
/* 44:   */   }
/* 45:   */   
/* 46:   */   public void setRowCountJdbcParameter(boolean b)
/* 47:   */   {
/* 48:42 */     this.rowCountJdbcParameter = b;
/* 49:   */   }
/* 50:   */   
/* 51:   */   public boolean isLimitAll()
/* 52:   */   {
/* 53:50 */     return this.limitAll;
/* 54:   */   }
/* 55:   */   
/* 56:   */   public void setLimitAll(boolean b)
/* 57:   */   {
/* 58:54 */     this.limitAll = b;
/* 59:   */   }
/* 60:   */   
/* 61:   */   public String toString()
/* 62:   */   {
/* 63:58 */     String retVal = "";
/* 64:59 */     if ((this.rowCount > 0L) || (this.rowCountJdbcParameter)) {
/* 65:60 */       retVal = retVal + " LIMIT " + (this.rowCountJdbcParameter ? "?" : new StringBuilder().append(this.rowCount).append("").toString());
/* 66:   */     }
/* 67:62 */     if ((this.offset > 0L) || (this.offsetJdbcParameter)) {
/* 68:63 */       retVal = retVal + " OFFSET " + (this.offsetJdbcParameter ? "?" : new StringBuilder().append(this.offset).append("").toString());
/* 69:   */     }
/* 70:65 */     return retVal;
/* 71:   */   }
/* 72:   */ }


/* Location:           E:\workspace\java\db\lib\jsqlparser.jar
 * Qualified Name:     net.sf.jsqlparser.statement.select.Limit
 * JD-Core Version:    0.7.0.1
 */