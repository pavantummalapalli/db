/*   1:    */ package net.sf.jsqlparser.statement.select;
/*   2:    */ 
/*   3:    */ import java.util.List;
/*   4:    */ 
/*   5:    */ public class Union
/*   6:    */   implements SelectBody
/*   7:    */ {
/*   8:    */   private List plainSelects;
/*   9:    */   private List orderByElements;
/*  10:    */   private Limit limit;
/*  11:    */   private boolean distinct;
/*  12:    */   private boolean all;
/*  13:    */   
/*  14:    */   public void accept(SelectVisitor selectVisitor)
/*  15:    */   {
/*  16: 39 */     selectVisitor.visit(this);
/*  17:    */   }
/*  18:    */   
/*  19:    */   public List getOrderByElements()
/*  20:    */   {
/*  21: 43 */     return this.orderByElements;
/*  22:    */   }
/*  23:    */   
/*  24:    */   public List getPlainSelects()
/*  25:    */   {
/*  26: 51 */     return this.plainSelects;
/*  27:    */   }
/*  28:    */   
/*  29:    */   public void setOrderByElements(List orderByElements)
/*  30:    */   {
/*  31: 55 */     this.orderByElements = orderByElements;
/*  32:    */   }
/*  33:    */   
/*  34:    */   public void setPlainSelects(List list)
/*  35:    */   {
/*  36: 59 */     this.plainSelects = list;
/*  37:    */   }
/*  38:    */   
/*  39:    */   public Limit getLimit()
/*  40:    */   {
/*  41: 63 */     return this.limit;
/*  42:    */   }
/*  43:    */   
/*  44:    */   public void setLimit(Limit limit)
/*  45:    */   {
/*  46: 67 */     this.limit = limit;
/*  47:    */   }
/*  48:    */   
/*  49:    */   public boolean isAll()
/*  50:    */   {
/*  51: 74 */     return this.all;
/*  52:    */   }
/*  53:    */   
/*  54:    */   public void setAll(boolean all)
/*  55:    */   {
/*  56: 78 */     this.all = all;
/*  57:    */   }
/*  58:    */   
/*  59:    */   public boolean isDistinct()
/*  60:    */   {
/*  61: 85 */     return this.distinct;
/*  62:    */   }
/*  63:    */   
/*  64:    */   public void setDistinct(boolean distinct)
/*  65:    */   {
/*  66: 89 */     this.distinct = distinct;
/*  67:    */   }
/*  68:    */   
/*  69:    */   public String toString()
/*  70:    */   {
/*  71: 94 */     String selects = "";
/*  72: 95 */     String allDistinct = "";
/*  73: 96 */     if (isAll()) {
/*  74: 97 */       allDistinct = "ALL ";
/*  75: 98 */     } else if (isDistinct()) {
/*  76: 99 */       allDistinct = "DISTINCT ";
/*  77:    */     }
/*  78:102 */     for (int i = 0; i < this.plainSelects.size(); i++) {
/*  79:103 */       selects = selects + "(" + this.plainSelects.get(i) + (i < this.plainSelects.size() - 1 ? ") UNION " + allDistinct : ")");
/*  80:    */     }
/*  81:107 */     return selects + (this.orderByElements != null ? PlainSelect.orderByToString(this.orderByElements) : "") + (this.limit != null ? this.limit + "" : "");
/*  82:    */   }
/*  83:    */ }


/* Location:           E:\workspace\java\db\lib\jsqlparser.jar
 * Qualified Name:     net.sf.jsqlparser.statement.select.Union
 * JD-Core Version:    0.7.0.1
 */