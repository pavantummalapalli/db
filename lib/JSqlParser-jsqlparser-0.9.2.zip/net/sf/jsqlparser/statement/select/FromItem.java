package net.sf.jsqlparser.statement.select;

public abstract interface FromItem
{
  public abstract void accept(FromItemVisitor paramFromItemVisitor);
  
  public abstract String getAlias();
  
  public abstract void setAlias(String paramString);
}


/* Location:           E:\workspace\java\db\lib\jsqlparser.jar
 * Qualified Name:     net.sf.jsqlparser.statement.select.FromItem
 * JD-Core Version:    0.7.0.1
 */