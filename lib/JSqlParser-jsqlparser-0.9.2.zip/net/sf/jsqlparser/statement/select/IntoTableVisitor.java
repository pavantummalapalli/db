package net.sf.jsqlparser.statement.select;

import net.sf.jsqlparser.schema.Table;

public abstract interface IntoTableVisitor
{
  public abstract void visit(Table paramTable);
}


/* Location:           E:\workspace\java\db\lib\jsqlparser.jar
 * Qualified Name:     net.sf.jsqlparser.statement.select.IntoTableVisitor
 * JD-Core Version:    0.7.0.1
 */