/*   1:    */ package net.sf.jsqlparser.statement.select;
/*   2:    */ 
/*   3:    */ import java.util.Iterator;
/*   4:    */ import java.util.List;
/*   5:    */ import net.sf.jsqlparser.expression.Expression;
/*   6:    */ import net.sf.jsqlparser.schema.Table;
/*   7:    */ 
/*   8:    */ public class PlainSelect
/*   9:    */   implements SelectBody
/*  10:    */ {
/*  11: 37 */   private Distinct distinct = null;
/*  12:    */   private List selectItems;
/*  13:    */   private Table into;
/*  14:    */   private FromItem fromItem;
/*  15:    */   private List joins;
/*  16:    */   private Expression where;
/*  17:    */   private List groupByColumnReferences;
/*  18:    */   private List orderByElements;
/*  19:    */   private Expression having;
/*  20:    */   private Limit limit;
/*  21:    */   private Top top;
/*  22:    */   
/*  23:    */   public FromItem getFromItem()
/*  24:    */   {
/*  25: 56 */     return this.fromItem;
/*  26:    */   }
/*  27:    */   
/*  28:    */   public Table getInto()
/*  29:    */   {
/*  30: 60 */     return this.into;
/*  31:    */   }
/*  32:    */   
/*  33:    */   public List getSelectItems()
/*  34:    */   {
/*  35: 68 */     return this.selectItems;
/*  36:    */   }
/*  37:    */   
/*  38:    */   public Expression getWhere()
/*  39:    */   {
/*  40: 72 */     return this.where;
/*  41:    */   }
/*  42:    */   
/*  43:    */   public void setFromItem(FromItem item)
/*  44:    */   {
/*  45: 76 */     this.fromItem = item;
/*  46:    */   }
/*  47:    */   
/*  48:    */   public void setInto(Table table)
/*  49:    */   {
/*  50: 80 */     this.into = table;
/*  51:    */   }
/*  52:    */   
/*  53:    */   public void setSelectItems(List list)
/*  54:    */   {
/*  55: 85 */     this.selectItems = list;
/*  56:    */   }
/*  57:    */   
/*  58:    */   public void setWhere(Expression where)
/*  59:    */   {
/*  60: 89 */     this.where = where;
/*  61:    */   }
/*  62:    */   
/*  63:    */   public List getJoins()
/*  64:    */   {
/*  65: 98 */     return this.joins;
/*  66:    */   }
/*  67:    */   
/*  68:    */   public void setJoins(List list)
/*  69:    */   {
/*  70:102 */     this.joins = list;
/*  71:    */   }
/*  72:    */   
/*  73:    */   public void accept(SelectVisitor selectVisitor)
/*  74:    */   {
/*  75:106 */     selectVisitor.visit(this);
/*  76:    */   }
/*  77:    */   
/*  78:    */   public List getOrderByElements()
/*  79:    */   {
/*  80:110 */     return this.orderByElements;
/*  81:    */   }
/*  82:    */   
/*  83:    */   public void setOrderByElements(List orderByElements)
/*  84:    */   {
/*  85:114 */     this.orderByElements = orderByElements;
/*  86:    */   }
/*  87:    */   
/*  88:    */   public Limit getLimit()
/*  89:    */   {
/*  90:118 */     return this.limit;
/*  91:    */   }
/*  92:    */   
/*  93:    */   public void setLimit(Limit limit)
/*  94:    */   {
/*  95:122 */     this.limit = limit;
/*  96:    */   }
/*  97:    */   
/*  98:    */   public Top getTop()
/*  99:    */   {
/* 100:126 */     return this.top;
/* 101:    */   }
/* 102:    */   
/* 103:    */   public void setTop(Top top)
/* 104:    */   {
/* 105:130 */     this.top = top;
/* 106:    */   }
/* 107:    */   
/* 108:    */   public Distinct getDistinct()
/* 109:    */   {
/* 110:134 */     return this.distinct;
/* 111:    */   }
/* 112:    */   
/* 113:    */   public void setDistinct(Distinct distinct)
/* 114:    */   {
/* 115:138 */     this.distinct = distinct;
/* 116:    */   }
/* 117:    */   
/* 118:    */   public Expression getHaving()
/* 119:    */   {
/* 120:142 */     return this.having;
/* 121:    */   }
/* 122:    */   
/* 123:    */   public void setHaving(Expression expression)
/* 124:    */   {
/* 125:146 */     this.having = expression;
/* 126:    */   }
/* 127:    */   
/* 128:    */   public List getGroupByColumnReferences()
/* 129:    */   {
/* 130:155 */     return this.groupByColumnReferences;
/* 131:    */   }
/* 132:    */   
/* 133:    */   public void setGroupByColumnReferences(List list)
/* 134:    */   {
/* 135:159 */     this.groupByColumnReferences = list;
/* 136:    */   }
/* 137:    */   
/* 138:    */   public String toString()
/* 139:    */   {
/* 140:163 */     String sql = "";
/* 141:    */     
/* 142:165 */     sql = "SELECT ";
/* 143:166 */     sql = sql + (this.distinct != null ? "" + this.distinct + " " : "");
/* 144:167 */     sql = sql + (this.top != null ? "" + this.top + " " : "");
/* 145:168 */     sql = sql + getStringList(this.selectItems);
/* 146:169 */     sql = sql + " FROM " + this.fromItem;
/* 147:170 */     if (this.joins != null)
/* 148:    */     {
/* 149:171 */       Iterator it = this.joins.iterator();
/* 150:172 */       while (it.hasNext())
/* 151:    */       {
/* 152:173 */         Join join = (Join)it.next();
/* 153:174 */         if (join.isSimple()) {
/* 154:175 */           sql = sql + ", " + join;
/* 155:    */         } else {
/* 156:178 */           sql = sql + " " + join;
/* 157:    */         }
/* 158:    */       }
/* 159:    */     }
/* 160:183 */     sql = sql + (this.where != null ? " WHERE " + this.where : "");
/* 161:184 */     sql = sql + getFormatedList(this.groupByColumnReferences, "GROUP BY");
/* 162:185 */     sql = sql + (this.having != null ? " HAVING " + this.having : "");
/* 163:186 */     sql = sql + orderByToString(this.orderByElements);
/* 164:187 */     sql = sql + (this.limit != null ? this.limit + "" : "");
/* 165:    */     
/* 166:189 */     return sql;
/* 167:    */   }
/* 168:    */   
/* 169:    */   public static String orderByToString(List orderByElements)
/* 170:    */   {
/* 171:194 */     return getFormatedList(orderByElements, "ORDER BY");
/* 172:    */   }
/* 173:    */   
/* 174:    */   public static String getFormatedList(List list, String expression)
/* 175:    */   {
/* 176:199 */     return getFormatedList(list, expression, true, false);
/* 177:    */   }
/* 178:    */   
/* 179:    */   public static String getFormatedList(List list, String expression, boolean useComma, boolean useBrackets)
/* 180:    */   {
/* 181:204 */     String sql = getStringList(list, useComma, useBrackets);
/* 182:206 */     if (sql.length() > 0) {
/* 183:207 */       if (expression.length() > 0) {
/* 184:208 */         sql = " " + expression + " " + sql;
/* 185:    */       } else {
/* 186:210 */         sql = " " + sql;
/* 187:    */       }
/* 188:    */     }
/* 189:214 */     return sql;
/* 190:    */   }
/* 191:    */   
/* 192:    */   public static String getStringList(List list)
/* 193:    */   {
/* 194:228 */     return getStringList(list, true, false);
/* 195:    */   }
/* 196:    */   
/* 197:    */   public static String getStringList(List list, boolean useComma, boolean useBrackets)
/* 198:    */   {
/* 199:241 */     String ans = "";
/* 200:242 */     String comma = ",";
/* 201:243 */     if (!useComma) {
/* 202:244 */       comma = "";
/* 203:    */     }
/* 204:246 */     if (list != null)
/* 205:    */     {
/* 206:247 */       if (useBrackets) {
/* 207:248 */         ans = ans + "(";
/* 208:    */       }
/* 209:251 */       for (int i = 0; i < list.size(); i++) {
/* 210:252 */         ans = ans + "" + list.get(i) + (i < list.size() - 1 ? comma + " " : "");
/* 211:    */       }
/* 212:255 */       if (useBrackets) {
/* 213:256 */         ans = ans + ")";
/* 214:    */       }
/* 215:    */     }
/* 216:260 */     return ans;
/* 217:    */   }
/* 218:    */ }


/* Location:           E:\workspace\java\db\lib\jsqlparser.jar
 * Qualified Name:     net.sf.jsqlparser.statement.select.PlainSelect
 * JD-Core Version:    0.7.0.1
 */