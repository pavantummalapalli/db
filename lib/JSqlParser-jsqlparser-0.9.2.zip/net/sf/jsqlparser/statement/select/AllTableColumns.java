/*  1:   */ package net.sf.jsqlparser.statement.select;
/*  2:   */ 
/*  3:   */ import net.sf.jsqlparser.schema.Table;
/*  4:   */ 
/*  5:   */ public class AllTableColumns
/*  6:   */   implements SelectItem
/*  7:   */ {
/*  8:   */   private Table table;
/*  9:   */   
/* 10:   */   public AllTableColumns() {}
/* 11:   */   
/* 12:   */   public AllTableColumns(Table tableName)
/* 13:   */   {
/* 14:37 */     this.table = tableName;
/* 15:   */   }
/* 16:   */   
/* 17:   */   public Table getTable()
/* 18:   */   {
/* 19:42 */     return this.table;
/* 20:   */   }
/* 21:   */   
/* 22:   */   public void setTable(Table table)
/* 23:   */   {
/* 24:46 */     this.table = table;
/* 25:   */   }
/* 26:   */   
/* 27:   */   public void accept(SelectItemVisitor selectItemVisitor)
/* 28:   */   {
/* 29:50 */     selectItemVisitor.visit(this);
/* 30:   */   }
/* 31:   */   
/* 32:   */   public String toString()
/* 33:   */   {
/* 34:54 */     return this.table + ".*";
/* 35:   */   }
/* 36:   */ }


/* Location:           E:\workspace\java\db\lib\jsqlparser.jar
 * Qualified Name:     net.sf.jsqlparser.statement.select.AllTableColumns
 * JD-Core Version:    0.7.0.1
 */