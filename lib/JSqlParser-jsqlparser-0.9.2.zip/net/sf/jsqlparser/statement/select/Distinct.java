/*  1:   */ package net.sf.jsqlparser.statement.select;
/*  2:   */ 
/*  3:   */ import java.util.List;
/*  4:   */ 
/*  5:   */ public class Distinct
/*  6:   */ {
/*  7:   */   private List onSelectItems;
/*  8:   */   
/*  9:   */   public List getOnSelectItems()
/* 10:   */   {
/* 11:16 */     return this.onSelectItems;
/* 12:   */   }
/* 13:   */   
/* 14:   */   public void setOnSelectItems(List list)
/* 15:   */   {
/* 16:20 */     this.onSelectItems = list;
/* 17:   */   }
/* 18:   */   
/* 19:   */   public String toString()
/* 20:   */   {
/* 21:24 */     String sql = "DISTINCT";
/* 22:26 */     if ((this.onSelectItems != null) && (this.onSelectItems.size() > 0)) {
/* 23:27 */       sql = sql + " ON (" + PlainSelect.getStringList(this.onSelectItems) + ")";
/* 24:   */     }
/* 25:30 */     return sql;
/* 26:   */   }
/* 27:   */ }


/* Location:           E:\workspace\java\db\lib\jsqlparser.jar
 * Qualified Name:     net.sf.jsqlparser.statement.select.Distinct
 * JD-Core Version:    0.7.0.1
 */