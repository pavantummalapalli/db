/*  1:   */ package net.sf.jsqlparser.statement.select;
/*  2:   */ 
/*  3:   */ public class AllColumns
/*  4:   */   implements SelectItem
/*  5:   */ {
/*  6:   */   public void accept(SelectItemVisitor selectItemVisitor)
/*  7:   */   {
/*  8:31 */     selectItemVisitor.visit(this);
/*  9:   */   }
/* 10:   */   
/* 11:   */   public String toString()
/* 12:   */   {
/* 13:35 */     return "*";
/* 14:   */   }
/* 15:   */ }


/* Location:           E:\workspace\java\db\lib\jsqlparser.jar
 * Qualified Name:     net.sf.jsqlparser.statement.select.AllColumns
 * JD-Core Version:    0.7.0.1
 */