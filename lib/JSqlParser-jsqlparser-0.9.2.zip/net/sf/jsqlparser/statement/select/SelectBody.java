package net.sf.jsqlparser.statement.select;

public abstract interface SelectBody
{
  public abstract void accept(SelectVisitor paramSelectVisitor);
}


/* Location:           E:\workspace\java\db\lib\jsqlparser.jar
 * Qualified Name:     net.sf.jsqlparser.statement.select.SelectBody
 * JD-Core Version:    0.7.0.1
 */