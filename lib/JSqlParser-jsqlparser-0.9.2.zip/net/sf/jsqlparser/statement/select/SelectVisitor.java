package net.sf.jsqlparser.statement.select;

public abstract interface SelectVisitor
{
  public abstract void visit(PlainSelect paramPlainSelect);
  
  public abstract void visit(Union paramUnion);
}


/* Location:           E:\workspace\java\db\lib\jsqlparser.jar
 * Qualified Name:     net.sf.jsqlparser.statement.select.SelectVisitor
 * JD-Core Version:    0.7.0.1
 */