package net.sf.jsqlparser.statement.select;

public abstract interface SelectItem
{
  public abstract void accept(SelectItemVisitor paramSelectItemVisitor);
}


/* Location:           E:\workspace\java\db\lib\jsqlparser.jar
 * Qualified Name:     net.sf.jsqlparser.statement.select.SelectItem
 * JD-Core Version:    0.7.0.1
 */