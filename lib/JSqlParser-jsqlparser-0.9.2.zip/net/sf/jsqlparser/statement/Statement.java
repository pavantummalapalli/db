package net.sf.jsqlparser.statement;

public abstract interface Statement
{
  public abstract void accept(StatementVisitor paramStatementVisitor);
}


/* Location:           E:\workspace\java\db\lib\jsqlparser.jar
 * Qualified Name:     net.sf.jsqlparser.statement.Statement
 * JD-Core Version:    0.7.0.1
 */