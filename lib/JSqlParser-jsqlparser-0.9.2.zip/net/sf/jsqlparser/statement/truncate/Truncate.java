/*  1:   */ package net.sf.jsqlparser.statement.truncate;
/*  2:   */ 
/*  3:   */ import net.sf.jsqlparser.schema.Table;
/*  4:   */ import net.sf.jsqlparser.statement.Statement;
/*  5:   */ import net.sf.jsqlparser.statement.StatementVisitor;
/*  6:   */ 
/*  7:   */ public class Truncate
/*  8:   */   implements Statement
/*  9:   */ {
/* 10:   */   private Table table;
/* 11:   */   
/* 12:   */   public void accept(StatementVisitor statementVisitor)
/* 13:   */   {
/* 14:14 */     statementVisitor.visit(this);
/* 15:   */   }
/* 16:   */   
/* 17:   */   public Table getTable()
/* 18:   */   {
/* 19:18 */     return this.table;
/* 20:   */   }
/* 21:   */   
/* 22:   */   public void setTable(Table table)
/* 23:   */   {
/* 24:22 */     this.table = table;
/* 25:   */   }
/* 26:   */   
/* 27:   */   public String toString()
/* 28:   */   {
/* 29:26 */     return "TRUNCATE TABLE " + this.table;
/* 30:   */   }
/* 31:   */ }


/* Location:           E:\workspace\java\db\lib\jsqlparser.jar
 * Qualified Name:     net.sf.jsqlparser.statement.truncate.Truncate
 * JD-Core Version:    0.7.0.1
 */