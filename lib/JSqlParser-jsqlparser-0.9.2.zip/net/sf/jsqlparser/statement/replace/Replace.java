/*   1:    */ package net.sf.jsqlparser.statement.replace;
/*   2:    */ 
/*   3:    */ import java.util.List;
/*   4:    */ import net.sf.jsqlparser.expression.operators.relational.ItemsList;
/*   5:    */ import net.sf.jsqlparser.schema.Table;
/*   6:    */ import net.sf.jsqlparser.statement.Statement;
/*   7:    */ import net.sf.jsqlparser.statement.StatementVisitor;
/*   8:    */ import net.sf.jsqlparser.statement.select.PlainSelect;
/*   9:    */ 
/*  10:    */ public class Replace
/*  11:    */   implements Statement
/*  12:    */ {
/*  13:    */   private Table table;
/*  14:    */   private List columns;
/*  15:    */   private ItemsList itemsList;
/*  16:    */   private List expressions;
/*  17: 42 */   private boolean useValues = true;
/*  18:    */   
/*  19:    */   public void accept(StatementVisitor statementVisitor)
/*  20:    */   {
/*  21: 45 */     statementVisitor.visit(this);
/*  22:    */   }
/*  23:    */   
/*  24:    */   public Table getTable()
/*  25:    */   {
/*  26: 49 */     return this.table;
/*  27:    */   }
/*  28:    */   
/*  29:    */   public void setTable(Table name)
/*  30:    */   {
/*  31: 53 */     this.table = name;
/*  32:    */   }
/*  33:    */   
/*  34:    */   public List getColumns()
/*  35:    */   {
/*  36: 61 */     return this.columns;
/*  37:    */   }
/*  38:    */   
/*  39:    */   public ItemsList getItemsList()
/*  40:    */   {
/*  41: 70 */     return this.itemsList;
/*  42:    */   }
/*  43:    */   
/*  44:    */   public void setColumns(List list)
/*  45:    */   {
/*  46: 75 */     this.columns = list;
/*  47:    */   }
/*  48:    */   
/*  49:    */   public void setItemsList(ItemsList list)
/*  50:    */   {
/*  51: 79 */     this.itemsList = list;
/*  52:    */   }
/*  53:    */   
/*  54:    */   public List getExpressions()
/*  55:    */   {
/*  56: 87 */     return this.expressions;
/*  57:    */   }
/*  58:    */   
/*  59:    */   public void setExpressions(List list)
/*  60:    */   {
/*  61: 91 */     this.expressions = list;
/*  62:    */   }
/*  63:    */   
/*  64:    */   public boolean isUseValues()
/*  65:    */   {
/*  66: 95 */     return this.useValues;
/*  67:    */   }
/*  68:    */   
/*  69:    */   public void setUseValues(boolean useValues)
/*  70:    */   {
/*  71: 99 */     this.useValues = useValues;
/*  72:    */   }
/*  73:    */   
/*  74:    */   public String toString()
/*  75:    */   {
/*  76:103 */     String sql = "REPLACE " + this.table;
/*  77:105 */     if ((this.expressions != null) && (this.columns != null))
/*  78:    */     {
/*  79:107 */       sql = sql + " SET ";
/*  80:    */       
/*  81:109 */       int i = 0;
/*  82:109 */       for (int s = this.columns.size(); i < s; i++)
/*  83:    */       {
/*  84:110 */         sql = sql + "" + this.columns.get(i) + "=" + this.expressions.get(i);
/*  85:111 */         sql = sql + (i < s - 1 ? ", " : "");
/*  86:    */       }
/*  87:    */     }
/*  88:114 */     else if (this.columns != null)
/*  89:    */     {
/*  90:116 */       sql = sql + " " + PlainSelect.getStringList(this.columns, true, true);
/*  91:    */     }
/*  92:119 */     if (this.itemsList != null)
/*  93:    */     {
/*  94:123 */       if (this.useValues) {
/*  95:124 */         sql = sql + " VALUES";
/*  96:    */       }
/*  97:127 */       sql = sql + " " + this.itemsList;
/*  98:    */     }
/*  99:130 */     return sql;
/* 100:    */   }
/* 101:    */ }


/* Location:           E:\workspace\java\db\lib\jsqlparser.jar
 * Qualified Name:     net.sf.jsqlparser.statement.replace.Replace
 * JD-Core Version:    0.7.0.1
 */