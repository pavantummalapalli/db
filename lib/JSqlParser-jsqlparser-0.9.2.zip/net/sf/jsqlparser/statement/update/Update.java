/*  1:   */ package net.sf.jsqlparser.statement.update;
/*  2:   */ 
/*  3:   */ import java.util.List;
/*  4:   */ import net.sf.jsqlparser.expression.Expression;
/*  5:   */ import net.sf.jsqlparser.schema.Table;
/*  6:   */ import net.sf.jsqlparser.statement.Statement;
/*  7:   */ import net.sf.jsqlparser.statement.StatementVisitor;
/*  8:   */ 
/*  9:   */ public class Update
/* 10:   */   implements Statement
/* 11:   */ {
/* 12:   */   private Table table;
/* 13:   */   private Expression where;
/* 14:   */   private List columns;
/* 15:   */   private List expressions;
/* 16:   */   
/* 17:   */   public void accept(StatementVisitor statementVisitor)
/* 18:   */   {
/* 19:42 */     statementVisitor.visit(this);
/* 20:   */   }
/* 21:   */   
/* 22:   */   public Table getTable()
/* 23:   */   {
/* 24:46 */     return this.table;
/* 25:   */   }
/* 26:   */   
/* 27:   */   public Expression getWhere()
/* 28:   */   {
/* 29:50 */     return this.where;
/* 30:   */   }
/* 31:   */   
/* 32:   */   public void setTable(Table name)
/* 33:   */   {
/* 34:54 */     this.table = name;
/* 35:   */   }
/* 36:   */   
/* 37:   */   public void setWhere(Expression expression)
/* 38:   */   {
/* 39:58 */     this.where = expression;
/* 40:   */   }
/* 41:   */   
/* 42:   */   public List getColumns()
/* 43:   */   {
/* 44:66 */     return this.columns;
/* 45:   */   }
/* 46:   */   
/* 47:   */   public List getExpressions()
/* 48:   */   {
/* 49:74 */     return this.expressions;
/* 50:   */   }
/* 51:   */   
/* 52:   */   public void setColumns(List list)
/* 53:   */   {
/* 54:78 */     this.columns = list;
/* 55:   */   }
/* 56:   */   
/* 57:   */   public void setExpressions(List list)
/* 58:   */   {
/* 59:82 */     this.expressions = list;
/* 60:   */   }
/* 61:   */ }


/* Location:           E:\workspace\java\db\lib\jsqlparser.jar
 * Qualified Name:     net.sf.jsqlparser.statement.update.Update
 * JD-Core Version:    0.7.0.1
 */