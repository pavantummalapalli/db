/*   1:    */ package net.sf.jsqlparser.statement.insert;
/*   2:    */ 
/*   3:    */ import java.util.List;
/*   4:    */ import net.sf.jsqlparser.expression.operators.relational.ItemsList;
/*   5:    */ import net.sf.jsqlparser.schema.Table;
/*   6:    */ import net.sf.jsqlparser.statement.Statement;
/*   7:    */ import net.sf.jsqlparser.statement.StatementVisitor;
/*   8:    */ import net.sf.jsqlparser.statement.select.PlainSelect;
/*   9:    */ 
/*  10:    */ public class Insert
/*  11:    */   implements Statement
/*  12:    */ {
/*  13:    */   private Table table;
/*  14:    */   private List columns;
/*  15:    */   private ItemsList itemsList;
/*  16: 42 */   private boolean useValues = true;
/*  17:    */   
/*  18:    */   public void accept(StatementVisitor statementVisitor)
/*  19:    */   {
/*  20: 45 */     statementVisitor.visit(this);
/*  21:    */   }
/*  22:    */   
/*  23:    */   public Table getTable()
/*  24:    */   {
/*  25: 49 */     return this.table;
/*  26:    */   }
/*  27:    */   
/*  28:    */   public void setTable(Table name)
/*  29:    */   {
/*  30: 53 */     this.table = name;
/*  31:    */   }
/*  32:    */   
/*  33:    */   public List getColumns()
/*  34:    */   {
/*  35: 61 */     return this.columns;
/*  36:    */   }
/*  37:    */   
/*  38:    */   public void setColumns(List list)
/*  39:    */   {
/*  40: 65 */     this.columns = list;
/*  41:    */   }
/*  42:    */   
/*  43:    */   public ItemsList getItemsList()
/*  44:    */   {
/*  45: 73 */     return this.itemsList;
/*  46:    */   }
/*  47:    */   
/*  48:    */   public void setItemsList(ItemsList list)
/*  49:    */   {
/*  50: 77 */     this.itemsList = list;
/*  51:    */   }
/*  52:    */   
/*  53:    */   public boolean isUseValues()
/*  54:    */   {
/*  55: 81 */     return this.useValues;
/*  56:    */   }
/*  57:    */   
/*  58:    */   public void setUseValues(boolean useValues)
/*  59:    */   {
/*  60: 85 */     this.useValues = useValues;
/*  61:    */   }
/*  62:    */   
/*  63:    */   public String toString()
/*  64:    */   {
/*  65: 89 */     String sql = "";
/*  66:    */     
/*  67: 91 */     sql = "INSERT INTO ";
/*  68: 92 */     sql = sql + this.table + " ";
/*  69: 93 */     sql = sql + (this.columns != null ? PlainSelect.getStringList(this.columns, true, true) + " " : "");
/*  70: 95 */     if (this.useValues) {
/*  71: 96 */       sql = sql + "VALUES " + this.itemsList + "";
/*  72:    */     } else {
/*  73: 98 */       sql = sql + "" + this.itemsList + "";
/*  74:    */     }
/*  75:101 */     return sql;
/*  76:    */   }
/*  77:    */ }


/* Location:           E:\workspace\java\db\lib\jsqlparser.jar
 * Qualified Name:     net.sf.jsqlparser.statement.insert.Insert
 * JD-Core Version:    0.7.0.1
 */