/*  1:   */ package net.sf.jsqlparser.statement.create.table;
/*  2:   */ 
/*  3:   */ import java.util.List;
/*  4:   */ import net.sf.jsqlparser.statement.select.PlainSelect;
/*  5:   */ 
/*  6:   */ public class Index
/*  7:   */ {
/*  8:   */   private String type;
/*  9:   */   private List columnsNames;
/* 10:   */   private String name;
/* 11:   */   
/* 12:   */   public List getColumnsNames()
/* 13:   */   {
/* 14:20 */     return this.columnsNames;
/* 15:   */   }
/* 16:   */   
/* 17:   */   public String getName()
/* 18:   */   {
/* 19:24 */     return this.name;
/* 20:   */   }
/* 21:   */   
/* 22:   */   public String getType()
/* 23:   */   {
/* 24:31 */     return this.type;
/* 25:   */   }
/* 26:   */   
/* 27:   */   public void setColumnsNames(List list)
/* 28:   */   {
/* 29:35 */     this.columnsNames = list;
/* 30:   */   }
/* 31:   */   
/* 32:   */   public void setName(String string)
/* 33:   */   {
/* 34:39 */     this.name = string;
/* 35:   */   }
/* 36:   */   
/* 37:   */   public void setType(String string)
/* 38:   */   {
/* 39:43 */     this.type = string;
/* 40:   */   }
/* 41:   */   
/* 42:   */   public String toString()
/* 43:   */   {
/* 44:47 */     return this.type + " " + PlainSelect.getStringList(this.columnsNames, true, true) + (this.name != null ? " " + this.name : "");
/* 45:   */   }
/* 46:   */ }


/* Location:           E:\workspace\java\db\lib\jsqlparser.jar
 * Qualified Name:     net.sf.jsqlparser.statement.create.table.Index
 * JD-Core Version:    0.7.0.1
 */