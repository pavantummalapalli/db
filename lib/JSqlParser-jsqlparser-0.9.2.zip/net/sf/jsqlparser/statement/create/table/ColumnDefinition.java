/*  1:   */ package net.sf.jsqlparser.statement.create.table;
/*  2:   */ 
/*  3:   */ import java.util.List;
/*  4:   */ import net.sf.jsqlparser.statement.select.PlainSelect;
/*  5:   */ 
/*  6:   */ public class ColumnDefinition
/*  7:   */ {
/*  8:   */   private String columnName;
/*  9:   */   private ColDataType colDataType;
/* 10:   */   private List columnSpecStrings;
/* 11:   */   
/* 12:   */   public List getColumnSpecStrings()
/* 13:   */   {
/* 14:24 */     return this.columnSpecStrings;
/* 15:   */   }
/* 16:   */   
/* 17:   */   public void setColumnSpecStrings(List list)
/* 18:   */   {
/* 19:28 */     this.columnSpecStrings = list;
/* 20:   */   }
/* 21:   */   
/* 22:   */   public ColDataType getColDataType()
/* 23:   */   {
/* 24:35 */     return this.colDataType;
/* 25:   */   }
/* 26:   */   
/* 27:   */   public void setColDataType(ColDataType type)
/* 28:   */   {
/* 29:39 */     this.colDataType = type;
/* 30:   */   }
/* 31:   */   
/* 32:   */   public String getColumnName()
/* 33:   */   {
/* 34:43 */     return this.columnName;
/* 35:   */   }
/* 36:   */   
/* 37:   */   public void setColumnName(String string)
/* 38:   */   {
/* 39:47 */     this.columnName = string;
/* 40:   */   }
/* 41:   */   
/* 42:   */   public String toString()
/* 43:   */   {
/* 44:51 */     return this.columnName + " " + this.colDataType + " " + PlainSelect.getStringList(this.columnSpecStrings, false, false);
/* 45:   */   }
/* 46:   */ }


/* Location:           E:\workspace\java\db\lib\jsqlparser.jar
 * Qualified Name:     net.sf.jsqlparser.statement.create.table.ColumnDefinition
 * JD-Core Version:    0.7.0.1
 */