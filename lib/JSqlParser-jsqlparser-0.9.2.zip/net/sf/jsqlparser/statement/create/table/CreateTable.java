/*  1:   */ package net.sf.jsqlparser.statement.create.table;
/*  2:   */ 
/*  3:   */ import java.util.List;
/*  4:   */ import net.sf.jsqlparser.schema.Table;
/*  5:   */ import net.sf.jsqlparser.statement.Statement;
/*  6:   */ import net.sf.jsqlparser.statement.StatementVisitor;
/*  7:   */ import net.sf.jsqlparser.statement.select.PlainSelect;
/*  8:   */ 
/*  9:   */ public class CreateTable
/* 10:   */   implements Statement
/* 11:   */ {
/* 12:   */   private Table table;
/* 13:   */   private List tableOptionsStrings;
/* 14:   */   private List columnDefinitions;
/* 15:   */   private List indexes;
/* 16:   */   
/* 17:   */   public void accept(StatementVisitor statementVisitor)
/* 18:   */   {
/* 19:21 */     statementVisitor.visit(this);
/* 20:   */   }
/* 21:   */   
/* 22:   */   public Table getTable()
/* 23:   */   {
/* 24:28 */     return this.table;
/* 25:   */   }
/* 26:   */   
/* 27:   */   public void setTable(Table table)
/* 28:   */   {
/* 29:32 */     this.table = table;
/* 30:   */   }
/* 31:   */   
/* 32:   */   public List getColumnDefinitions()
/* 33:   */   {
/* 34:39 */     return this.columnDefinitions;
/* 35:   */   }
/* 36:   */   
/* 37:   */   public void setColumnDefinitions(List list)
/* 38:   */   {
/* 39:43 */     this.columnDefinitions = list;
/* 40:   */   }
/* 41:   */   
/* 42:   */   public List getTableOptionsStrings()
/* 43:   */   {
/* 44:50 */     return this.tableOptionsStrings;
/* 45:   */   }
/* 46:   */   
/* 47:   */   public void setTableOptionsStrings(List list)
/* 48:   */   {
/* 49:54 */     this.tableOptionsStrings = list;
/* 50:   */   }
/* 51:   */   
/* 52:   */   public List getIndexes()
/* 53:   */   {
/* 54:62 */     return this.indexes;
/* 55:   */   }
/* 56:   */   
/* 57:   */   public void setIndexes(List list)
/* 58:   */   {
/* 59:66 */     this.indexes = list;
/* 60:   */   }
/* 61:   */   
/* 62:   */   public String toString()
/* 63:   */   {
/* 64:70 */     String sql = "";
/* 65:   */     
/* 66:72 */     sql = "CREATE TABLE " + this.table + " (";
/* 67:   */     
/* 68:74 */     sql = sql + PlainSelect.getStringList(this.columnDefinitions, true, false);
/* 69:75 */     if ((this.indexes != null) && (this.indexes.size() != 0))
/* 70:   */     {
/* 71:76 */       sql = sql + ", ";
/* 72:77 */       sql = sql + PlainSelect.getStringList(this.indexes);
/* 73:   */     }
/* 74:79 */     sql = sql + ") ";
/* 75:80 */     sql = sql + PlainSelect.getStringList(this.tableOptionsStrings, false, false);
/* 76:   */     
/* 77:82 */     return sql;
/* 78:   */   }
/* 79:   */ }


/* Location:           E:\workspace\java\db\lib\jsqlparser.jar
 * Qualified Name:     net.sf.jsqlparser.statement.create.table.CreateTable
 * JD-Core Version:    0.7.0.1
 */