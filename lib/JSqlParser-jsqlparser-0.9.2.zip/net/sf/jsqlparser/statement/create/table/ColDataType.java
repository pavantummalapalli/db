/*  1:   */ package net.sf.jsqlparser.statement.create.table;
/*  2:   */ 
/*  3:   */ import java.util.List;
/*  4:   */ import net.sf.jsqlparser.statement.select.PlainSelect;
/*  5:   */ 
/*  6:   */ public class ColDataType
/*  7:   */ {
/*  8:   */   private String dataType;
/*  9:   */   private List argumentsStringList;
/* 10:   */   
/* 11:   */   public List getArgumentsStringList()
/* 12:   */   {
/* 13:14 */     return this.argumentsStringList;
/* 14:   */   }
/* 15:   */   
/* 16:   */   public String getDataType()
/* 17:   */   {
/* 18:18 */     return this.dataType;
/* 19:   */   }
/* 20:   */   
/* 21:   */   public void setArgumentsStringList(List list)
/* 22:   */   {
/* 23:22 */     this.argumentsStringList = list;
/* 24:   */   }
/* 25:   */   
/* 26:   */   public void setDataType(String string)
/* 27:   */   {
/* 28:26 */     this.dataType = string;
/* 29:   */   }
/* 30:   */   
/* 31:   */   public String toString()
/* 32:   */   {
/* 33:30 */     return this.dataType + (this.argumentsStringList != null ? " " + PlainSelect.getStringList(this.argumentsStringList, true, true) : "");
/* 34:   */   }
/* 35:   */ }


/* Location:           E:\workspace\java\db\lib\jsqlparser.jar
 * Qualified Name:     net.sf.jsqlparser.statement.create.table.ColDataType
 * JD-Core Version:    0.7.0.1
 */