package net.sf.jsqlparser.statement;

import net.sf.jsqlparser.statement.create.table.CreateTable;
import net.sf.jsqlparser.statement.delete.Delete;
import net.sf.jsqlparser.statement.drop.Drop;
import net.sf.jsqlparser.statement.insert.Insert;
import net.sf.jsqlparser.statement.replace.Replace;
import net.sf.jsqlparser.statement.select.Select;
import net.sf.jsqlparser.statement.truncate.Truncate;
import net.sf.jsqlparser.statement.update.Update;

public abstract interface StatementVisitor
{
  public abstract void visit(Select paramSelect);
  
  public abstract void visit(Delete paramDelete);
  
  public abstract void visit(Update paramUpdate);
  
  public abstract void visit(Insert paramInsert);
  
  public abstract void visit(Replace paramReplace);
  
  public abstract void visit(Drop paramDrop);
  
  public abstract void visit(Truncate paramTruncate);
  
  public abstract void visit(CreateTable paramCreateTable);
}


/* Location:           E:\workspace\java\db\lib\jsqlparser.jar
 * Qualified Name:     net.sf.jsqlparser.statement.StatementVisitor
 * JD-Core Version:    0.7.0.1
 */