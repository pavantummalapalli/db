/*  1:   */ package net.sf.jsqlparser.util.deparser;
/*  2:   */ 
/*  3:   */ import java.util.Iterator;
/*  4:   */ import java.util.List;
/*  5:   */ import net.sf.jsqlparser.expression.Expression;
/*  6:   */ import net.sf.jsqlparser.expression.ExpressionVisitor;
/*  7:   */ import net.sf.jsqlparser.expression.operators.relational.ExpressionList;
/*  8:   */ import net.sf.jsqlparser.expression.operators.relational.ItemsList;
/*  9:   */ import net.sf.jsqlparser.expression.operators.relational.ItemsListVisitor;
/* 10:   */ import net.sf.jsqlparser.schema.Column;
/* 11:   */ import net.sf.jsqlparser.schema.Table;
/* 12:   */ import net.sf.jsqlparser.statement.insert.Insert;
/* 13:   */ import net.sf.jsqlparser.statement.select.SelectBody;
/* 14:   */ import net.sf.jsqlparser.statement.select.SelectVisitor;
/* 15:   */ import net.sf.jsqlparser.statement.select.SubSelect;
/* 16:   */ 
/* 17:   */ public class InsertDeParser
/* 18:   */   implements ItemsListVisitor
/* 19:   */ {
/* 20:   */   protected StringBuffer buffer;
/* 21:   */   protected ExpressionVisitor expressionVisitor;
/* 22:   */   protected SelectVisitor selectVisitor;
/* 23:   */   
/* 24:   */   public InsertDeParser() {}
/* 25:   */   
/* 26:   */   public InsertDeParser(ExpressionVisitor expressionVisitor, SelectVisitor selectVisitor, StringBuffer buffer)
/* 27:   */   {
/* 28:36 */     this.buffer = buffer;
/* 29:37 */     this.expressionVisitor = expressionVisitor;
/* 30:38 */     this.selectVisitor = selectVisitor;
/* 31:   */   }
/* 32:   */   
/* 33:   */   public StringBuffer getBuffer()
/* 34:   */   {
/* 35:42 */     return this.buffer;
/* 36:   */   }
/* 37:   */   
/* 38:   */   public void setBuffer(StringBuffer buffer)
/* 39:   */   {
/* 40:46 */     this.buffer = buffer;
/* 41:   */   }
/* 42:   */   
/* 43:   */   public void deParse(Insert insert)
/* 44:   */   {
/* 45:50 */     this.buffer.append("INSERT INTO ");
/* 46:51 */     this.buffer.append(insert.getTable().getWholeTableName());
/* 47:52 */     if (insert.getColumns() != null)
/* 48:   */     {
/* 49:53 */       this.buffer.append("(");
/* 50:54 */       for (Iterator iter = insert.getColumns().iterator(); iter.hasNext();)
/* 51:   */       {
/* 52:55 */         Column column = (Column)iter.next();
/* 53:56 */         this.buffer.append(column.getColumnName());
/* 54:57 */         if (iter.hasNext()) {
/* 55:58 */           this.buffer.append(", ");
/* 56:   */         }
/* 57:   */       }
/* 58:61 */       this.buffer.append(")");
/* 59:   */     }
/* 60:64 */     insert.getItemsList().accept(this);
/* 61:   */   }
/* 62:   */   
/* 63:   */   public void visit(ExpressionList expressionList)
/* 64:   */   {
/* 65:69 */     this.buffer.append(" VALUES (");
/* 66:70 */     for (Iterator iter = expressionList.getExpressions().iterator(); iter.hasNext();)
/* 67:   */     {
/* 68:71 */       Expression expression = (Expression)iter.next();
/* 69:72 */       expression.accept(this.expressionVisitor);
/* 70:73 */       if (iter.hasNext()) {
/* 71:74 */         this.buffer.append(", ");
/* 72:   */       }
/* 73:   */     }
/* 74:76 */     this.buffer.append(")");
/* 75:   */   }
/* 76:   */   
/* 77:   */   public void visit(SubSelect subSelect)
/* 78:   */   {
/* 79:80 */     subSelect.getSelectBody().accept(this.selectVisitor);
/* 80:   */   }
/* 81:   */   
/* 82:   */   public ExpressionVisitor getExpressionVisitor()
/* 83:   */   {
/* 84:83 */     return this.expressionVisitor;
/* 85:   */   }
/* 86:   */   
/* 87:   */   public SelectVisitor getSelectVisitor()
/* 88:   */   {
/* 89:87 */     return this.selectVisitor;
/* 90:   */   }
/* 91:   */   
/* 92:   */   public void setExpressionVisitor(ExpressionVisitor visitor)
/* 93:   */   {
/* 94:91 */     this.expressionVisitor = visitor;
/* 95:   */   }
/* 96:   */   
/* 97:   */   public void setSelectVisitor(SelectVisitor visitor)
/* 98:   */   {
/* 99:95 */     this.selectVisitor = visitor;
/* :0:   */   }
/* :1:   */ }


/* Location:           E:\workspace\java\db\lib\jsqlparser.jar
 * Qualified Name:     net.sf.jsqlparser.util.deparser.InsertDeParser
 * JD-Core Version:    0.7.0.1
 */