/*  1:   */ package net.sf.jsqlparser.util.deparser;
/*  2:   */ 
/*  3:   */ import net.sf.jsqlparser.expression.Expression;
/*  4:   */ import net.sf.jsqlparser.expression.ExpressionVisitor;
/*  5:   */ import net.sf.jsqlparser.schema.Table;
/*  6:   */ import net.sf.jsqlparser.statement.delete.Delete;
/*  7:   */ 
/*  8:   */ public class DeleteDeParser
/*  9:   */ {
/* 10:   */   protected StringBuffer buffer;
/* 11:   */   protected ExpressionVisitor expressionVisitor;
/* 12:   */   
/* 13:   */   public DeleteDeParser() {}
/* 14:   */   
/* 15:   */   public DeleteDeParser(ExpressionVisitor expressionVisitor, StringBuffer buffer)
/* 16:   */   {
/* 17:24 */     this.buffer = buffer;
/* 18:25 */     this.expressionVisitor = expressionVisitor;
/* 19:   */   }
/* 20:   */   
/* 21:   */   public StringBuffer getBuffer()
/* 22:   */   {
/* 23:29 */     return this.buffer;
/* 24:   */   }
/* 25:   */   
/* 26:   */   public void setBuffer(StringBuffer buffer)
/* 27:   */   {
/* 28:33 */     this.buffer = buffer;
/* 29:   */   }
/* 30:   */   
/* 31:   */   public void deParse(Delete delete)
/* 32:   */   {
/* 33:37 */     this.buffer.append("DELETE FROM " + delete.getTable().getWholeTableName());
/* 34:38 */     if (delete.getWhere() != null)
/* 35:   */     {
/* 36:39 */       this.buffer.append(" WHERE ");
/* 37:40 */       delete.getWhere().accept(this.expressionVisitor);
/* 38:   */     }
/* 39:   */   }
/* 40:   */   
/* 41:   */   public ExpressionVisitor getExpressionVisitor()
/* 42:   */   {
/* 43:45 */     return this.expressionVisitor;
/* 44:   */   }
/* 45:   */   
/* 46:   */   public void setExpressionVisitor(ExpressionVisitor visitor)
/* 47:   */   {
/* 48:49 */     this.expressionVisitor = visitor;
/* 49:   */   }
/* 50:   */ }


/* Location:           E:\workspace\java\db\lib\jsqlparser.jar
 * Qualified Name:     net.sf.jsqlparser.util.deparser.DeleteDeParser
 * JD-Core Version:    0.7.0.1
 */