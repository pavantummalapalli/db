/*  1:   */ package net.sf.jsqlparser.util.deparser;
/*  2:   */ 
/*  3:   */ import java.util.List;
/*  4:   */ import net.sf.jsqlparser.expression.Expression;
/*  5:   */ import net.sf.jsqlparser.expression.ExpressionVisitor;
/*  6:   */ import net.sf.jsqlparser.schema.Column;
/*  7:   */ import net.sf.jsqlparser.schema.Table;
/*  8:   */ import net.sf.jsqlparser.statement.update.Update;
/*  9:   */ 
/* 10:   */ public class UpdateDeParser
/* 11:   */ {
/* 12:   */   protected StringBuffer buffer;
/* 13:   */   protected ExpressionVisitor expressionVisitor;
/* 14:   */   
/* 15:   */   public UpdateDeParser() {}
/* 16:   */   
/* 17:   */   public UpdateDeParser(ExpressionVisitor expressionVisitor, StringBuffer buffer)
/* 18:   */   {
/* 19:25 */     this.buffer = buffer;
/* 20:26 */     this.expressionVisitor = expressionVisitor;
/* 21:   */   }
/* 22:   */   
/* 23:   */   public StringBuffer getBuffer()
/* 24:   */   {
/* 25:30 */     return this.buffer;
/* 26:   */   }
/* 27:   */   
/* 28:   */   public void setBuffer(StringBuffer buffer)
/* 29:   */   {
/* 30:34 */     this.buffer = buffer;
/* 31:   */   }
/* 32:   */   
/* 33:   */   public void deParse(Update update)
/* 34:   */   {
/* 35:38 */     this.buffer.append("UPDATE " + update.getTable().getWholeTableName() + " SET ");
/* 36:39 */     for (int i = 0; i < update.getColumns().size(); i++)
/* 37:   */     {
/* 38:40 */       Column column = (Column)update.getColumns().get(i);
/* 39:41 */       this.buffer.append(column.getWholeColumnName() + "=");
/* 40:   */       
/* 41:43 */       Expression expression = (Expression)update.getExpressions().get(i);
/* 42:44 */       expression.accept(this.expressionVisitor);
/* 43:45 */       if (i < update.getColumns().size() - 1) {
/* 44:46 */         this.buffer.append(", ");
/* 45:   */       }
/* 46:   */     }
/* 47:51 */     if (update.getWhere() != null)
/* 48:   */     {
/* 49:52 */       this.buffer.append(" WHERE ");
/* 50:53 */       update.getWhere().accept(this.expressionVisitor);
/* 51:   */     }
/* 52:   */   }
/* 53:   */   
/* 54:   */   public ExpressionVisitor getExpressionVisitor()
/* 55:   */   {
/* 56:59 */     return this.expressionVisitor;
/* 57:   */   }
/* 58:   */   
/* 59:   */   public void setExpressionVisitor(ExpressionVisitor visitor)
/* 60:   */   {
/* 61:63 */     this.expressionVisitor = visitor;
/* 62:   */   }
/* 63:   */ }


/* Location:           E:\workspace\java\db\lib\jsqlparser.jar
 * Qualified Name:     net.sf.jsqlparser.util.deparser.UpdateDeParser
 * JD-Core Version:    0.7.0.1
 */