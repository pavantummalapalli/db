/*   1:    */ package net.sf.jsqlparser.util.deparser;
/*   2:    */ 
/*   3:    */ import java.sql.Date;
/*   4:    */ import java.sql.Time;
/*   5:    */ import java.sql.Timestamp;
/*   6:    */ import java.util.Iterator;
/*   7:    */ import java.util.List;
/*   8:    */ import net.sf.jsqlparser.expression.AllComparisonExpression;
/*   9:    */ import net.sf.jsqlparser.expression.AnyComparisonExpression;
/*  10:    */ import net.sf.jsqlparser.expression.BinaryExpression;
/*  11:    */ import net.sf.jsqlparser.expression.CaseExpression;
/*  12:    */ import net.sf.jsqlparser.expression.DateValue;
/*  13:    */ import net.sf.jsqlparser.expression.DoubleValue;
/*  14:    */ import net.sf.jsqlparser.expression.Expression;
/*  15:    */ import net.sf.jsqlparser.expression.ExpressionVisitor;
/*  16:    */ import net.sf.jsqlparser.expression.Function;
/*  17:    */ import net.sf.jsqlparser.expression.InverseExpression;
/*  18:    */ import net.sf.jsqlparser.expression.JdbcParameter;
/*  19:    */ import net.sf.jsqlparser.expression.LongValue;
/*  20:    */ import net.sf.jsqlparser.expression.NullValue;
/*  21:    */ import net.sf.jsqlparser.expression.Parenthesis;
/*  22:    */ import net.sf.jsqlparser.expression.StringValue;
/*  23:    */ import net.sf.jsqlparser.expression.TimeValue;
/*  24:    */ import net.sf.jsqlparser.expression.TimestampValue;
/*  25:    */ import net.sf.jsqlparser.expression.WhenClause;
/*  26:    */ import net.sf.jsqlparser.expression.operators.arithmetic.Addition;
/*  27:    */ import net.sf.jsqlparser.expression.operators.arithmetic.BitwiseAnd;
/*  28:    */ import net.sf.jsqlparser.expression.operators.arithmetic.BitwiseOr;
/*  29:    */ import net.sf.jsqlparser.expression.operators.arithmetic.BitwiseXor;
/*  30:    */ import net.sf.jsqlparser.expression.operators.arithmetic.Concat;
/*  31:    */ import net.sf.jsqlparser.expression.operators.arithmetic.Division;
/*  32:    */ import net.sf.jsqlparser.expression.operators.arithmetic.Multiplication;
/*  33:    */ import net.sf.jsqlparser.expression.operators.arithmetic.Subtraction;
/*  34:    */ import net.sf.jsqlparser.expression.operators.conditional.AndExpression;
/*  35:    */ import net.sf.jsqlparser.expression.operators.conditional.OrExpression;
/*  36:    */ import net.sf.jsqlparser.expression.operators.relational.Between;
/*  37:    */ import net.sf.jsqlparser.expression.operators.relational.EqualsTo;
/*  38:    */ import net.sf.jsqlparser.expression.operators.relational.ExistsExpression;
/*  39:    */ import net.sf.jsqlparser.expression.operators.relational.ExpressionList;
/*  40:    */ import net.sf.jsqlparser.expression.operators.relational.GreaterThan;
/*  41:    */ import net.sf.jsqlparser.expression.operators.relational.GreaterThanEquals;
/*  42:    */ import net.sf.jsqlparser.expression.operators.relational.InExpression;
/*  43:    */ import net.sf.jsqlparser.expression.operators.relational.IsNullExpression;
/*  44:    */ import net.sf.jsqlparser.expression.operators.relational.ItemsList;
/*  45:    */ import net.sf.jsqlparser.expression.operators.relational.ItemsListVisitor;
/*  46:    */ import net.sf.jsqlparser.expression.operators.relational.LikeExpression;
/*  47:    */ import net.sf.jsqlparser.expression.operators.relational.Matches;
/*  48:    */ import net.sf.jsqlparser.expression.operators.relational.MinorThan;
/*  49:    */ import net.sf.jsqlparser.expression.operators.relational.MinorThanEquals;
/*  50:    */ import net.sf.jsqlparser.expression.operators.relational.NotEqualsTo;
/*  51:    */ import net.sf.jsqlparser.schema.Column;
/*  52:    */ import net.sf.jsqlparser.schema.Table;
/*  53:    */ import net.sf.jsqlparser.statement.select.SelectBody;
/*  54:    */ import net.sf.jsqlparser.statement.select.SelectVisitor;
/*  55:    */ import net.sf.jsqlparser.statement.select.SubSelect;
/*  56:    */ 
/*  57:    */ public class ExpressionDeParser
/*  58:    */   implements ExpressionVisitor, ItemsListVisitor
/*  59:    */ {
/*  60:    */   protected StringBuffer buffer;
/*  61:    */   protected SelectVisitor selectVisitor;
/*  62: 60 */   protected boolean useBracketsInExprList = true;
/*  63:    */   
/*  64:    */   public ExpressionDeParser() {}
/*  65:    */   
/*  66:    */   public ExpressionDeParser(SelectVisitor selectVisitor, StringBuffer buffer)
/*  67:    */   {
/*  68: 79 */     this.selectVisitor = selectVisitor;
/*  69: 80 */     this.buffer = buffer;
/*  70:    */   }
/*  71:    */   
/*  72:    */   public StringBuffer getBuffer()
/*  73:    */   {
/*  74: 84 */     return this.buffer;
/*  75:    */   }
/*  76:    */   
/*  77:    */   public void setBuffer(StringBuffer buffer)
/*  78:    */   {
/*  79: 88 */     this.buffer = buffer;
/*  80:    */   }
/*  81:    */   
/*  82:    */   public void visit(Addition addition)
/*  83:    */   {
/*  84: 92 */     visitBinaryExpression(addition, " + ");
/*  85:    */   }
/*  86:    */   
/*  87:    */   public void visit(AndExpression andExpression)
/*  88:    */   {
/*  89: 96 */     visitBinaryExpression(andExpression, " AND ");
/*  90:    */   }
/*  91:    */   
/*  92:    */   public void visit(Between between)
/*  93:    */   {
/*  94:100 */     between.getLeftExpression().accept(this);
/*  95:101 */     if (between.isNot()) {
/*  96:102 */       this.buffer.append(" NOT");
/*  97:    */     }
/*  98:104 */     this.buffer.append(" BETWEEN ");
/*  99:105 */     between.getBetweenExpressionStart().accept(this);
/* 100:106 */     this.buffer.append(" AND ");
/* 101:107 */     between.getBetweenExpressionEnd().accept(this);
/* 102:    */   }
/* 103:    */   
/* 104:    */   public void visit(Division division)
/* 105:    */   {
/* 106:112 */     visitBinaryExpression(division, " / ");
/* 107:    */   }
/* 108:    */   
/* 109:    */   public void visit(DoubleValue doubleValue)
/* 110:    */   {
/* 111:117 */     this.buffer.append(doubleValue.getValue());
/* 112:    */   }
/* 113:    */   
/* 114:    */   public void visit(EqualsTo equalsTo)
/* 115:    */   {
/* 116:122 */     visitBinaryExpression(equalsTo, " = ");
/* 117:    */   }
/* 118:    */   
/* 119:    */   public void visit(GreaterThan greaterThan)
/* 120:    */   {
/* 121:126 */     visitBinaryExpression(greaterThan, " > ");
/* 122:    */   }
/* 123:    */   
/* 124:    */   public void visit(GreaterThanEquals greaterThanEquals)
/* 125:    */   {
/* 126:130 */     visitBinaryExpression(greaterThanEquals, " >= ");
/* 127:    */   }
/* 128:    */   
/* 129:    */   public void visit(InExpression inExpression)
/* 130:    */   {
/* 131:136 */     inExpression.getLeftExpression().accept(this);
/* 132:137 */     if (inExpression.isNot()) {
/* 133:138 */       this.buffer.append(" NOT");
/* 134:    */     }
/* 135:139 */     this.buffer.append(" IN ");
/* 136:    */     
/* 137:141 */     inExpression.getItemsList().accept(this);
/* 138:    */   }
/* 139:    */   
/* 140:    */   public void visit(InverseExpression inverseExpression)
/* 141:    */   {
/* 142:145 */     this.buffer.append("-");
/* 143:146 */     inverseExpression.getExpression().accept(this);
/* 144:    */   }
/* 145:    */   
/* 146:    */   public void visit(IsNullExpression isNullExpression)
/* 147:    */   {
/* 148:150 */     isNullExpression.getLeftExpression().accept(this);
/* 149:151 */     if (isNullExpression.isNot()) {
/* 150:152 */       this.buffer.append(" IS NOT NULL");
/* 151:    */     } else {
/* 152:154 */       this.buffer.append(" IS NULL");
/* 153:    */     }
/* 154:    */   }
/* 155:    */   
/* 156:    */   public void visit(JdbcParameter jdbcParameter)
/* 157:    */   {
/* 158:159 */     this.buffer.append("?");
/* 159:    */   }
/* 160:    */   
/* 161:    */   public void visit(LikeExpression likeExpression)
/* 162:    */   {
/* 163:164 */     visitBinaryExpression(likeExpression, " LIKE ");
/* 164:    */   }
/* 165:    */   
/* 166:    */   public void visit(ExistsExpression existsExpression)
/* 167:    */   {
/* 168:169 */     if (existsExpression.isNot()) {
/* 169:170 */       this.buffer.append(" NOT EXISTS ");
/* 170:    */     } else {
/* 171:172 */       this.buffer.append(" EXISTS ");
/* 172:    */     }
/* 173:174 */     existsExpression.getRightExpression().accept(this);
/* 174:    */   }
/* 175:    */   
/* 176:    */   public void visit(LongValue longValue)
/* 177:    */   {
/* 178:178 */     this.buffer.append(longValue.getStringValue());
/* 179:    */   }
/* 180:    */   
/* 181:    */   public void visit(MinorThan minorThan)
/* 182:    */   {
/* 183:183 */     visitBinaryExpression(minorThan, " < ");
/* 184:    */   }
/* 185:    */   
/* 186:    */   public void visit(MinorThanEquals minorThanEquals)
/* 187:    */   {
/* 188:188 */     visitBinaryExpression(minorThanEquals, " <= ");
/* 189:    */   }
/* 190:    */   
/* 191:    */   public void visit(Multiplication multiplication)
/* 192:    */   {
/* 193:193 */     visitBinaryExpression(multiplication, " * ");
/* 194:    */   }
/* 195:    */   
/* 196:    */   public void visit(NotEqualsTo notEqualsTo)
/* 197:    */   {
/* 198:198 */     visitBinaryExpression(notEqualsTo, " <> ");
/* 199:    */   }
/* 200:    */   
/* 201:    */   public void visit(NullValue nullValue)
/* 202:    */   {
/* 203:203 */     this.buffer.append("NULL");
/* 204:    */   }
/* 205:    */   
/* 206:    */   public void visit(OrExpression orExpression)
/* 207:    */   {
/* 208:208 */     visitBinaryExpression(orExpression, " OR ");
/* 209:    */   }
/* 210:    */   
/* 211:    */   public void visit(Parenthesis parenthesis)
/* 212:    */   {
/* 213:213 */     if (parenthesis.isNot()) {
/* 214:214 */       this.buffer.append(" NOT ");
/* 215:    */     }
/* 216:216 */     this.buffer.append("(");
/* 217:217 */     parenthesis.getExpression().accept(this);
/* 218:218 */     this.buffer.append(")");
/* 219:    */   }
/* 220:    */   
/* 221:    */   public void visit(StringValue stringValue)
/* 222:    */   {
/* 223:223 */     this.buffer.append("'" + stringValue.getValue() + "'");
/* 224:    */   }
/* 225:    */   
/* 226:    */   public void visit(Subtraction subtraction)
/* 227:    */   {
/* 228:228 */     visitBinaryExpression(subtraction, "-");
/* 229:    */   }
/* 230:    */   
/* 231:    */   private void visitBinaryExpression(BinaryExpression binaryExpression, String operator)
/* 232:    */   {
/* 233:233 */     if (binaryExpression.isNot()) {
/* 234:234 */       this.buffer.append(" NOT ");
/* 235:    */     }
/* 236:235 */     binaryExpression.getLeftExpression().accept(this);
/* 237:236 */     this.buffer.append(operator);
/* 238:237 */     binaryExpression.getRightExpression().accept(this);
/* 239:    */   }
/* 240:    */   
/* 241:    */   public void visit(SubSelect subSelect)
/* 242:    */   {
/* 243:242 */     this.buffer.append("(");
/* 244:243 */     subSelect.getSelectBody().accept(this.selectVisitor);
/* 245:244 */     this.buffer.append(")");
/* 246:    */   }
/* 247:    */   
/* 248:    */   public void visit(Column tableColumn)
/* 249:    */   {
/* 250:248 */     String tableName = tableColumn.getTable().getWholeTableName();
/* 251:249 */     if (tableName != null) {
/* 252:250 */       this.buffer.append(tableName + ".");
/* 253:    */     }
/* 254:253 */     this.buffer.append(tableColumn.getColumnName());
/* 255:    */   }
/* 256:    */   
/* 257:    */   public void visit(Function function)
/* 258:    */   {
/* 259:257 */     if (function.isEscaped()) {
/* 260:258 */       this.buffer.append("{fn ");
/* 261:    */     }
/* 262:261 */     this.buffer.append(function.getName());
/* 263:262 */     if (function.isAllColumns())
/* 264:    */     {
/* 265:263 */       this.buffer.append("(*)");
/* 266:    */     }
/* 267:264 */     else if (function.getParameters() == null)
/* 268:    */     {
/* 269:265 */       this.buffer.append("()");
/* 270:    */     }
/* 271:    */     else
/* 272:    */     {
/* 273:267 */       boolean oldUseBracketsInExprList = this.useBracketsInExprList;
/* 274:268 */       if (function.isDistinct())
/* 275:    */       {
/* 276:269 */         this.useBracketsInExprList = false;
/* 277:270 */         this.buffer.append("(DISTINCT ");
/* 278:    */       }
/* 279:272 */       visit(function.getParameters());
/* 280:273 */       this.useBracketsInExprList = oldUseBracketsInExprList;
/* 281:274 */       if (function.isDistinct()) {
/* 282:275 */         this.buffer.append(")");
/* 283:    */       }
/* 284:    */     }
/* 285:279 */     if (function.isEscaped()) {
/* 286:280 */       this.buffer.append("}");
/* 287:    */     }
/* 288:    */   }
/* 289:    */   
/* 290:    */   public void visit(ExpressionList expressionList)
/* 291:    */   {
/* 292:286 */     if (this.useBracketsInExprList) {
/* 293:287 */       this.buffer.append("(");
/* 294:    */     }
/* 295:288 */     for (Iterator iter = expressionList.getExpressions().iterator(); iter.hasNext();)
/* 296:    */     {
/* 297:289 */       Expression expression = (Expression)iter.next();
/* 298:290 */       expression.accept(this);
/* 299:291 */       if (iter.hasNext()) {
/* 300:292 */         this.buffer.append(", ");
/* 301:    */       }
/* 302:    */     }
/* 303:294 */     if (this.useBracketsInExprList) {
/* 304:295 */       this.buffer.append(")");
/* 305:    */     }
/* 306:    */   }
/* 307:    */   
/* 308:    */   public SelectVisitor getSelectVisitor()
/* 309:    */   {
/* 310:300 */     return this.selectVisitor;
/* 311:    */   }
/* 312:    */   
/* 313:    */   public void setSelectVisitor(SelectVisitor visitor)
/* 314:    */   {
/* 315:304 */     this.selectVisitor = visitor;
/* 316:    */   }
/* 317:    */   
/* 318:    */   public void visit(DateValue dateValue)
/* 319:    */   {
/* 320:308 */     this.buffer.append("{d '" + dateValue.getValue().toString() + "'}");
/* 321:    */   }
/* 322:    */   
/* 323:    */   public void visit(TimestampValue timestampValue)
/* 324:    */   {
/* 325:311 */     this.buffer.append("{ts '" + timestampValue.getValue().toString() + "'}");
/* 326:    */   }
/* 327:    */   
/* 328:    */   public void visit(TimeValue timeValue)
/* 329:    */   {
/* 330:314 */     this.buffer.append("{t '" + timeValue.getValue().toString() + "'}");
/* 331:    */   }
/* 332:    */   
/* 333:    */   public void visit(CaseExpression caseExpression)
/* 334:    */   {
/* 335:318 */     this.buffer.append("CASE ");
/* 336:319 */     Expression switchExp = caseExpression.getSwitchExpression();
/* 337:320 */     if (switchExp != null) {
/* 338:321 */       switchExp.accept(this);
/* 339:    */     }
/* 340:324 */     List clauses = caseExpression.getWhenClauses();
/* 341:325 */     for (Iterator iter = clauses.iterator(); iter.hasNext();)
/* 342:    */     {
/* 343:326 */       Expression exp = (Expression)iter.next();
/* 344:327 */       exp.accept(this);
/* 345:    */     }
/* 346:330 */     Expression elseExp = caseExpression.getElseExpression();
/* 347:331 */     if (elseExp != null) {
/* 348:332 */       elseExp.accept(this);
/* 349:    */     }
/* 350:335 */     this.buffer.append(" END");
/* 351:    */   }
/* 352:    */   
/* 353:    */   public void visit(WhenClause whenClause)
/* 354:    */   {
/* 355:339 */     this.buffer.append(" WHEN ");
/* 356:340 */     whenClause.getWhenExpression().accept(this);
/* 357:341 */     this.buffer.append(" THEN ");
/* 358:342 */     whenClause.getThenExpression().accept(this);
/* 359:    */   }
/* 360:    */   
/* 361:    */   public void visit(AllComparisonExpression allComparisonExpression)
/* 362:    */   {
/* 363:346 */     this.buffer.append(" ALL ");
/* 364:347 */     allComparisonExpression.getSubSelect().accept(this);
/* 365:    */   }
/* 366:    */   
/* 367:    */   public void visit(AnyComparisonExpression anyComparisonExpression)
/* 368:    */   {
/* 369:351 */     this.buffer.append(" ANY ");
/* 370:352 */     anyComparisonExpression.getSubSelect().accept(this);
/* 371:    */   }
/* 372:    */   
/* 373:    */   public void visit(Concat concat)
/* 374:    */   {
/* 375:356 */     visitBinaryExpression(concat, " || ");
/* 376:    */   }
/* 377:    */   
/* 378:    */   public void visit(Matches matches)
/* 379:    */   {
/* 380:360 */     visitBinaryExpression(matches, " @@ ");
/* 381:    */   }
/* 382:    */   
/* 383:    */   public void visit(BitwiseAnd bitwiseAnd)
/* 384:    */   {
/* 385:364 */     visitBinaryExpression(bitwiseAnd, " & ");
/* 386:    */   }
/* 387:    */   
/* 388:    */   public void visit(BitwiseOr bitwiseOr)
/* 389:    */   {
/* 390:368 */     visitBinaryExpression(bitwiseOr, " | ");
/* 391:    */   }
/* 392:    */   
/* 393:    */   public void visit(BitwiseXor bitwiseXor)
/* 394:    */   {
/* 395:372 */     visitBinaryExpression(bitwiseXor, " ^ ");
/* 396:    */   }
/* 397:    */ }


/* Location:           E:\workspace\java\db\lib\jsqlparser.jar
 * Qualified Name:     net.sf.jsqlparser.util.deparser.ExpressionDeParser
 * JD-Core Version:    0.7.0.1
 */