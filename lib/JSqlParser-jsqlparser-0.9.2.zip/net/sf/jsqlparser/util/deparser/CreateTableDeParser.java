/*  1:   */ package net.sf.jsqlparser.util.deparser;
/*  2:   */ 
/*  3:   */ import java.util.Iterator;
/*  4:   */ import java.util.List;
/*  5:   */ import net.sf.jsqlparser.schema.Table;
/*  6:   */ import net.sf.jsqlparser.statement.create.table.ColDataType;
/*  7:   */ import net.sf.jsqlparser.statement.create.table.ColumnDefinition;
/*  8:   */ import net.sf.jsqlparser.statement.create.table.CreateTable;
/*  9:   */ import net.sf.jsqlparser.statement.create.table.Index;
/* 10:   */ 
/* 11:   */ public class CreateTableDeParser
/* 12:   */ {
/* 13:   */   protected StringBuffer buffer;
/* 14:   */   
/* 15:   */   public CreateTableDeParser(StringBuffer buffer)
/* 16:   */   {
/* 17:20 */     this.buffer = buffer;
/* 18:   */   }
/* 19:   */   
/* 20:   */   public void deParse(CreateTable createTable)
/* 21:   */   {
/* 22:24 */     this.buffer.append("CREATE TABLE " + createTable.getTable().getWholeTableName());
/* 23:25 */     if (createTable.getColumnDefinitions() != null)
/* 24:   */     {
/* 25:26 */       this.buffer.append(" { ");
/* 26:27 */       for (Iterator iter = createTable.getColumnDefinitions().iterator(); iter.hasNext();)
/* 27:   */       {
/* 28:28 */         ColumnDefinition columnDefinition = (ColumnDefinition)iter.next();
/* 29:29 */         this.buffer.append(columnDefinition.getColumnName());
/* 30:30 */         this.buffer.append(" ");
/* 31:31 */         this.buffer.append(columnDefinition.getColDataType().getDataType());
/* 32:   */         Iterator iterator;
/* 33:32 */         if (columnDefinition.getColDataType().getArgumentsStringList() != null) {
/* 34:33 */           for (iterator = columnDefinition.getColDataType().getArgumentsStringList().iterator(); iterator.hasNext();)
/* 35:   */           {
/* 36:34 */             this.buffer.append(" ");
/* 37:35 */             this.buffer.append((String)iterator.next());
/* 38:   */           }
/* 39:   */         }
/* 40:   */         Iterator iterator;
/* 41:38 */         if (columnDefinition.getColumnSpecStrings() != null) {
/* 42:39 */           for (iterator = columnDefinition.getColumnSpecStrings().iterator(); iterator.hasNext();)
/* 43:   */           {
/* 44:40 */             this.buffer.append(" ");
/* 45:41 */             this.buffer.append((String)iterator.next());
/* 46:   */           }
/* 47:   */         }
/* 48:45 */         if (iter.hasNext()) {
/* 49:46 */           this.buffer.append(",\n");
/* 50:   */         }
/* 51:   */       }
/* 52:50 */       for (Iterator iter = createTable.getIndexes().iterator(); iter.hasNext();)
/* 53:   */       {
/* 54:51 */         this.buffer.append(",\n");
/* 55:52 */         Index index = (Index)iter.next();
/* 56:53 */         this.buffer.append(index.getType() + " " + index.getName());
/* 57:54 */         this.buffer.append("(");
/* 58:55 */         for (Iterator iterator = index.getColumnsNames().iterator(); iterator.hasNext();)
/* 59:   */         {
/* 60:56 */           this.buffer.append((String)iterator.next());
/* 61:57 */           if (iterator.hasNext()) {
/* 62:58 */             this.buffer.append(", ");
/* 63:   */           }
/* 64:   */         }
/* 65:61 */         this.buffer.append(")");
/* 66:63 */         if (iter.hasNext()) {
/* 67:64 */           this.buffer.append(",\n");
/* 68:   */         }
/* 69:   */       }
/* 70:67 */       this.buffer.append(" \n} ");
/* 71:   */     }
/* 72:   */   }
/* 73:   */   
/* 74:   */   public StringBuffer getBuffer()
/* 75:   */   {
/* 76:72 */     return this.buffer;
/* 77:   */   }
/* 78:   */   
/* 79:   */   public void setBuffer(StringBuffer buffer)
/* 80:   */   {
/* 81:76 */     this.buffer = buffer;
/* 82:   */   }
/* 83:   */ }


/* Location:           E:\workspace\java\db\lib\jsqlparser.jar
 * Qualified Name:     net.sf.jsqlparser.util.deparser.CreateTableDeParser
 * JD-Core Version:    0.7.0.1
 */