/*   1:    */ package net.sf.jsqlparser.util.deparser;
/*   2:    */ 
/*   3:    */ import java.util.Iterator;
/*   4:    */ import java.util.List;
/*   5:    */ import net.sf.jsqlparser.expression.Expression;
/*   6:    */ import net.sf.jsqlparser.expression.ExpressionVisitor;
/*   7:    */ import net.sf.jsqlparser.expression.operators.relational.ExpressionList;
/*   8:    */ import net.sf.jsqlparser.expression.operators.relational.ItemsListVisitor;
/*   9:    */ import net.sf.jsqlparser.schema.Column;
/*  10:    */ import net.sf.jsqlparser.schema.Table;
/*  11:    */ import net.sf.jsqlparser.statement.replace.Replace;
/*  12:    */ import net.sf.jsqlparser.statement.select.SelectBody;
/*  13:    */ import net.sf.jsqlparser.statement.select.SelectVisitor;
/*  14:    */ import net.sf.jsqlparser.statement.select.SubSelect;
/*  15:    */ 
/*  16:    */ public class ReplaceDeParser
/*  17:    */   implements ItemsListVisitor
/*  18:    */ {
/*  19:    */   protected StringBuffer buffer;
/*  20:    */   protected ExpressionVisitor expressionVisitor;
/*  21:    */   protected SelectVisitor selectVisitor;
/*  22:    */   
/*  23:    */   public ReplaceDeParser() {}
/*  24:    */   
/*  25:    */   public ReplaceDeParser(ExpressionVisitor expressionVisitor, SelectVisitor selectVisitor, StringBuffer buffer)
/*  26:    */   {
/*  27: 35 */     this.buffer = buffer;
/*  28: 36 */     this.expressionVisitor = expressionVisitor;
/*  29: 37 */     this.selectVisitor = selectVisitor;
/*  30:    */   }
/*  31:    */   
/*  32:    */   public StringBuffer getBuffer()
/*  33:    */   {
/*  34: 41 */     return this.buffer;
/*  35:    */   }
/*  36:    */   
/*  37:    */   public void setBuffer(StringBuffer buffer)
/*  38:    */   {
/*  39: 45 */     this.buffer = buffer;
/*  40:    */   }
/*  41:    */   
/*  42:    */   public void deParse(Replace replace)
/*  43:    */   {
/*  44: 49 */     this.buffer.append("REPLACE " + replace.getTable().getWholeTableName());
/*  45: 50 */     if (replace.getItemsList() != null)
/*  46:    */     {
/*  47: 51 */       if (replace.getColumns() != null)
/*  48:    */       {
/*  49: 52 */         this.buffer.append(" (");
/*  50: 53 */         for (int i = 0; i < replace.getColumns().size(); i++)
/*  51:    */         {
/*  52: 54 */           Column column = (Column)replace.getColumns().get(i);
/*  53: 55 */           this.buffer.append(column.getWholeColumnName());
/*  54: 56 */           if (i < replace.getColumns().size() - 1) {
/*  55: 57 */             this.buffer.append(", ");
/*  56:    */           }
/*  57:    */         }
/*  58: 60 */         this.buffer.append(") ");
/*  59:    */       }
/*  60:    */       else
/*  61:    */       {
/*  62: 62 */         this.buffer.append(" ");
/*  63:    */       }
/*  64:    */     }
/*  65:    */     else
/*  66:    */     {
/*  67: 66 */       this.buffer.append(" SET ");
/*  68: 67 */       for (int i = 0; i < replace.getColumns().size(); i++)
/*  69:    */       {
/*  70: 68 */         Column column = (Column)replace.getColumns().get(i);
/*  71: 69 */         this.buffer.append(column.getWholeColumnName() + "=");
/*  72:    */         
/*  73: 71 */         Expression expression = (Expression)replace.getExpressions().get(i);
/*  74: 72 */         expression.accept(this.expressionVisitor);
/*  75: 73 */         if (i < replace.getColumns().size() - 1) {
/*  76: 74 */           this.buffer.append(", ");
/*  77:    */         }
/*  78:    */       }
/*  79:    */     }
/*  80:    */   }
/*  81:    */   
/*  82:    */   public void visit(ExpressionList expressionList)
/*  83:    */   {
/*  84: 83 */     this.buffer.append(" VALUES (");
/*  85: 84 */     for (Iterator iter = expressionList.getExpressions().iterator(); iter.hasNext();)
/*  86:    */     {
/*  87: 85 */       Expression expression = (Expression)iter.next();
/*  88: 86 */       expression.accept(this.expressionVisitor);
/*  89: 87 */       if (iter.hasNext()) {
/*  90: 88 */         this.buffer.append(", ");
/*  91:    */       }
/*  92:    */     }
/*  93: 90 */     this.buffer.append(")");
/*  94:    */   }
/*  95:    */   
/*  96:    */   public void visit(SubSelect subSelect)
/*  97:    */   {
/*  98: 94 */     subSelect.getSelectBody().accept(this.selectVisitor);
/*  99:    */   }
/* 100:    */   
/* 101:    */   public ExpressionVisitor getExpressionVisitor()
/* 102:    */   {
/* 103: 98 */     return this.expressionVisitor;
/* 104:    */   }
/* 105:    */   
/* 106:    */   public SelectVisitor getSelectVisitor()
/* 107:    */   {
/* 108:102 */     return this.selectVisitor;
/* 109:    */   }
/* 110:    */   
/* 111:    */   public void setExpressionVisitor(ExpressionVisitor visitor)
/* 112:    */   {
/* 113:106 */     this.expressionVisitor = visitor;
/* 114:    */   }
/* 115:    */   
/* 116:    */   public void setSelectVisitor(SelectVisitor visitor)
/* 117:    */   {
/* 118:110 */     this.selectVisitor = visitor;
/* 119:    */   }
/* 120:    */ }


/* Location:           E:\workspace\java\db\lib\jsqlparser.jar
 * Qualified Name:     net.sf.jsqlparser.util.deparser.ReplaceDeParser
 * JD-Core Version:    0.7.0.1
 */