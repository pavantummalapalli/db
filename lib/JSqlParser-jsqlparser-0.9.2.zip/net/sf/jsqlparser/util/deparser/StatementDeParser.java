/*   1:    */ package net.sf.jsqlparser.util.deparser;
/*   2:    */ 
/*   3:    */ import java.util.Iterator;
/*   4:    */ import java.util.List;
/*   5:    */ import net.sf.jsqlparser.statement.StatementVisitor;
/*   6:    */ import net.sf.jsqlparser.statement.create.table.CreateTable;
/*   7:    */ import net.sf.jsqlparser.statement.delete.Delete;
/*   8:    */ import net.sf.jsqlparser.statement.drop.Drop;
/*   9:    */ import net.sf.jsqlparser.statement.insert.Insert;
/*  10:    */ import net.sf.jsqlparser.statement.replace.Replace;
/*  11:    */ import net.sf.jsqlparser.statement.select.Select;
/*  12:    */ import net.sf.jsqlparser.statement.select.SelectBody;
/*  13:    */ import net.sf.jsqlparser.statement.select.WithItem;
/*  14:    */ import net.sf.jsqlparser.statement.truncate.Truncate;
/*  15:    */ import net.sf.jsqlparser.statement.update.Update;
/*  16:    */ 
/*  17:    */ public class StatementDeParser
/*  18:    */   implements StatementVisitor
/*  19:    */ {
/*  20:    */   protected StringBuffer buffer;
/*  21:    */   
/*  22:    */   public StatementDeParser(StringBuffer buffer)
/*  23:    */   {
/*  24: 20 */     this.buffer = buffer;
/*  25:    */   }
/*  26:    */   
/*  27:    */   public void visit(CreateTable createTable)
/*  28:    */   {
/*  29: 24 */     CreateTableDeParser createTableDeParser = new CreateTableDeParser(this.buffer);
/*  30: 25 */     createTableDeParser.deParse(createTable);
/*  31:    */   }
/*  32:    */   
/*  33:    */   public void visit(Delete delete)
/*  34:    */   {
/*  35: 29 */     SelectDeParser selectDeParser = new SelectDeParser();
/*  36: 30 */     selectDeParser.setBuffer(this.buffer);
/*  37: 31 */     ExpressionDeParser expressionDeParser = new ExpressionDeParser(selectDeParser, this.buffer);
/*  38: 32 */     selectDeParser.setExpressionVisitor(expressionDeParser);
/*  39: 33 */     DeleteDeParser deleteDeParser = new DeleteDeParser(expressionDeParser, this.buffer);
/*  40: 34 */     deleteDeParser.deParse(delete);
/*  41:    */   }
/*  42:    */   
/*  43:    */   public void visit(Drop drop) {}
/*  44:    */   
/*  45:    */   public void visit(Insert insert)
/*  46:    */   {
/*  47: 43 */     SelectDeParser selectDeParser = new SelectDeParser();
/*  48: 44 */     selectDeParser.setBuffer(this.buffer);
/*  49: 45 */     ExpressionDeParser expressionDeParser = new ExpressionDeParser(selectDeParser, this.buffer);
/*  50: 46 */     selectDeParser.setExpressionVisitor(expressionDeParser);
/*  51: 47 */     InsertDeParser insertDeParser = new InsertDeParser(expressionDeParser, selectDeParser, this.buffer);
/*  52: 48 */     insertDeParser.deParse(insert);
/*  53:    */   }
/*  54:    */   
/*  55:    */   public void visit(Replace replace)
/*  56:    */   {
/*  57: 53 */     SelectDeParser selectDeParser = new SelectDeParser();
/*  58: 54 */     selectDeParser.setBuffer(this.buffer);
/*  59: 55 */     ExpressionDeParser expressionDeParser = new ExpressionDeParser(selectDeParser, this.buffer);
/*  60: 56 */     selectDeParser.setExpressionVisitor(expressionDeParser);
/*  61: 57 */     ReplaceDeParser replaceDeParser = new ReplaceDeParser(expressionDeParser, selectDeParser, this.buffer);
/*  62: 58 */     replaceDeParser.deParse(replace);
/*  63:    */   }
/*  64:    */   
/*  65:    */   public void visit(Select select)
/*  66:    */   {
/*  67: 62 */     SelectDeParser selectDeParser = new SelectDeParser();
/*  68: 63 */     selectDeParser.setBuffer(this.buffer);
/*  69: 64 */     ExpressionDeParser expressionDeParser = new ExpressionDeParser(selectDeParser, this.buffer);
/*  70: 65 */     selectDeParser.setExpressionVisitor(expressionDeParser);
/*  71:    */     Iterator iter;
/*  72: 66 */     if ((select.getWithItemsList() != null) && (!select.getWithItemsList().isEmpty()))
/*  73:    */     {
/*  74: 67 */       this.buffer.append("WITH ");
/*  75: 68 */       for (iter = select.getWithItemsList().iterator(); iter.hasNext();)
/*  76:    */       {
/*  77: 69 */         WithItem withItem = (WithItem)iter.next();
/*  78: 70 */         this.buffer.append(withItem);
/*  79: 71 */         if (iter.hasNext()) {
/*  80: 72 */           this.buffer.append(",");
/*  81:    */         }
/*  82: 73 */         this.buffer.append(" ");
/*  83:    */       }
/*  84:    */     }
/*  85: 76 */     select.getSelectBody().accept(selectDeParser);
/*  86:    */   }
/*  87:    */   
/*  88:    */   public void visit(Truncate truncate) {}
/*  89:    */   
/*  90:    */   public void visit(Update update)
/*  91:    */   {
/*  92: 86 */     SelectDeParser selectDeParser = new SelectDeParser();
/*  93: 87 */     selectDeParser.setBuffer(this.buffer);
/*  94: 88 */     ExpressionDeParser expressionDeParser = new ExpressionDeParser(selectDeParser, this.buffer);
/*  95: 89 */     UpdateDeParser updateDeParser = new UpdateDeParser(expressionDeParser, this.buffer);
/*  96: 90 */     selectDeParser.setExpressionVisitor(expressionDeParser);
/*  97: 91 */     updateDeParser.deParse(update);
/*  98:    */   }
/*  99:    */   
/* 100:    */   public StringBuffer getBuffer()
/* 101:    */   {
/* 102: 96 */     return this.buffer;
/* 103:    */   }
/* 104:    */   
/* 105:    */   public void setBuffer(StringBuffer buffer)
/* 106:    */   {
/* 107:100 */     this.buffer = buffer;
/* 108:    */   }
/* 109:    */ }


/* Location:           E:\workspace\java\db\lib\jsqlparser.jar
 * Qualified Name:     net.sf.jsqlparser.util.deparser.StatementDeParser
 * JD-Core Version:    0.7.0.1
 */