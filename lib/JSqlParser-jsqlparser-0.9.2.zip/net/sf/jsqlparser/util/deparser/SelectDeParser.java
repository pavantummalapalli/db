/*   1:    */ package net.sf.jsqlparser.util.deparser;
/*   2:    */ 
/*   3:    */ import java.util.Iterator;
/*   4:    */ import java.util.List;
/*   5:    */ import net.sf.jsqlparser.expression.Expression;
/*   6:    */ import net.sf.jsqlparser.expression.ExpressionVisitor;
/*   7:    */ import net.sf.jsqlparser.schema.Column;
/*   8:    */ import net.sf.jsqlparser.schema.Table;
/*   9:    */ import net.sf.jsqlparser.statement.select.AllColumns;
/*  10:    */ import net.sf.jsqlparser.statement.select.AllTableColumns;
/*  11:    */ import net.sf.jsqlparser.statement.select.Distinct;
/*  12:    */ import net.sf.jsqlparser.statement.select.FromItem;
/*  13:    */ import net.sf.jsqlparser.statement.select.FromItemVisitor;
/*  14:    */ import net.sf.jsqlparser.statement.select.Join;
/*  15:    */ import net.sf.jsqlparser.statement.select.Limit;
/*  16:    */ import net.sf.jsqlparser.statement.select.OrderByElement;
/*  17:    */ import net.sf.jsqlparser.statement.select.OrderByVisitor;
/*  18:    */ import net.sf.jsqlparser.statement.select.PlainSelect;
/*  19:    */ import net.sf.jsqlparser.statement.select.SelectBody;
/*  20:    */ import net.sf.jsqlparser.statement.select.SelectExpressionItem;
/*  21:    */ import net.sf.jsqlparser.statement.select.SelectItem;
/*  22:    */ import net.sf.jsqlparser.statement.select.SelectItemVisitor;
/*  23:    */ import net.sf.jsqlparser.statement.select.SelectVisitor;
/*  24:    */ import net.sf.jsqlparser.statement.select.SubJoin;
/*  25:    */ import net.sf.jsqlparser.statement.select.SubSelect;
/*  26:    */ import net.sf.jsqlparser.statement.select.Top;
/*  27:    */ import net.sf.jsqlparser.statement.select.Union;
/*  28:    */ 
/*  29:    */ public class SelectDeParser
/*  30:    */   implements SelectVisitor, OrderByVisitor, SelectItemVisitor, FromItemVisitor
/*  31:    */ {
/*  32:    */   protected StringBuffer buffer;
/*  33:    */   protected ExpressionVisitor expressionVisitor;
/*  34:    */   
/*  35:    */   public SelectDeParser() {}
/*  36:    */   
/*  37:    */   public SelectDeParser(ExpressionVisitor expressionVisitor, StringBuffer buffer)
/*  38:    */   {
/*  39: 45 */     this.buffer = buffer;
/*  40: 46 */     this.expressionVisitor = expressionVisitor;
/*  41:    */   }
/*  42:    */   
/*  43:    */   public void visit(PlainSelect plainSelect)
/*  44:    */   {
/*  45: 50 */     this.buffer.append("SELECT ");
/*  46: 51 */     Top top = plainSelect.getTop();
/*  47: 52 */     if (top != null) {
/*  48: 53 */       top.toString();
/*  49:    */     }
/*  50: 54 */     if (plainSelect.getDistinct() != null)
/*  51:    */     {
/*  52: 55 */       this.buffer.append("DISTINCT ");
/*  53: 56 */       if (plainSelect.getDistinct().getOnSelectItems() != null)
/*  54:    */       {
/*  55: 57 */         this.buffer.append("ON (");
/*  56: 58 */         for (Iterator iter = plainSelect.getDistinct().getOnSelectItems().iterator(); iter.hasNext();)
/*  57:    */         {
/*  58: 59 */           SelectItem selectItem = (SelectItem)iter.next();
/*  59: 60 */           selectItem.accept(this);
/*  60: 61 */           if (iter.hasNext()) {
/*  61: 62 */             this.buffer.append(", ");
/*  62:    */           }
/*  63:    */         }
/*  64: 65 */         this.buffer.append(") ");
/*  65:    */       }
/*  66:    */     }
/*  67: 70 */     for (Iterator iter = plainSelect.getSelectItems().iterator(); iter.hasNext();)
/*  68:    */     {
/*  69: 71 */       SelectItem selectItem = (SelectItem)iter.next();
/*  70: 72 */       selectItem.accept(this);
/*  71: 73 */       if (iter.hasNext()) {
/*  72: 74 */         this.buffer.append(", ");
/*  73:    */       }
/*  74:    */     }
/*  75: 78 */     this.buffer.append(" ");
/*  76: 80 */     if (plainSelect.getFromItem() != null)
/*  77:    */     {
/*  78: 81 */       this.buffer.append("FROM ");
/*  79: 82 */       plainSelect.getFromItem().accept(this);
/*  80:    */     }
/*  81:    */     Iterator iter;
/*  82: 85 */     if (plainSelect.getJoins() != null) {
/*  83: 86 */       for (iter = plainSelect.getJoins().iterator(); iter.hasNext();)
/*  84:    */       {
/*  85: 87 */         Join join = (Join)iter.next();
/*  86: 88 */         deparseJoin(join);
/*  87:    */       }
/*  88:    */     }
/*  89: 92 */     if (plainSelect.getWhere() != null)
/*  90:    */     {
/*  91: 93 */       this.buffer.append(" WHERE ");
/*  92: 94 */       plainSelect.getWhere().accept(this.expressionVisitor);
/*  93:    */     }
/*  94:    */     Iterator iter;
/*  95: 97 */     if (plainSelect.getGroupByColumnReferences() != null)
/*  96:    */     {
/*  97: 98 */       this.buffer.append(" GROUP BY ");
/*  98: 99 */       for (iter = plainSelect.getGroupByColumnReferences().iterator(); iter.hasNext();)
/*  99:    */       {
/* 100:100 */         Expression columnReference = (Expression)iter.next();
/* 101:101 */         columnReference.accept(this.expressionVisitor);
/* 102:102 */         if (iter.hasNext()) {
/* 103:103 */           this.buffer.append(", ");
/* 104:    */         }
/* 105:    */       }
/* 106:    */     }
/* 107:108 */     if (plainSelect.getHaving() != null)
/* 108:    */     {
/* 109:109 */       this.buffer.append(" HAVING ");
/* 110:110 */       plainSelect.getHaving().accept(this.expressionVisitor);
/* 111:    */     }
/* 112:113 */     if (plainSelect.getOrderByElements() != null) {
/* 113:114 */       deparseOrderBy(plainSelect.getOrderByElements());
/* 114:    */     }
/* 115:117 */     if (plainSelect.getLimit() != null) {
/* 116:118 */       deparseLimit(plainSelect.getLimit());
/* 117:    */     }
/* 118:    */   }
/* 119:    */   
/* 120:    */   public void visit(Union union)
/* 121:    */   {
/* 122:124 */     for (Iterator iter = union.getPlainSelects().iterator(); iter.hasNext();)
/* 123:    */     {
/* 124:125 */       this.buffer.append("(");
/* 125:126 */       PlainSelect plainSelect = (PlainSelect)iter.next();
/* 126:127 */       plainSelect.accept(this);
/* 127:128 */       this.buffer.append(")");
/* 128:129 */       if (iter.hasNext()) {
/* 129:130 */         this.buffer.append(" UNION ");
/* 130:    */       }
/* 131:    */     }
/* 132:135 */     if (union.getOrderByElements() != null) {
/* 133:136 */       deparseOrderBy(union.getOrderByElements());
/* 134:    */     }
/* 135:139 */     if (union.getLimit() != null) {
/* 136:140 */       deparseLimit(union.getLimit());
/* 137:    */     }
/* 138:    */   }
/* 139:    */   
/* 140:    */   public void visit(OrderByElement orderBy)
/* 141:    */   {
/* 142:146 */     orderBy.getExpression().accept(this.expressionVisitor);
/* 143:147 */     if (orderBy.isAsc()) {
/* 144:148 */       this.buffer.append(" ASC");
/* 145:    */     } else {
/* 146:150 */       this.buffer.append(" DESC");
/* 147:    */     }
/* 148:    */   }
/* 149:    */   
/* 150:    */   public void visit(Column column)
/* 151:    */   {
/* 152:154 */     this.buffer.append(column.getWholeColumnName());
/* 153:    */   }
/* 154:    */   
/* 155:    */   public void visit(AllColumns allColumns)
/* 156:    */   {
/* 157:158 */     this.buffer.append("*");
/* 158:    */   }
/* 159:    */   
/* 160:    */   public void visit(AllTableColumns allTableColumns)
/* 161:    */   {
/* 162:162 */     this.buffer.append(allTableColumns.getTable().getWholeTableName() + ".*");
/* 163:    */   }
/* 164:    */   
/* 165:    */   public void visit(SelectExpressionItem selectExpressionItem)
/* 166:    */   {
/* 167:166 */     selectExpressionItem.getExpression().accept(this.expressionVisitor);
/* 168:167 */     if (selectExpressionItem.getAlias() != null) {
/* 169:168 */       this.buffer.append(" AS " + selectExpressionItem.getAlias());
/* 170:    */     }
/* 171:    */   }
/* 172:    */   
/* 173:    */   public void visit(SubSelect subSelect)
/* 174:    */   {
/* 175:174 */     this.buffer.append("(");
/* 176:175 */     subSelect.getSelectBody().accept(this);
/* 177:176 */     this.buffer.append(")");
/* 178:    */   }
/* 179:    */   
/* 180:    */   public void visit(Table tableName)
/* 181:    */   {
/* 182:180 */     this.buffer.append(tableName.getWholeTableName());
/* 183:181 */     String alias = tableName.getAlias();
/* 184:182 */     if ((alias != null) && (!alias.isEmpty())) {
/* 185:183 */       this.buffer.append(" AS " + alias);
/* 186:    */     }
/* 187:    */   }
/* 188:    */   
/* 189:    */   public void deparseOrderBy(List orderByElements)
/* 190:    */   {
/* 191:188 */     this.buffer.append(" ORDER BY ");
/* 192:189 */     for (Iterator iter = orderByElements.iterator(); iter.hasNext();)
/* 193:    */     {
/* 194:190 */       OrderByElement orderByElement = (OrderByElement)iter.next();
/* 195:191 */       orderByElement.accept(this);
/* 196:192 */       if (iter.hasNext()) {
/* 197:193 */         this.buffer.append(", ");
/* 198:    */       }
/* 199:    */     }
/* 200:    */   }
/* 201:    */   
/* 202:    */   public void deparseLimit(Limit limit)
/* 203:    */   {
/* 204:200 */     this.buffer.append(" LIMIT ");
/* 205:201 */     if (limit.isRowCountJdbcParameter()) {
/* 206:202 */       this.buffer.append("?");
/* 207:203 */     } else if (limit.getRowCount() != 0L) {
/* 208:204 */       this.buffer.append(limit.getRowCount());
/* 209:    */     } else {
/* 210:212 */       this.buffer.append("18446744073709551615");
/* 211:    */     }
/* 212:215 */     if (limit.isOffsetJdbcParameter()) {
/* 213:216 */       this.buffer.append(" OFFSET ?");
/* 214:217 */     } else if (limit.getOffset() != 0L) {
/* 215:218 */       this.buffer.append(" OFFSET " + limit.getOffset());
/* 216:    */     }
/* 217:    */   }
/* 218:    */   
/* 219:    */   public StringBuffer getBuffer()
/* 220:    */   {
/* 221:224 */     return this.buffer;
/* 222:    */   }
/* 223:    */   
/* 224:    */   public void setBuffer(StringBuffer buffer)
/* 225:    */   {
/* 226:228 */     this.buffer = buffer;
/* 227:    */   }
/* 228:    */   
/* 229:    */   public ExpressionVisitor getExpressionVisitor()
/* 230:    */   {
/* 231:232 */     return this.expressionVisitor;
/* 232:    */   }
/* 233:    */   
/* 234:    */   public void setExpressionVisitor(ExpressionVisitor visitor)
/* 235:    */   {
/* 236:236 */     this.expressionVisitor = visitor;
/* 237:    */   }
/* 238:    */   
/* 239:    */   public void visit(SubJoin subjoin)
/* 240:    */   {
/* 241:240 */     this.buffer.append("(");
/* 242:241 */     subjoin.getLeft().accept(this);
/* 243:242 */     this.buffer.append(" ");
/* 244:243 */     deparseJoin(subjoin.getJoin());
/* 245:244 */     this.buffer.append(")");
/* 246:    */   }
/* 247:    */   
/* 248:    */   public void deparseJoin(Join join)
/* 249:    */   {
/* 250:248 */     if (join.isSimple())
/* 251:    */     {
/* 252:249 */       this.buffer.append(", ");
/* 253:    */     }
/* 254:    */     else
/* 255:    */     {
/* 256:253 */       if (join.isRight()) {
/* 257:254 */         this.buffer.append("RIGHT ");
/* 258:255 */       } else if (join.isNatural()) {
/* 259:256 */         this.buffer.append("NATURAL ");
/* 260:257 */       } else if (join.isFull()) {
/* 261:258 */         this.buffer.append("FULL ");
/* 262:259 */       } else if (join.isLeft()) {
/* 263:260 */         this.buffer.append("LEFT ");
/* 264:    */       }
/* 265:262 */       if (join.isOuter()) {
/* 266:263 */         this.buffer.append("OUTER ");
/* 267:264 */       } else if (join.isInner()) {
/* 268:265 */         this.buffer.append("INNER ");
/* 269:    */       }
/* 270:267 */       this.buffer.append("JOIN ");
/* 271:    */     }
/* 272:271 */     FromItem fromItem = join.getRightItem();
/* 273:272 */     fromItem.accept(this);
/* 274:273 */     if (join.getOnExpression() != null)
/* 275:    */     {
/* 276:274 */       this.buffer.append(" ON ");
/* 277:275 */       join.getOnExpression().accept(this.expressionVisitor);
/* 278:    */     }
/* 279:277 */     if (join.getUsingColumns() != null)
/* 280:    */     {
/* 281:278 */       this.buffer.append(" USING ( ");
/* 282:279 */       for (Iterator iterator = join.getUsingColumns().iterator(); iterator.hasNext();)
/* 283:    */       {
/* 284:280 */         Column column = (Column)iterator.next();
/* 285:281 */         this.buffer.append(column.getWholeColumnName());
/* 286:282 */         if (iterator.hasNext()) {
/* 287:283 */           this.buffer.append(" ,");
/* 288:    */         }
/* 289:    */       }
/* 290:286 */       this.buffer.append(")");
/* 291:    */     }
/* 292:    */   }
/* 293:    */ }


/* Location:           E:\workspace\java\db\lib\jsqlparser.jar
 * Qualified Name:     net.sf.jsqlparser.util.deparser.SelectDeParser
 * JD-Core Version:    0.7.0.1
 */