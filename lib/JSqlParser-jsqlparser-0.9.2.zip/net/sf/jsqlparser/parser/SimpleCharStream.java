/*   1:    */ package net.sf.jsqlparser.parser;
/*   2:    */ 
/*   3:    */ import java.io.IOException;
/*   4:    */ import java.io.InputStream;
/*   5:    */ import java.io.InputStreamReader;
/*   6:    */ import java.io.Reader;
/*   7:    */ import java.io.UnsupportedEncodingException;
/*   8:    */ 
/*   9:    */ public class SimpleCharStream
/*  10:    */ {
/*  11:    */   public static final boolean staticFlag = false;
/*  12:    */   int bufsize;
/*  13:    */   int available;
/*  14:    */   int tokenBegin;
/*  15: 41 */   public int bufpos = -1;
/*  16:    */   protected int[] bufline;
/*  17:    */   protected int[] bufcolumn;
/*  18: 45 */   protected int column = 0;
/*  19: 46 */   protected int line = 1;
/*  20: 48 */   protected boolean prevCharIsCR = false;
/*  21: 49 */   protected boolean prevCharIsLF = false;
/*  22:    */   protected Reader inputStream;
/*  23:    */   protected char[] buffer;
/*  24: 54 */   protected int maxNextCharInd = 0;
/*  25: 55 */   protected int inBuf = 0;
/*  26: 56 */   protected int tabSize = 8;
/*  27:    */   
/*  28:    */   protected void setTabSize(int i)
/*  29:    */   {
/*  30: 58 */     this.tabSize = i;
/*  31:    */   }
/*  32:    */   
/*  33:    */   protected int getTabSize(int i)
/*  34:    */   {
/*  35: 59 */     return this.tabSize;
/*  36:    */   }
/*  37:    */   
/*  38:    */   protected void ExpandBuff(boolean wrapAround)
/*  39:    */   {
/*  40: 64 */     char[] newbuffer = new char[this.bufsize + 2048];
/*  41: 65 */     int[] newbufline = new int[this.bufsize + 2048];
/*  42: 66 */     int[] newbufcolumn = new int[this.bufsize + 2048];
/*  43:    */     try
/*  44:    */     {
/*  45: 70 */       if (wrapAround)
/*  46:    */       {
/*  47: 72 */         System.arraycopy(this.buffer, this.tokenBegin, newbuffer, 0, this.bufsize - this.tokenBegin);
/*  48: 73 */         System.arraycopy(this.buffer, 0, newbuffer, this.bufsize - this.tokenBegin, this.bufpos);
/*  49: 74 */         this.buffer = newbuffer;
/*  50:    */         
/*  51: 76 */         System.arraycopy(this.bufline, this.tokenBegin, newbufline, 0, this.bufsize - this.tokenBegin);
/*  52: 77 */         System.arraycopy(this.bufline, 0, newbufline, this.bufsize - this.tokenBegin, this.bufpos);
/*  53: 78 */         this.bufline = newbufline;
/*  54:    */         
/*  55: 80 */         System.arraycopy(this.bufcolumn, this.tokenBegin, newbufcolumn, 0, this.bufsize - this.tokenBegin);
/*  56: 81 */         System.arraycopy(this.bufcolumn, 0, newbufcolumn, this.bufsize - this.tokenBegin, this.bufpos);
/*  57: 82 */         this.bufcolumn = newbufcolumn;
/*  58:    */         
/*  59: 84 */         this.maxNextCharInd = (this.bufpos += this.bufsize - this.tokenBegin);
/*  60:    */       }
/*  61:    */       else
/*  62:    */       {
/*  63: 88 */         System.arraycopy(this.buffer, this.tokenBegin, newbuffer, 0, this.bufsize - this.tokenBegin);
/*  64: 89 */         this.buffer = newbuffer;
/*  65:    */         
/*  66: 91 */         System.arraycopy(this.bufline, this.tokenBegin, newbufline, 0, this.bufsize - this.tokenBegin);
/*  67: 92 */         this.bufline = newbufline;
/*  68:    */         
/*  69: 94 */         System.arraycopy(this.bufcolumn, this.tokenBegin, newbufcolumn, 0, this.bufsize - this.tokenBegin);
/*  70: 95 */         this.bufcolumn = newbufcolumn;
/*  71:    */         
/*  72: 97 */         this.maxNextCharInd = (this.bufpos -= this.tokenBegin);
/*  73:    */       }
/*  74:    */     }
/*  75:    */     catch (Throwable t)
/*  76:    */     {
/*  77:102 */       throw new Error(t.getMessage());
/*  78:    */     }
/*  79:106 */     this.bufsize += 2048;
/*  80:107 */     this.available = this.bufsize;
/*  81:108 */     this.tokenBegin = 0;
/*  82:    */   }
/*  83:    */   
/*  84:    */   protected void FillBuff()
/*  85:    */     throws IOException
/*  86:    */   {
/*  87:113 */     if (this.maxNextCharInd == this.available) {
/*  88:115 */       if (this.available == this.bufsize)
/*  89:    */       {
/*  90:117 */         if (this.tokenBegin > 2048)
/*  91:    */         {
/*  92:119 */           this.bufpos = (this.maxNextCharInd = 0);
/*  93:120 */           this.available = this.tokenBegin;
/*  94:    */         }
/*  95:122 */         else if (this.tokenBegin < 0)
/*  96:    */         {
/*  97:123 */           this.bufpos = (this.maxNextCharInd = 0);
/*  98:    */         }
/*  99:    */         else
/* 100:    */         {
/* 101:125 */           ExpandBuff(false);
/* 102:    */         }
/* 103:    */       }
/* 104:127 */       else if (this.available > this.tokenBegin) {
/* 105:128 */         this.available = this.bufsize;
/* 106:129 */       } else if (this.tokenBegin - this.available < 2048) {
/* 107:130 */         ExpandBuff(true);
/* 108:    */       } else {
/* 109:132 */         this.available = this.tokenBegin;
/* 110:    */       }
/* 111:    */     }
/* 112:    */     try
/* 113:    */     {
/* 114:    */       int i;
/* 115:137 */       if ((i = this.inputStream.read(this.buffer, this.maxNextCharInd, this.available - this.maxNextCharInd)) == -1)
/* 116:    */       {
/* 117:139 */         this.inputStream.close();
/* 118:140 */         throw new IOException();
/* 119:    */       }
/* 120:143 */       this.maxNextCharInd += i;
/* 121:144 */       return;
/* 122:    */     }
/* 123:    */     catch (IOException e)
/* 124:    */     {
/* 125:147 */       this.bufpos -= 1;
/* 126:148 */       backup(0);
/* 127:149 */       if (this.tokenBegin == -1) {
/* 128:150 */         this.tokenBegin = this.bufpos;
/* 129:    */       }
/* 130:151 */       throw e;
/* 131:    */     }
/* 132:    */   }
/* 133:    */   
/* 134:    */   public char BeginToken()
/* 135:    */     throws IOException
/* 136:    */   {
/* 137:158 */     this.tokenBegin = -1;
/* 138:159 */     char c = readChar();
/* 139:160 */     this.tokenBegin = this.bufpos;
/* 140:    */     
/* 141:162 */     return c;
/* 142:    */   }
/* 143:    */   
/* 144:    */   protected void UpdateLineColumn(char c)
/* 145:    */   {
/* 146:167 */     this.column += 1;
/* 147:169 */     if (this.prevCharIsLF)
/* 148:    */     {
/* 149:171 */       this.prevCharIsLF = false;
/* 150:172 */       this.line += (this.column = 1);
/* 151:    */     }
/* 152:174 */     else if (this.prevCharIsCR)
/* 153:    */     {
/* 154:176 */       this.prevCharIsCR = false;
/* 155:177 */       if (c == '\n') {
/* 156:179 */         this.prevCharIsLF = true;
/* 157:    */       } else {
/* 158:182 */         this.line += (this.column = 1);
/* 159:    */       }
/* 160:    */     }
/* 161:185 */     switch (c)
/* 162:    */     {
/* 163:    */     case '\r': 
/* 164:188 */       this.prevCharIsCR = true;
/* 165:189 */       break;
/* 166:    */     case '\n': 
/* 167:191 */       this.prevCharIsLF = true;
/* 168:192 */       break;
/* 169:    */     case '\t': 
/* 170:194 */       this.column -= 1;
/* 171:195 */       this.column += this.tabSize - this.column % this.tabSize;
/* 172:196 */       break;
/* 173:    */     }
/* 174:201 */     this.bufline[this.bufpos] = this.line;
/* 175:202 */     this.bufcolumn[this.bufpos] = this.column;
/* 176:    */   }
/* 177:    */   
/* 178:    */   public char readChar()
/* 179:    */     throws IOException
/* 180:    */   {
/* 181:208 */     if (this.inBuf > 0)
/* 182:    */     {
/* 183:210 */       this.inBuf -= 1;
/* 184:212 */       if (++this.bufpos == this.bufsize) {
/* 185:213 */         this.bufpos = 0;
/* 186:    */       }
/* 187:215 */       return this.buffer[this.bufpos];
/* 188:    */     }
/* 189:218 */     if (++this.bufpos >= this.maxNextCharInd) {
/* 190:219 */       FillBuff();
/* 191:    */     }
/* 192:221 */     char c = this.buffer[this.bufpos];
/* 193:    */     
/* 194:223 */     UpdateLineColumn(c);
/* 195:224 */     return c;
/* 196:    */   }
/* 197:    */   
/* 198:    */   @Deprecated
/* 199:    */   public int getColumn()
/* 200:    */   {
/* 201:234 */     return this.bufcolumn[this.bufpos];
/* 202:    */   }
/* 203:    */   
/* 204:    */   @Deprecated
/* 205:    */   public int getLine()
/* 206:    */   {
/* 207:244 */     return this.bufline[this.bufpos];
/* 208:    */   }
/* 209:    */   
/* 210:    */   public int getEndColumn()
/* 211:    */   {
/* 212:249 */     return this.bufcolumn[this.bufpos];
/* 213:    */   }
/* 214:    */   
/* 215:    */   public int getEndLine()
/* 216:    */   {
/* 217:254 */     return this.bufline[this.bufpos];
/* 218:    */   }
/* 219:    */   
/* 220:    */   public int getBeginColumn()
/* 221:    */   {
/* 222:259 */     return this.bufcolumn[this.tokenBegin];
/* 223:    */   }
/* 224:    */   
/* 225:    */   public int getBeginLine()
/* 226:    */   {
/* 227:264 */     return this.bufline[this.tokenBegin];
/* 228:    */   }
/* 229:    */   
/* 230:    */   public void backup(int amount)
/* 231:    */   {
/* 232:270 */     this.inBuf += amount;
/* 233:271 */     if (this.bufpos -= amount < 0) {
/* 234:272 */       this.bufpos += this.bufsize;
/* 235:    */     }
/* 236:    */   }
/* 237:    */   
/* 238:    */   public SimpleCharStream(Reader dstream, int startline, int startcolumn, int buffersize)
/* 239:    */   {
/* 240:279 */     this.inputStream = dstream;
/* 241:280 */     this.line = startline;
/* 242:281 */     this.column = (startcolumn - 1);
/* 243:    */     
/* 244:283 */     this.available = (this.bufsize = buffersize);
/* 245:284 */     this.buffer = new char[buffersize];
/* 246:285 */     this.bufline = new int[buffersize];
/* 247:286 */     this.bufcolumn = new int[buffersize];
/* 248:    */   }
/* 249:    */   
/* 250:    */   public SimpleCharStream(Reader dstream, int startline, int startcolumn)
/* 251:    */   {
/* 252:293 */     this(dstream, startline, startcolumn, 4096);
/* 253:    */   }
/* 254:    */   
/* 255:    */   public SimpleCharStream(Reader dstream)
/* 256:    */   {
/* 257:299 */     this(dstream, 1, 1, 4096);
/* 258:    */   }
/* 259:    */   
/* 260:    */   public void ReInit(Reader dstream, int startline, int startcolumn, int buffersize)
/* 261:    */   {
/* 262:306 */     this.inputStream = dstream;
/* 263:307 */     this.line = startline;
/* 264:308 */     this.column = (startcolumn - 1);
/* 265:310 */     if ((this.buffer == null) || (buffersize != this.buffer.length))
/* 266:    */     {
/* 267:312 */       this.available = (this.bufsize = buffersize);
/* 268:313 */       this.buffer = new char[buffersize];
/* 269:314 */       this.bufline = new int[buffersize];
/* 270:315 */       this.bufcolumn = new int[buffersize];
/* 271:    */     }
/* 272:317 */     this.prevCharIsLF = (this.prevCharIsCR = 0);
/* 273:318 */     this.tokenBegin = (this.inBuf = this.maxNextCharInd = 0);
/* 274:319 */     this.bufpos = -1;
/* 275:    */   }
/* 276:    */   
/* 277:    */   public void ReInit(Reader dstream, int startline, int startcolumn)
/* 278:    */   {
/* 279:326 */     ReInit(dstream, startline, startcolumn, 4096);
/* 280:    */   }
/* 281:    */   
/* 282:    */   public void ReInit(Reader dstream)
/* 283:    */   {
/* 284:332 */     ReInit(dstream, 1, 1, 4096);
/* 285:    */   }
/* 286:    */   
/* 287:    */   public SimpleCharStream(InputStream dstream, String encoding, int startline, int startcolumn, int buffersize)
/* 288:    */     throws UnsupportedEncodingException
/* 289:    */   {
/* 290:338 */     this(encoding == null ? new InputStreamReader(dstream) : new InputStreamReader(dstream, encoding), startline, startcolumn, buffersize);
/* 291:    */   }
/* 292:    */   
/* 293:    */   public SimpleCharStream(InputStream dstream, int startline, int startcolumn, int buffersize)
/* 294:    */   {
/* 295:345 */     this(new InputStreamReader(dstream), startline, startcolumn, buffersize);
/* 296:    */   }
/* 297:    */   
/* 298:    */   public SimpleCharStream(InputStream dstream, String encoding, int startline, int startcolumn)
/* 299:    */     throws UnsupportedEncodingException
/* 300:    */   {
/* 301:352 */     this(dstream, encoding, startline, startcolumn, 4096);
/* 302:    */   }
/* 303:    */   
/* 304:    */   public SimpleCharStream(InputStream dstream, int startline, int startcolumn)
/* 305:    */   {
/* 306:359 */     this(dstream, startline, startcolumn, 4096);
/* 307:    */   }
/* 308:    */   
/* 309:    */   public SimpleCharStream(InputStream dstream, String encoding)
/* 310:    */     throws UnsupportedEncodingException
/* 311:    */   {
/* 312:365 */     this(dstream, encoding, 1, 1, 4096);
/* 313:    */   }
/* 314:    */   
/* 315:    */   public SimpleCharStream(InputStream dstream)
/* 316:    */   {
/* 317:371 */     this(dstream, 1, 1, 4096);
/* 318:    */   }
/* 319:    */   
/* 320:    */   public void ReInit(InputStream dstream, String encoding, int startline, int startcolumn, int buffersize)
/* 321:    */     throws UnsupportedEncodingException
/* 322:    */   {
/* 323:378 */     ReInit(encoding == null ? new InputStreamReader(dstream) : new InputStreamReader(dstream, encoding), startline, startcolumn, buffersize);
/* 324:    */   }
/* 325:    */   
/* 326:    */   public void ReInit(InputStream dstream, int startline, int startcolumn, int buffersize)
/* 327:    */   {
/* 328:385 */     ReInit(new InputStreamReader(dstream), startline, startcolumn, buffersize);
/* 329:    */   }
/* 330:    */   
/* 331:    */   public void ReInit(InputStream dstream, String encoding)
/* 332:    */     throws UnsupportedEncodingException
/* 333:    */   {
/* 334:391 */     ReInit(dstream, encoding, 1, 1, 4096);
/* 335:    */   }
/* 336:    */   
/* 337:    */   public void ReInit(InputStream dstream)
/* 338:    */   {
/* 339:397 */     ReInit(dstream, 1, 1, 4096);
/* 340:    */   }
/* 341:    */   
/* 342:    */   public void ReInit(InputStream dstream, String encoding, int startline, int startcolumn)
/* 343:    */     throws UnsupportedEncodingException
/* 344:    */   {
/* 345:403 */     ReInit(dstream, encoding, startline, startcolumn, 4096);
/* 346:    */   }
/* 347:    */   
/* 348:    */   public void ReInit(InputStream dstream, int startline, int startcolumn)
/* 349:    */   {
/* 350:409 */     ReInit(dstream, startline, startcolumn, 4096);
/* 351:    */   }
/* 352:    */   
/* 353:    */   public String GetImage()
/* 354:    */   {
/* 355:414 */     if (this.bufpos >= this.tokenBegin) {
/* 356:415 */       return new String(this.buffer, this.tokenBegin, this.bufpos - this.tokenBegin + 1);
/* 357:    */     }
/* 358:417 */     return new String(this.buffer, this.tokenBegin, this.bufsize - this.tokenBegin) + new String(this.buffer, 0, this.bufpos + 1);
/* 359:    */   }
/* 360:    */   
/* 361:    */   public char[] GetSuffix(int len)
/* 362:    */   {
/* 363:424 */     char[] ret = new char[len];
/* 364:426 */     if (this.bufpos + 1 >= len)
/* 365:    */     {
/* 366:427 */       System.arraycopy(this.buffer, this.bufpos - len + 1, ret, 0, len);
/* 367:    */     }
/* 368:    */     else
/* 369:    */     {
/* 370:430 */       System.arraycopy(this.buffer, this.bufsize - (len - this.bufpos - 1), ret, 0, len - this.bufpos - 1);
/* 371:    */       
/* 372:432 */       System.arraycopy(this.buffer, 0, ret, len - this.bufpos - 1, this.bufpos + 1);
/* 373:    */     }
/* 374:435 */     return ret;
/* 375:    */   }
/* 376:    */   
/* 377:    */   public void Done()
/* 378:    */   {
/* 379:441 */     this.buffer = null;
/* 380:442 */     this.bufline = null;
/* 381:443 */     this.bufcolumn = null;
/* 382:    */   }
/* 383:    */   
/* 384:    */   public void adjustBeginLineColumn(int newLine, int newCol)
/* 385:    */   {
/* 386:451 */     int start = this.tokenBegin;
/* 387:    */     int len;
/* 388:    */     int len;
/* 389:454 */     if (this.bufpos >= this.tokenBegin) {
/* 390:456 */       len = this.bufpos - this.tokenBegin + this.inBuf + 1;
/* 391:    */     } else {
/* 392:460 */       len = this.bufsize - this.tokenBegin + this.bufpos + 1 + this.inBuf;
/* 393:    */     }
/* 394:463 */     int i = 0;int j = 0;int k = 0;
/* 395:464 */     int nextColDiff = 0;int columnDiff = 0;
/* 396:466 */     while ((i < len) && (this.bufline[(j = start % this.bufsize)] == this.bufline[(k = ++start % this.bufsize)]))
/* 397:    */     {
/* 398:468 */       this.bufline[j] = newLine;
/* 399:469 */       nextColDiff = columnDiff + this.bufcolumn[k] - this.bufcolumn[j];
/* 400:470 */       this.bufcolumn[j] = (newCol + columnDiff);
/* 401:471 */       columnDiff = nextColDiff;
/* 402:472 */       i++;
/* 403:    */     }
/* 404:475 */     if (i < len)
/* 405:    */     {
/* 406:477 */       this.bufline[j] = (newLine++);
/* 407:478 */       this.bufcolumn[j] = (newCol + columnDiff);
/* 408:480 */       while (i++ < len) {
/* 409:482 */         if (this.bufline[(j = start % this.bufsize)] != this.bufline[(++start % this.bufsize)]) {
/* 410:483 */           this.bufline[j] = (newLine++);
/* 411:    */         } else {
/* 412:485 */           this.bufline[j] = newLine;
/* 413:    */         }
/* 414:    */       }
/* 415:    */     }
/* 416:489 */     this.line = this.bufline[j];
/* 417:490 */     this.column = this.bufcolumn[j];
/* 418:    */   }
/* 419:    */ }


/* Location:           E:\workspace\java\db\lib\jsqlparser.jar
 * Qualified Name:     net.sf.jsqlparser.parser.SimpleCharStream
 * JD-Core Version:    0.7.0.1
 */