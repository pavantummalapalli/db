/*   1:    */ package net.sf.jsqlparser.parser;
/*   2:    */ 
/*   3:    */ public abstract interface CCJSqlParserConstants
/*   4:    */ {
/*   5:    */   public static final int EOF = 0;
/*   6:    */   public static final int K_AS = 5;
/*   7:    */   public static final int K_BY = 6;
/*   8:    */   public static final int K_DO = 7;
/*   9:    */   public static final int K_IS = 8;
/*  10:    */   public static final int K_IN = 9;
/*  11:    */   public static final int K_OR = 10;
/*  12:    */   public static final int K_ON = 11;
/*  13:    */   public static final int K_ALL = 12;
/*  14:    */   public static final int K_AND = 13;
/*  15:    */   public static final int K_ANY = 14;
/*  16:    */   public static final int K_KEY = 15;
/*  17:    */   public static final int K_NOT = 16;
/*  18:    */   public static final int K_SET = 17;
/*  19:    */   public static final int K_ASC = 18;
/*  20:    */   public static final int K_TOP = 19;
/*  21:    */   public static final int K_END = 20;
/*  22:    */   public static final int K_DESC = 21;
/*  23:    */   public static final int K_INTO = 22;
/*  24:    */   public static final int K_NULL = 23;
/*  25:    */   public static final int K_LIKE = 24;
/*  26:    */   public static final int K_DROP = 25;
/*  27:    */   public static final int K_JOIN = 26;
/*  28:    */   public static final int K_LEFT = 27;
/*  29:    */   public static final int K_FROM = 28;
/*  30:    */   public static final int K_OPEN = 29;
/*  31:    */   public static final int K_CASE = 30;
/*  32:    */   public static final int K_WHEN = 31;
/*  33:    */   public static final int K_THEN = 32;
/*  34:    */   public static final int K_ELSE = 33;
/*  35:    */   public static final int K_SOME = 34;
/*  36:    */   public static final int K_FULL = 35;
/*  37:    */   public static final int K_WITH = 36;
/*  38:    */   public static final int K_TABLE = 37;
/*  39:    */   public static final int K_WHERE = 38;
/*  40:    */   public static final int K_USING = 39;
/*  41:    */   public static final int K_UNION = 40;
/*  42:    */   public static final int K_GROUP = 41;
/*  43:    */   public static final int K_BEGIN = 42;
/*  44:    */   public static final int K_INDEX = 43;
/*  45:    */   public static final int K_INNER = 44;
/*  46:    */   public static final int K_LIMIT = 45;
/*  47:    */   public static final int K_OUTER = 46;
/*  48:    */   public static final int K_ORDER = 47;
/*  49:    */   public static final int K_RIGHT = 48;
/*  50:    */   public static final int K_DELETE = 49;
/*  51:    */   public static final int K_CREATE = 50;
/*  52:    */   public static final int K_SELECT = 51;
/*  53:    */   public static final int K_OFFSET = 52;
/*  54:    */   public static final int K_EXISTS = 53;
/*  55:    */   public static final int K_HAVING = 54;
/*  56:    */   public static final int K_INSERT = 55;
/*  57:    */   public static final int K_UPDATE = 56;
/*  58:    */   public static final int K_VALUES = 57;
/*  59:    */   public static final int K_ESCAPE = 58;
/*  60:    */   public static final int K_PRIMARY = 59;
/*  61:    */   public static final int K_NATURAL = 60;
/*  62:    */   public static final int K_REPLACE = 61;
/*  63:    */   public static final int K_BETWEEN = 62;
/*  64:    */   public static final int K_TRUNCATE = 63;
/*  65:    */   public static final int K_DISTINCT = 64;
/*  66:    */   public static final int K_INTERSECT = 65;
/*  67:    */   public static final int S_DOUBLE = 66;
/*  68:    */   public static final int S_INTEGER = 67;
/*  69:    */   public static final int DIGIT = 68;
/*  70:    */   public static final int LINE_COMMENT = 69;
/*  71:    */   public static final int MULTI_LINE_COMMENT = 70;
/*  72:    */   public static final int S_IDENTIFIER = 71;
/*  73:    */   public static final int LETTER = 72;
/*  74:    */   public static final int SPECIAL_CHARS = 73;
/*  75:    */   public static final int S_CHAR_LITERAL = 74;
/*  76:    */   public static final int S_QUOTED_IDENTIFIER = 75;
/*  77:    */   public static final int DEFAULT = 0;
/*  78:183 */   public static final String[] tokenImage = { "<EOF>", "\" \"", "\"\\t\"", "\"\\r\"", "\"\\n\"", "\"AS\"", "\"BY\"", "\"DO\"", "\"IS\"", "\"IN\"", "\"OR\"", "\"ON\"", "\"ALL\"", "\"AND\"", "\"ANY\"", "\"KEY\"", "\"NOT\"", "\"SET\"", "\"ASC\"", "\"TOP\"", "\"END\"", "\"DESC\"", "\"INTO\"", "\"NULL\"", "\"LIKE\"", "\"DROP\"", "\"JOIN\"", "\"LEFT\"", "\"FROM\"", "\"OPEN\"", "\"CASE\"", "\"WHEN\"", "\"THEN\"", "\"ELSE\"", "\"SOME\"", "\"FULL\"", "\"WITH\"", "\"TABLE\"", "\"WHERE\"", "\"USING\"", "\"UNION\"", "\"GROUP\"", "\"BEGIN\"", "\"INDEX\"", "\"INNER\"", "\"LIMIT\"", "\"OUTER\"", "\"ORDER\"", "\"RIGHT\"", "\"DELETE\"", "\"CREATE\"", "\"SELECT\"", "\"OFFSET\"", "\"EXISTS\"", "\"HAVING\"", "\"INSERT\"", "\"UPDATE\"", "\"VALUES\"", "\"ESCAPE\"", "\"PRIMARY\"", "\"NATURAL\"", "\"REPLACE\"", "\"BETWEEN\"", "\"TRUNCATE\"", "\"DISTINCT\"", "\"INTERSECT\"", "<S_DOUBLE>", "<S_INTEGER>", "<DIGIT>", "<LINE_COMMENT>", "<MULTI_LINE_COMMENT>", "<S_IDENTIFIER>", "<LETTER>", "<SPECIAL_CHARS>", "<S_CHAR_LITERAL>", "<S_QUOTED_IDENTIFIER>", "\";\"", "\"=\"", "\",\"", "\"(\"", "\")\"", "\".\"", "\"*\"", "\"?\"", "\">\"", "\"<\"", "\">=\"", "\"<=\"", "\"<>\"", "\"!=\"", "\"@@\"", "\"||\"", "\"|\"", "\"&\"", "\"+\"", "\"-\"", "\"/\"", "\"^\"", "\"{d\"", "\"}\"", "\"{t\"", "\"{ts\"", "\"{fn\"" };
/*  79:    */ }


/* Location:           E:\workspace\java\db\lib\jsqlparser.jar
 * Qualified Name:     net.sf.jsqlparser.parser.CCJSqlParserConstants
 * JD-Core Version:    0.7.0.1
 */