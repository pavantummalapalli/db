/*  1:   */ package net.sf.jsqlparser.parser;
/*  2:   */ 
/*  3:   */ import java.io.Reader;
/*  4:   */ import net.sf.jsqlparser.JSQLParserException;
/*  5:   */ import net.sf.jsqlparser.statement.Statement;
/*  6:   */ 
/*  7:   */ public class CCJSqlParserManager
/*  8:   */   implements JSqlParser
/*  9:   */ {
/* 10:   */   public Statement parse(Reader statementReader)
/* 11:   */     throws JSQLParserException
/* 12:   */   {
/* 13:36 */     CCJSqlParser parser = new CCJSqlParser(statementReader);
/* 14:   */     try
/* 15:   */     {
/* 16:38 */       return parser.Statement();
/* 17:   */     }
/* 18:   */     catch (Throwable e)
/* 19:   */     {
/* 20:40 */       throw new JSQLParserException(e);
/* 21:   */     }
/* 22:   */   }
/* 23:   */ }


/* Location:           E:\workspace\java\db\lib\jsqlparser.jar
 * Qualified Name:     net.sf.jsqlparser.parser.CCJSqlParserManager
 * JD-Core Version:    0.7.0.1
 */