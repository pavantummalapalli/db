/*   1:    */ package net.sf.jsqlparser.parser;
/*   2:    */ 
/*   3:    */ public class ParseException
/*   4:    */   extends Exception
/*   5:    */ {
/*   6:    */   private static final long serialVersionUID = 1L;
/*   7:    */   public Token currentToken;
/*   8:    */   public int[][] expectedTokenSequences;
/*   9:    */   public String[] tokenImage;
/*  10:    */   
/*  11:    */   public ParseException(Token currentTokenVal, int[][] expectedTokenSequencesVal, String[] tokenImageVal)
/*  12:    */   {
/*  13: 57 */     super(initialise(currentTokenVal, expectedTokenSequencesVal, tokenImageVal));
/*  14: 58 */     this.currentToken = currentTokenVal;
/*  15: 59 */     this.expectedTokenSequences = expectedTokenSequencesVal;
/*  16: 60 */     this.tokenImage = tokenImageVal;
/*  17:    */   }
/*  18:    */   
/*  19:    */   public ParseException() {}
/*  20:    */   
/*  21:    */   public ParseException(String message)
/*  22:    */   {
/*  23: 79 */     super(message);
/*  24:    */   }
/*  25:    */   
/*  26:    */   private static String initialise(Token currentToken, int[][] expectedTokenSequences, String[] tokenImage)
/*  27:    */   {
/*  28:114 */     String eol = System.getProperty("line.separator", "\n");
/*  29:115 */     StringBuffer expected = new StringBuffer();
/*  30:116 */     int maxSize = 0;
/*  31:117 */     for (int i = 0; i < expectedTokenSequences.length; i++)
/*  32:    */     {
/*  33:118 */       if (maxSize < expectedTokenSequences[i].length) {
/*  34:119 */         maxSize = expectedTokenSequences[i].length;
/*  35:    */       }
/*  36:121 */       for (int j = 0; j < expectedTokenSequences[i].length; j++) {
/*  37:122 */         expected.append(tokenImage[expectedTokenSequences[i][j]]).append(' ');
/*  38:    */       }
/*  39:124 */       if (expectedTokenSequences[i][(expectedTokenSequences[i].length - 1)] != 0) {
/*  40:125 */         expected.append("...");
/*  41:    */       }
/*  42:127 */       expected.append(eol).append("    ");
/*  43:    */     }
/*  44:129 */     String retval = "Encountered \"";
/*  45:130 */     Token tok = currentToken.next;
/*  46:131 */     for (int i = 0; i < maxSize; i++)
/*  47:    */     {
/*  48:132 */       if (i != 0) {
/*  49:132 */         retval = retval + " ";
/*  50:    */       }
/*  51:133 */       if (tok.kind == 0)
/*  52:    */       {
/*  53:134 */         retval = retval + tokenImage[0];
/*  54:135 */         break;
/*  55:    */       }
/*  56:137 */       retval = retval + " " + tokenImage[tok.kind];
/*  57:138 */       retval = retval + " \"";
/*  58:139 */       retval = retval + add_escapes(tok.image);
/*  59:140 */       retval = retval + " \"";
/*  60:141 */       tok = tok.next;
/*  61:    */     }
/*  62:143 */     retval = retval + "\" at line " + currentToken.next.beginLine + ", column " + currentToken.next.beginColumn;
/*  63:144 */     retval = retval + "." + eol;
/*  64:145 */     if (expectedTokenSequences.length == 1) {
/*  65:146 */       retval = retval + "Was expecting:" + eol + "    ";
/*  66:    */     } else {
/*  67:148 */       retval = retval + "Was expecting one of:" + eol + "    ";
/*  68:    */     }
/*  69:150 */     retval = retval + expected.toString();
/*  70:151 */     return retval;
/*  71:    */   }
/*  72:    */   
/*  73:157 */   protected String eol = System.getProperty("line.separator", "\n");
/*  74:    */   
/*  75:    */   static String add_escapes(String str)
/*  76:    */   {
/*  77:165 */     StringBuffer retval = new StringBuffer();
/*  78:167 */     for (int i = 0; i < str.length(); i++) {
/*  79:168 */       switch (str.charAt(i))
/*  80:    */       {
/*  81:    */       case '\000': 
/*  82:    */         break;
/*  83:    */       case '\b': 
/*  84:173 */         retval.append("\\b");
/*  85:174 */         break;
/*  86:    */       case '\t': 
/*  87:176 */         retval.append("\\t");
/*  88:177 */         break;
/*  89:    */       case '\n': 
/*  90:179 */         retval.append("\\n");
/*  91:180 */         break;
/*  92:    */       case '\f': 
/*  93:182 */         retval.append("\\f");
/*  94:183 */         break;
/*  95:    */       case '\r': 
/*  96:185 */         retval.append("\\r");
/*  97:186 */         break;
/*  98:    */       case '"': 
/*  99:188 */         retval.append("\\\"");
/* 100:189 */         break;
/* 101:    */       case '\'': 
/* 102:191 */         retval.append("\\'");
/* 103:192 */         break;
/* 104:    */       case '\\': 
/* 105:194 */         retval.append("\\\\");
/* 106:195 */         break;
/* 107:    */       default: 
/* 108:    */         char ch;
/* 109:197 */         if (((ch = str.charAt(i)) < ' ') || (ch > '~'))
/* 110:    */         {
/* 111:198 */           String s = "0000" + Integer.toString(ch, 16);
/* 112:199 */           retval.append("\\u" + s.substring(s.length() - 4, s.length()));
/* 113:    */         }
/* 114:    */         else
/* 115:    */         {
/* 116:201 */           retval.append(ch);
/* 117:    */         }
/* 118:    */         break;
/* 119:    */       }
/* 120:    */     }
/* 121:206 */     return retval.toString();
/* 122:    */   }
/* 123:    */ }


/* Location:           E:\workspace\java\db\lib\jsqlparser.jar
 * Qualified Name:     net.sf.jsqlparser.parser.ParseException
 * JD-Core Version:    0.7.0.1
 */