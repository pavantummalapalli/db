/*    1:     */ package net.sf.jsqlparser.parser;
/*    2:     */ 
/*    3:     */ import java.io.IOException;
/*    4:     */ import java.io.PrintStream;
/*    5:     */ 
/*    6:     */ public class CCJSqlParserTokenManager
/*    7:     */   implements CCJSqlParserConstants
/*    8:     */ {
/*    9: 105 */   public PrintStream debugStream = System.out;
/*   10:     */   
/*   11:     */   public void setDebugStream(PrintStream ds)
/*   12:     */   {
/*   13: 107 */     this.debugStream = ds;
/*   14:     */   }
/*   15:     */   
/*   16:     */   private final int jjStopStringLiteralDfa_0(int pos, long active0, long active1)
/*   17:     */   {
/*   18: 110 */     switch (pos)
/*   19:     */     {
/*   20:     */     case 0: 
/*   21: 113 */       if (((active0 & 0xFFFFFFE0) != 0L) || ((active1 & 0x3) != 0L))
/*   22:     */       {
/*   23: 115 */         this.jjmatchedKind = 71;
/*   24: 116 */         return 36;
/*   25:     */       }
/*   26: 118 */       if ((active1 & 0x0) != 0L) {
/*   27: 119 */         return 8;
/*   28:     */       }
/*   29: 120 */       if ((active1 & 0x20000) != 0L) {
/*   30: 121 */         return 1;
/*   31:     */       }
/*   32: 122 */       if ((active1 & 0x80000000) != 0L) {
/*   33: 123 */         return 5;
/*   34:     */       }
/*   35: 124 */       return -1;
/*   36:     */     case 1: 
/*   37: 126 */       if (((active0 & 0xFFBBF000) != 0L) || ((active1 & 1L) != 0L))
/*   38:     */       {
/*   39: 128 */         if (this.jjmatchedPos != 1)
/*   40:     */         {
/*   41: 130 */           this.jjmatchedKind = 71;
/*   42: 131 */           this.jjmatchedPos = 1;
/*   43:     */         }
/*   44: 133 */         return 36;
/*   45:     */       }
/*   46: 135 */       if (((active0 & 0x440FE0) != 0L) || ((active1 & 0x2) != 0L)) {
/*   47: 136 */         return 36;
/*   48:     */       }
/*   49: 137 */       return -1;
/*   50:     */     case 2: 
/*   51: 139 */       if (((active0 & 0xFFE00000) != 0L) || ((active1 & 0x3) != 0L))
/*   52:     */       {
/*   53: 141 */         this.jjmatchedKind = 71;
/*   54: 142 */         this.jjmatchedPos = 2;
/*   55: 143 */         return 36;
/*   56:     */       }
/*   57: 145 */       if ((active0 & 0x1FF000) != 0L) {
/*   58: 146 */         return 36;
/*   59:     */       }
/*   60: 147 */       return -1;
/*   61:     */     case 3: 
/*   62: 149 */       if (((active0 & 0x0) != 0L) || ((active1 & 0x3) != 0L))
/*   63:     */       {
/*   64: 151 */         this.jjmatchedKind = 71;
/*   65: 152 */         this.jjmatchedPos = 3;
/*   66: 153 */         return 36;
/*   67:     */       }
/*   68: 155 */       if ((active0 & 0xFFE00000) != 0L) {
/*   69: 156 */         return 36;
/*   70:     */       }
/*   71: 157 */       return -1;
/*   72:     */     case 4: 
/*   73: 159 */       if (((active0 & 0x0) != 0L) || ((active1 & 0x3) != 0L))
/*   74:     */       {
/*   75: 161 */         this.jjmatchedKind = 71;
/*   76: 162 */         this.jjmatchedPos = 4;
/*   77: 163 */         return 36;
/*   78:     */       }
/*   79: 165 */       if ((active0 & 0x0) != 0L) {
/*   80: 166 */         return 36;
/*   81:     */       }
/*   82: 167 */       return -1;
/*   83:     */     case 5: 
/*   84: 169 */       if (((active0 & 0x0) != 0L) || ((active1 & 0x3) != 0L))
/*   85:     */       {
/*   86: 171 */         this.jjmatchedKind = 71;
/*   87: 172 */         this.jjmatchedPos = 5;
/*   88: 173 */         return 36;
/*   89:     */       }
/*   90: 175 */       if ((active0 & 0x0) != 0L) {
/*   91: 176 */         return 36;
/*   92:     */       }
/*   93: 177 */       return -1;
/*   94:     */     case 6: 
/*   95: 179 */       if (((active0 & 0x0) != 0L) || ((active1 & 0x3) != 0L))
/*   96:     */       {
/*   97: 181 */         this.jjmatchedKind = 71;
/*   98: 182 */         this.jjmatchedPos = 6;
/*   99: 183 */         return 36;
/*  100:     */       }
/*  101: 185 */       if ((active0 & 0x0) != 0L) {
/*  102: 186 */         return 36;
/*  103:     */       }
/*  104: 187 */       return -1;
/*  105:     */     case 7: 
/*  106: 189 */       if ((active1 & 0x2) != 0L)
/*  107:     */       {
/*  108: 191 */         this.jjmatchedKind = 71;
/*  109: 192 */         this.jjmatchedPos = 7;
/*  110: 193 */         return 36;
/*  111:     */       }
/*  112: 195 */       if (((active0 & 0x0) != 0L) || ((active1 & 1L) != 0L)) {
/*  113: 196 */         return 36;
/*  114:     */       }
/*  115: 197 */       return -1;
/*  116:     */     }
/*  117: 199 */     return -1;
/*  118:     */   }
/*  119:     */   
/*  120:     */   private final int jjStartNfa_0(int pos, long active0, long active1)
/*  121:     */   {
/*  122: 204 */     return jjMoveNfa_0(jjStopStringLiteralDfa_0(pos, active0, active1), pos + 1);
/*  123:     */   }
/*  124:     */   
/*  125:     */   private int jjStopAtPos(int pos, int kind)
/*  126:     */   {
/*  127: 208 */     this.jjmatchedKind = kind;
/*  128: 209 */     this.jjmatchedPos = pos;
/*  129: 210 */     return pos + 1;
/*  130:     */   }
/*  131:     */   
/*  132:     */   private int jjMoveStringLiteralDfa0_0()
/*  133:     */   {
/*  134: 214 */     switch (this.curChar)
/*  135:     */     {
/*  136:     */     case '!': 
/*  137: 217 */       return jjMoveStringLiteralDfa1_0(0L, 33554432L);
/*  138:     */     case '&': 
/*  139: 219 */       return jjStopAtPos(0, 93);
/*  140:     */     case '(': 
/*  141: 221 */       return jjStopAtPos(0, 79);
/*  142:     */     case ')': 
/*  143: 223 */       return jjStopAtPos(0, 80);
/*  144:     */     case '*': 
/*  145: 225 */       return jjStopAtPos(0, 82);
/*  146:     */     case '+': 
/*  147: 227 */       return jjStopAtPos(0, 94);
/*  148:     */     case ',': 
/*  149: 229 */       return jjStopAtPos(0, 78);
/*  150:     */     case '-': 
/*  151: 231 */       return jjStartNfaWithStates_0(0, 95, 5);
/*  152:     */     case '.': 
/*  153: 233 */       return jjStartNfaWithStates_0(0, 81, 1);
/*  154:     */     case '/': 
/*  155: 235 */       return jjStartNfaWithStates_0(0, 96, 8);
/*  156:     */     case ';': 
/*  157: 237 */       return jjStopAtPos(0, 76);
/*  158:     */     case '<': 
/*  159: 239 */       this.jjmatchedKind = 85;
/*  160: 240 */       return jjMoveStringLiteralDfa1_0(0L, 25165824L);
/*  161:     */     case '=': 
/*  162: 242 */       return jjStopAtPos(0, 77);
/*  163:     */     case '>': 
/*  164: 244 */       this.jjmatchedKind = 84;
/*  165: 245 */       return jjMoveStringLiteralDfa1_0(0L, 4194304L);
/*  166:     */     case '?': 
/*  167: 247 */       return jjStopAtPos(0, 83);
/*  168:     */     case '@': 
/*  169: 249 */       return jjMoveStringLiteralDfa1_0(0L, 67108864L);
/*  170:     */     case '^': 
/*  171: 251 */       return jjStopAtPos(0, 97);
/*  172:     */     case 'A': 
/*  173:     */     case 'a': 
/*  174: 254 */       return jjMoveStringLiteralDfa1_0(290848L, 0L);
/*  175:     */     case 'B': 
/*  176:     */     case 'b': 
/*  177: 257 */       return jjMoveStringLiteralDfa1_0(4611690416473899072L, 0L);
/*  178:     */     case 'C': 
/*  179:     */     case 'c': 
/*  180: 260 */       return jjMoveStringLiteralDfa1_0(1125900980584448L, 0L);
/*  181:     */     case 'D': 
/*  182:     */     case 'd': 
/*  183: 263 */       return jjMoveStringLiteralDfa1_0(562949989073024L, 1L);
/*  184:     */     case 'E': 
/*  185:     */     case 'e': 
/*  186: 266 */       return jjMoveStringLiteralDfa1_0(297237583997435904L, 0L);
/*  187:     */     case 'F': 
/*  188:     */     case 'f': 
/*  189: 269 */       return jjMoveStringLiteralDfa1_0(34628173824L, 0L);
/*  190:     */     case 'G': 
/*  191:     */     case 'g': 
/*  192: 272 */       return jjMoveStringLiteralDfa1_0(2199023255552L, 0L);
/*  193:     */     case 'H': 
/*  194:     */     case 'h': 
/*  195: 275 */       return jjMoveStringLiteralDfa1_0(18014398509481984L, 0L);
/*  196:     */     case 'I': 
/*  197:     */     case 'i': 
/*  198: 278 */       return jjMoveStringLiteralDfa1_0(36055185302225664L, 2L);
/*  199:     */     case 'J': 
/*  200:     */     case 'j': 
/*  201: 281 */       return jjMoveStringLiteralDfa1_0(67108864L, 0L);
/*  202:     */     case 'K': 
/*  203:     */     case 'k': 
/*  204: 284 */       return jjMoveStringLiteralDfa1_0(32768L, 0L);
/*  205:     */     case 'L': 
/*  206:     */     case 'l': 
/*  207: 287 */       return jjMoveStringLiteralDfa1_0(35184523083776L, 0L);
/*  208:     */     case 'N': 
/*  209:     */     case 'n': 
/*  210: 290 */       return jjMoveStringLiteralDfa1_0(1152921504615301120L, 0L);
/*  211:     */     case 'O': 
/*  212:     */     case 'o': 
/*  213: 293 */       return jjMoveStringLiteralDfa1_0(4714706396777472L, 0L);
/*  214:     */     case 'P': 
/*  215:     */     case 'p': 
/*  216: 296 */       return jjMoveStringLiteralDfa1_0(576460752303423488L, 0L);
/*  217:     */     case 'R': 
/*  218:     */     case 'r': 
/*  219: 299 */       return jjMoveStringLiteralDfa1_0(2306124484190404608L, 0L);
/*  220:     */     case 'S': 
/*  221:     */     case 's': 
/*  222: 302 */       return jjMoveStringLiteralDfa1_0(2251816993685504L, 0L);
/*  223:     */     case 'T': 
/*  224:     */     case 't': 
/*  225: 305 */       return jjMoveStringLiteralDfa1_0(-9223371895120330752L, 0L);
/*  226:     */     case 'U': 
/*  227:     */     case 'u': 
/*  228: 308 */       return jjMoveStringLiteralDfa1_0(72059243305369600L, 0L);
/*  229:     */     case 'V': 
/*  230:     */     case 'v': 
/*  231: 311 */       return jjMoveStringLiteralDfa1_0(144115188075855872L, 0L);
/*  232:     */     case 'W': 
/*  233:     */     case 'w': 
/*  234: 314 */       return jjMoveStringLiteralDfa1_0(345744867328L, 0L);
/*  235:     */     case '{': 
/*  236: 316 */       return jjMoveStringLiteralDfa1_0(0L, 498216206336L);
/*  237:     */     case '|': 
/*  238: 318 */       this.jjmatchedKind = 92;
/*  239: 319 */       return jjMoveStringLiteralDfa1_0(0L, 134217728L);
/*  240:     */     case '}': 
/*  241: 321 */       return jjStopAtPos(0, 99);
/*  242:     */     }
/*  243: 323 */     return jjMoveNfa_0(7, 0);
/*  244:     */   }
/*  245:     */   
/*  246:     */   private int jjMoveStringLiteralDfa1_0(long active0, long active1)
/*  247:     */   {
/*  248:     */     try
/*  249:     */     {
/*  250: 328 */       this.curChar = this.input_stream.readChar();
/*  251:     */     }
/*  252:     */     catch (IOException e)
/*  253:     */     {
/*  254: 330 */       jjStopStringLiteralDfa_0(0, active0, active1);
/*  255: 331 */       return 1;
/*  256:     */     }
/*  257: 333 */     switch (this.curChar)
/*  258:     */     {
/*  259:     */     case '=': 
/*  260: 336 */       if ((active1 & 0x400000) != 0L) {
/*  261: 337 */         return jjStopAtPos(1, 86);
/*  262:     */       }
/*  263: 338 */       if ((active1 & 0x800000) != 0L) {
/*  264: 339 */         return jjStopAtPos(1, 87);
/*  265:     */       }
/*  266: 340 */       if ((active1 & 0x2000000) != 0L) {
/*  267: 341 */         return jjStopAtPos(1, 89);
/*  268:     */       }
/*  269:     */       break;
/*  270:     */     case '>': 
/*  271: 344 */       if ((active1 & 0x1000000) != 0L) {
/*  272: 345 */         return jjStopAtPos(1, 88);
/*  273:     */       }
/*  274:     */       break;
/*  275:     */     case '@': 
/*  276: 348 */       if ((active1 & 0x4000000) != 0L) {
/*  277: 349 */         return jjStopAtPos(1, 90);
/*  278:     */       }
/*  279:     */       break;
/*  280:     */     case 'A': 
/*  281:     */     case 'a': 
/*  282: 353 */       return jjMoveStringLiteralDfa2_0(active0, 1315051229704880128L, active1, 0L);
/*  283:     */     case 'D': 
/*  284:     */     case 'd': 
/*  285: 356 */       if ((active1 & 0x0) != 0L) {
/*  286: 357 */         return jjStopAtPos(1, 98);
/*  287:     */       }
/*  288:     */       break;
/*  289:     */     case 'E': 
/*  290:     */     case 'e': 
/*  291: 361 */       return jjMoveStringLiteralDfa2_0(active0, 6920348175591178240L, active1, 0L);
/*  292:     */     case 'F': 
/*  293:     */     case 'f': 
/*  294: 364 */       return jjMoveStringLiteralDfa2_0(active0, 4503599627370496L, active1, 274877906944L);
/*  295:     */     case 'H': 
/*  296:     */     case 'h': 
/*  297: 367 */       return jjMoveStringLiteralDfa2_0(active0, 281320357888L, active1, 0L);
/*  298:     */     case 'I': 
/*  299:     */     case 'i': 
/*  300: 370 */       return jjMoveStringLiteralDfa2_0(active0, 316728085053440L, active1, 1L);
/*  301:     */     case 'L': 
/*  302:     */     case 'l': 
/*  303: 373 */       return jjMoveStringLiteralDfa2_0(active0, 8589938688L, active1, 0L);
/*  304:     */     case 'N': 
/*  305:     */     case 'n': 
/*  306: 376 */       if ((active0 & 0x200) != 0L)
/*  307:     */       {
/*  308: 378 */         this.jjmatchedKind = 9;
/*  309: 379 */         this.jjmatchedPos = 1;
/*  310:     */       }
/*  311: 381 */       else if ((active0 & 0x800) != 0L)
/*  312:     */       {
/*  313: 382 */         return jjStartNfaWithStates_0(1, 11, 36);
/*  314:     */       }
/*  315: 383 */       return jjMoveStringLiteralDfa2_0(active0, 36056284814925824L, active1, 2L);
/*  316:     */     case 'O': 
/*  317:     */     case 'o': 
/*  318: 386 */       if ((active0 & 0x80) != 0L) {
/*  319: 387 */         return jjStartNfaWithStates_0(1, 7, 36);
/*  320:     */       }
/*  321: 388 */       return jjMoveStringLiteralDfa2_0(active0, 17247567872L, active1, 0L);
/*  322:     */     case 'P': 
/*  323:     */     case 'p': 
/*  324: 391 */       return jjMoveStringLiteralDfa2_0(active0, 72057594574798848L, active1, 0L);
/*  325:     */     case 'R': 
/*  326:     */     case 'r': 
/*  327: 394 */       if ((active0 & 0x400) != 0L)
/*  328:     */       {
/*  329: 396 */         this.jjmatchedKind = 10;
/*  330: 397 */         this.jjmatchedPos = 1;
/*  331:     */       }
/*  332: 399 */       return jjMoveStringLiteralDfa2_0(active0, -8645642447830908928L, active1, 0L);
/*  333:     */     case 'S': 
/*  334:     */     case 's': 
/*  335: 402 */       if ((active0 & 0x20) != 0L)
/*  336:     */       {
/*  337: 404 */         this.jjmatchedKind = 5;
/*  338: 405 */         this.jjmatchedPos = 1;
/*  339:     */       }
/*  340: 407 */       else if ((active0 & 0x100) != 0L)
/*  341:     */       {
/*  342: 408 */         return jjStartNfaWithStates_0(1, 8, 36);
/*  343:     */       }
/*  344: 409 */       return jjMoveStringLiteralDfa2_0(active0, 288230925907787776L, active1, 0L);
/*  345:     */     case 'T': 
/*  346:     */     case 't': 
/*  347: 412 */       if ((active1 & 0x0) != 0L)
/*  348:     */       {
/*  349: 414 */         this.jjmatchedKind = 100;
/*  350: 415 */         this.jjmatchedPos = 1;
/*  351:     */       }
/*  352: 417 */       return jjMoveStringLiteralDfa2_0(active0, 0L, active1, 137438953472L);
/*  353:     */     case 'U': 
/*  354:     */     case 'u': 
/*  355: 420 */       return jjMoveStringLiteralDfa2_0(active0, 70403112304640L, active1, 0L);
/*  356:     */     case 'X': 
/*  357:     */     case 'x': 
/*  358: 423 */       return jjMoveStringLiteralDfa2_0(active0, 9007199254740992L, active1, 0L);
/*  359:     */     case 'Y': 
/*  360:     */     case 'y': 
/*  361: 426 */       if ((active0 & 0x40) != 0L) {
/*  362: 427 */         return jjStartNfaWithStates_0(1, 6, 36);
/*  363:     */       }
/*  364:     */       break;
/*  365:     */     case '|': 
/*  366: 430 */       if ((active1 & 0x8000000) != 0L) {
/*  367: 431 */         return jjStopAtPos(1, 91);
/*  368:     */       }
/*  369:     */       break;
/*  370:     */     }
/*  371: 436 */     return jjStartNfa_0(0, active0, active1);
/*  372:     */   }
/*  373:     */   
/*  374:     */   private int jjMoveStringLiteralDfa2_0(long old0, long active0, long old1, long active1)
/*  375:     */   {
/*  376: 440 */     if ((active0 &= old0 | active1 &= old1) == 0L) {
/*  377: 441 */       return jjStartNfa_0(0, old0, old1);
/*  378:     */     }
/*  379:     */     try
/*  380:     */     {
/*  381: 442 */       this.curChar = this.input_stream.readChar();
/*  382:     */     }
/*  383:     */     catch (IOException e)
/*  384:     */     {
/*  385: 444 */       jjStopStringLiteralDfa_0(1, active0, active1);
/*  386: 445 */       return 2;
/*  387:     */     }
/*  388: 447 */     switch (this.curChar)
/*  389:     */     {
/*  390:     */     case 'B': 
/*  391:     */     case 'b': 
/*  392: 451 */       return jjMoveStringLiteralDfa3_0(active0, 137438953472L, active1, 0L);
/*  393:     */     case 'C': 
/*  394:     */     case 'c': 
/*  395: 454 */       if ((active0 & 0x40000) != 0L) {
/*  396: 455 */         return jjStartNfaWithStates_0(2, 18, 36);
/*  397:     */       }
/*  398: 456 */       return jjMoveStringLiteralDfa3_0(active0, 288230376151711744L, active1, 0L);
/*  399:     */     case 'D': 
/*  400:     */     case 'd': 
/*  401: 459 */       if ((active0 & 0x2000) != 0L) {
/*  402: 460 */         return jjStartNfaWithStates_0(2, 13, 36);
/*  403:     */       }
/*  404: 461 */       if ((active0 & 0x100000) != 0L) {
/*  405: 462 */         return jjStartNfaWithStates_0(2, 20, 36);
/*  406:     */       }
/*  407: 463 */       return jjMoveStringLiteralDfa3_0(active0, 72207127619305472L, active1, 0L);
/*  408:     */     case 'E': 
/*  409:     */     case 'e': 
/*  410: 466 */       return jjMoveStringLiteralDfa3_0(active0, 1126181764071424L, active1, 0L);
/*  411:     */     case 'F': 
/*  412:     */     case 'f': 
/*  413: 469 */       return jjMoveStringLiteralDfa3_0(active0, 4503599761588224L, active1, 0L);
/*  414:     */     case 'G': 
/*  415:     */     case 'g': 
/*  416: 472 */       return jjMoveStringLiteralDfa3_0(active0, 285873023221760L, active1, 0L);
/*  417:     */     case 'I': 
/*  418:     */     case 'i': 
/*  419: 475 */       return jjMoveStringLiteralDfa3_0(active0, 585469600892715008L, active1, 0L);
/*  420:     */     case 'K': 
/*  421:     */     case 'k': 
/*  422: 478 */       return jjMoveStringLiteralDfa3_0(active0, 16777216L, active1, 0L);
/*  423:     */     case 'L': 
/*  424:     */     case 'l': 
/*  425: 481 */       if ((active0 & 0x1000) != 0L) {
/*  426: 482 */         return jjStartNfaWithStates_0(2, 12, 36);
/*  427:     */       }
/*  428: 483 */       return jjMoveStringLiteralDfa3_0(active0, 146929972211089408L, active1, 0L);
/*  429:     */     case 'M': 
/*  430:     */     case 'm': 
/*  431: 486 */       return jjMoveStringLiteralDfa3_0(active0, 35201551958016L, active1, 0L);
/*  432:     */     case 'N': 
/*  433:     */     case 'n': 
/*  434: 489 */       if ((active1 & 0x0) != 0L) {
/*  435: 490 */         return jjStopAtPos(2, 102);
/*  436:     */       }
/*  437: 491 */       return jjMoveStringLiteralDfa3_0(active0, 17592186044416L, active1, 0L);
/*  438:     */     case 'O': 
/*  439:     */     case 'o': 
/*  440: 494 */       return jjMoveStringLiteralDfa3_0(active0, 2199325245440L, active1, 0L);
/*  441:     */     case 'P': 
/*  442:     */     case 'p': 
/*  443: 497 */       if ((active0 & 0x80000) != 0L) {
/*  444: 498 */         return jjStartNfaWithStates_0(2, 19, 36);
/*  445:     */       }
/*  446: 499 */       return jjMoveStringLiteralDfa3_0(active0, 2305843009213693952L, active1, 0L);
/*  447:     */     case 'S': 
/*  448:     */     case 's': 
/*  449: 502 */       if ((active1 & 0x0) != 0L) {
/*  450: 503 */         return jjStopAtPos(2, 101);
/*  451:     */       }
/*  452: 504 */       return jjMoveStringLiteralDfa3_0(active0, 36028806684737536L, active1, 1L);
/*  453:     */     case 'T': 
/*  454:     */     case 't': 
/*  455: 507 */       if ((active0 & 0x10000) != 0L) {
/*  456: 508 */         return jjStartNfaWithStates_0(2, 16, 36);
/*  457:     */       }
/*  458: 509 */       if ((active0 & 0x20000) != 0L) {
/*  459: 510 */         return jjStartNfaWithStates_0(2, 17, 36);
/*  460:     */       }
/*  461: 511 */       return jjMoveStringLiteralDfa3_0(active0, 5764677960502083584L, active1, 2L);
/*  462:     */     case 'U': 
/*  463:     */     case 'u': 
/*  464: 514 */       return jjMoveStringLiteralDfa3_0(active0, -9223372036854775808L, active1, 0L);
/*  465:     */     case 'V': 
/*  466:     */     case 'v': 
/*  467: 517 */       return jjMoveStringLiteralDfa3_0(active0, 18014398509481984L, active1, 0L);
/*  468:     */     case 'Y': 
/*  469:     */     case 'y': 
/*  470: 520 */       if ((active0 & 0x4000) != 0L) {
/*  471: 521 */         return jjStartNfaWithStates_0(2, 14, 36);
/*  472:     */       }
/*  473: 522 */       if ((active0 & 0x8000) != 0L) {
/*  474: 523 */         return jjStartNfaWithStates_0(2, 15, 36);
/*  475:     */       }
/*  476:     */       break;
/*  477:     */     }
/*  478: 528 */     return jjStartNfa_0(1, active0, active1);
/*  479:     */   }
/*  480:     */   
/*  481:     */   private int jjMoveStringLiteralDfa3_0(long old0, long active0, long old1, long active1)
/*  482:     */   {
/*  483: 532 */     if ((active0 &= old0 | active1 &= old1) == 0L) {
/*  484: 533 */       return jjStartNfa_0(1, old0, old1);
/*  485:     */     }
/*  486:     */     try
/*  487:     */     {
/*  488: 534 */       this.curChar = this.input_stream.readChar();
/*  489:     */     }
/*  490:     */     catch (IOException e)
/*  491:     */     {
/*  492: 536 */       jjStopStringLiteralDfa_0(2, active0, active1);
/*  493: 537 */       return 3;
/*  494:     */     }
/*  495: 539 */     switch (this.curChar)
/*  496:     */     {
/*  497:     */     case 'A': 
/*  498:     */     case 'a': 
/*  499: 543 */       return jjMoveStringLiteralDfa4_0(active0, 361413870096482304L, active1, 0L);
/*  500:     */     case 'C': 
/*  501:     */     case 'c': 
/*  502: 546 */       if ((active0 & 0x200000) != 0L) {
/*  503: 547 */         return jjStartNfaWithStates_0(3, 21, 36);
/*  504:     */       }
/*  505:     */       break;
/*  506:     */     case 'E': 
/*  507:     */     case 'e': 
/*  508: 551 */       if ((active0 & 0x1000000) != 0L) {
/*  509: 552 */         return jjStartNfaWithStates_0(3, 24, 36);
/*  510:     */       }
/*  511: 553 */       if ((active0 & 0x40000000) != 0L) {
/*  512: 554 */         return jjStartNfaWithStates_0(3, 30, 36);
/*  513:     */       }
/*  514: 555 */       if ((active0 & 0x0) != 0L) {
/*  515: 556 */         return jjStartNfaWithStates_0(3, 33, 36);
/*  516:     */       }
/*  517: 557 */       if ((active0 & 0x0) != 0L) {
/*  518: 558 */         return jjStartNfaWithStates_0(3, 34, 36);
/*  519:     */       }
/*  520: 559 */       return jjMoveStringLiteralDfa4_0(active0, 39081041297670144L, active1, 2L);
/*  521:     */     case 'H': 
/*  522:     */     case 'h': 
/*  523: 562 */       if ((active0 & 0x0) != 0L) {
/*  524: 563 */         return jjStartNfaWithStates_0(3, 36, 36);
/*  525:     */       }
/*  526: 564 */       return jjMoveStringLiteralDfa4_0(active0, 281474976710656L, active1, 0L);
/*  527:     */     case 'I': 
/*  528:     */     case 'i': 
/*  529: 567 */       return jjMoveStringLiteralDfa4_0(active0, 18053980928081920L, active1, 0L);
/*  530:     */     case 'L': 
/*  531:     */     case 'l': 
/*  532: 570 */       if ((active0 & 0x800000) != 0L) {
/*  533: 571 */         return jjStartNfaWithStates_0(3, 23, 36);
/*  534:     */       }
/*  535: 572 */       if ((active0 & 0x0) != 0L) {
/*  536: 573 */         return jjStartNfaWithStates_0(3, 35, 36);
/*  537:     */       }
/*  538: 574 */       return jjMoveStringLiteralDfa4_0(active0, 2305843146652647424L, active1, 0L);
/*  539:     */     case 'M': 
/*  540:     */     case 'm': 
/*  541: 577 */       if ((active0 & 0x10000000) != 0L) {
/*  542: 578 */         return jjStartNfaWithStates_0(3, 28, 36);
/*  543:     */       }
/*  544: 579 */       return jjMoveStringLiteralDfa4_0(active0, 576460752303423488L, active1, 0L);
/*  545:     */     case 'N': 
/*  546:     */     case 'n': 
/*  547: 582 */       if ((active0 & 0x4000000) != 0L) {
/*  548: 583 */         return jjStartNfaWithStates_0(3, 26, 36);
/*  549:     */       }
/*  550: 584 */       if ((active0 & 0x20000000) != 0L) {
/*  551: 585 */         return jjStartNfaWithStates_0(3, 29, 36);
/*  552:     */       }
/*  553: 586 */       if ((active0 & 0x80000000) != 0L) {
/*  554: 587 */         return jjStartNfaWithStates_0(3, 31, 36);
/*  555:     */       }
/*  556: 588 */       if ((active0 & 0x0) != 0L) {
/*  557: 589 */         return jjStartNfaWithStates_0(3, 32, 36);
/*  558:     */       }
/*  559: 590 */       return jjMoveStringLiteralDfa4_0(active0, -9223371487098961920L, active1, 0L);
/*  560:     */     case 'O': 
/*  561:     */     case 'o': 
/*  562: 593 */       if ((active0 & 0x400000) != 0L) {
/*  563: 594 */         return jjStartNfaWithStates_0(3, 22, 36);
/*  564:     */       }
/*  565: 595 */       return jjMoveStringLiteralDfa4_0(active0, 1099511627776L, active1, 0L);
/*  566:     */     case 'P': 
/*  567:     */     case 'p': 
/*  568: 598 */       if ((active0 & 0x2000000) != 0L) {
/*  569: 599 */         return jjStartNfaWithStates_0(3, 25, 36);
/*  570:     */       }
/*  571:     */       break;
/*  572:     */     case 'R': 
/*  573:     */     case 'r': 
/*  574: 603 */       return jjMoveStringLiteralDfa4_0(active0, 274877906944L, active1, 0L);
/*  575:     */     case 'S': 
/*  576:     */     case 's': 
/*  577: 606 */       return jjMoveStringLiteralDfa4_0(active0, 13510798882111488L, active1, 0L);
/*  578:     */     case 'T': 
/*  579:     */     case 't': 
/*  580: 609 */       if ((active0 & 0x8000000) != 0L) {
/*  581: 610 */         return jjStartNfaWithStates_0(3, 27, 36);
/*  582:     */       }
/*  583: 611 */       return jjMoveStringLiteralDfa4_0(active0, 0L, active1, 1L);
/*  584:     */     case 'U': 
/*  585:     */     case 'u': 
/*  586: 614 */       return jjMoveStringLiteralDfa4_0(active0, 1297038891705958400L, active1, 0L);
/*  587:     */     case 'W': 
/*  588:     */     case 'w': 
/*  589: 617 */       return jjMoveStringLiteralDfa4_0(active0, 4611686018427387904L, active1, 0L);
/*  590:     */     }
/*  591: 621 */     return jjStartNfa_0(2, active0, active1);
/*  592:     */   }
/*  593:     */   
/*  594:     */   private int jjMoveStringLiteralDfa4_0(long old0, long active0, long old1, long active1)
/*  595:     */   {
/*  596: 625 */     if ((active0 &= old0 | active1 &= old1) == 0L) {
/*  597: 626 */       return jjStartNfa_0(2, old0, old1);
/*  598:     */     }
/*  599:     */     try
/*  600:     */     {
/*  601: 627 */       this.curChar = this.input_stream.readChar();
/*  602:     */     }
/*  603:     */     catch (IOException e)
/*  604:     */     {
/*  605: 629 */       jjStopStringLiteralDfa_0(3, active0, active1);
/*  606: 630 */       return 4;
/*  607:     */     }
/*  608: 632 */     switch (this.curChar)
/*  609:     */     {
/*  610:     */     case 'A': 
/*  611:     */     case 'a': 
/*  612: 636 */       return jjMoveStringLiteralDfa5_0(active0, 2882303761517117440L, active1, 0L);
/*  613:     */     case 'C': 
/*  614:     */     case 'c': 
/*  615: 639 */       return jjMoveStringLiteralDfa5_0(active0, -9221120237041090560L, active1, 0L);
/*  616:     */     case 'E': 
/*  617:     */     case 'e': 
/*  618: 642 */       if ((active0 & 0x0) != 0L) {
/*  619: 643 */         return jjStartNfaWithStates_0(4, 37, 36);
/*  620:     */       }
/*  621: 644 */       if ((active0 & 0x0) != 0L) {
/*  622: 645 */         return jjStartNfaWithStates_0(4, 38, 36);
/*  623:     */       }
/*  624: 646 */       return jjMoveStringLiteralDfa5_0(active0, 4760304806130614272L, active1, 0L);
/*  625:     */     case 'G': 
/*  626:     */     case 'g': 
/*  627: 649 */       if ((active0 & 0x0) != 0L) {
/*  628: 650 */         return jjStartNfaWithStates_0(4, 39, 36);
/*  629:     */       }
/*  630:     */       break;
/*  631:     */     case 'I': 
/*  632:     */     case 'i': 
/*  633: 654 */       return jjMoveStringLiteralDfa5_0(active0, 0L, active1, 1L);
/*  634:     */     case 'N': 
/*  635:     */     case 'n': 
/*  636: 657 */       if ((active0 & 0x0) != 0L) {
/*  637: 658 */         return jjStartNfaWithStates_0(4, 40, 36);
/*  638:     */       }
/*  639: 659 */       if ((active0 & 0x0) != 0L) {
/*  640: 660 */         return jjStartNfaWithStates_0(4, 42, 36);
/*  641:     */       }
/*  642: 661 */       return jjMoveStringLiteralDfa5_0(active0, 18014398509481984L, active1, 0L);
/*  643:     */     case 'P': 
/*  644:     */     case 'p': 
/*  645: 664 */       if ((active0 & 0x0) != 0L) {
/*  646: 665 */         return jjStartNfaWithStates_0(4, 41, 36);
/*  647:     */       }
/*  648: 666 */       return jjMoveStringLiteralDfa5_0(active0, 288230376151711744L, active1, 0L);
/*  649:     */     case 'R': 
/*  650:     */     case 'r': 
/*  651: 669 */       if ((active0 & 0x0) != 0L) {
/*  652: 670 */         return jjStartNfaWithStates_0(4, 44, 36);
/*  653:     */       }
/*  654: 671 */       if ((active0 & 0x0) != 0L) {
/*  655: 672 */         return jjStartNfaWithStates_0(4, 46, 36);
/*  656:     */       }
/*  657: 673 */       if ((active0 & 0x0) != 0L) {
/*  658: 674 */         return jjStartNfaWithStates_0(4, 47, 36);
/*  659:     */       }
/*  660: 675 */       return jjMoveStringLiteralDfa5_0(active0, 1188950301625810944L, active1, 2L);
/*  661:     */     case 'T': 
/*  662:     */     case 't': 
/*  663: 678 */       if ((active0 & 0x0) != 0L) {
/*  664: 679 */         return jjStartNfaWithStates_0(4, 45, 36);
/*  665:     */       }
/*  666: 680 */       if ((active0 & 0x0) != 0L) {
/*  667: 681 */         return jjStartNfaWithStates_0(4, 48, 36);
/*  668:     */       }
/*  669: 682 */       return jjMoveStringLiteralDfa5_0(active0, 82753643152932864L, active1, 0L);
/*  670:     */     case 'X': 
/*  671:     */     case 'x': 
/*  672: 685 */       if ((active0 & 0x0) != 0L) {
/*  673: 686 */         return jjStartNfaWithStates_0(4, 43, 36);
/*  674:     */       }
/*  675:     */       break;
/*  676:     */     }
/*  677: 691 */     return jjStartNfa_0(3, active0, active1);
/*  678:     */   }
/*  679:     */   
/*  680:     */   private int jjMoveStringLiteralDfa5_0(long old0, long active0, long old1, long active1)
/*  681:     */   {
/*  682: 695 */     if ((active0 &= old0 | active1 &= old1) == 0L) {
/*  683: 696 */       return jjStartNfa_0(3, old0, old1);
/*  684:     */     }
/*  685:     */     try
/*  686:     */     {
/*  687: 697 */       this.curChar = this.input_stream.readChar();
/*  688:     */     }
/*  689:     */     catch (IOException e)
/*  690:     */     {
/*  691: 699 */       jjStopStringLiteralDfa_0(4, active0, active1);
/*  692: 700 */       return 5;
/*  693:     */     }
/*  694: 702 */     switch (this.curChar)
/*  695:     */     {
/*  696:     */     case 'A': 
/*  697:     */     case 'a': 
/*  698: 706 */       return jjMoveStringLiteralDfa6_0(active0, -8070450532247928832L, active1, 0L);
/*  699:     */     case 'C': 
/*  700:     */     case 'c': 
/*  701: 709 */       return jjMoveStringLiteralDfa6_0(active0, 2305843009213693952L, active1, 0L);
/*  702:     */     case 'E': 
/*  703:     */     case 'e': 
/*  704: 712 */       if ((active0 & 0x0) != 0L) {
/*  705: 713 */         return jjStartNfaWithStates_0(5, 49, 36);
/*  706:     */       }
/*  707: 714 */       if ((active0 & 0x0) != 0L) {
/*  708: 715 */         return jjStartNfaWithStates_0(5, 50, 36);
/*  709:     */       }
/*  710: 716 */       if ((active0 & 0x0) != 0L) {
/*  711: 717 */         return jjStartNfaWithStates_0(5, 56, 36);
/*  712:     */       }
/*  713: 718 */       if ((active0 & 0x0) != 0L) {
/*  714: 719 */         return jjStartNfaWithStates_0(5, 58, 36);
/*  715:     */       }
/*  716: 720 */       return jjMoveStringLiteralDfa6_0(active0, 4611686018427387904L, active1, 0L);
/*  717:     */     case 'G': 
/*  718:     */     case 'g': 
/*  719: 723 */       if ((active0 & 0x0) != 0L) {
/*  720: 724 */         return jjStartNfaWithStates_0(5, 54, 36);
/*  721:     */       }
/*  722:     */       break;
/*  723:     */     case 'N': 
/*  724:     */     case 'n': 
/*  725: 728 */       return jjMoveStringLiteralDfa6_0(active0, 0L, active1, 1L);
/*  726:     */     case 'R': 
/*  727:     */     case 'r': 
/*  728: 731 */       return jjMoveStringLiteralDfa6_0(active0, 576460752303423488L, active1, 0L);
/*  729:     */     case 'S': 
/*  730:     */     case 's': 
/*  731: 734 */       if ((active0 & 0x0) != 0L) {
/*  732: 735 */         return jjStartNfaWithStates_0(5, 53, 36);
/*  733:     */       }
/*  734: 736 */       if ((active0 & 0x0) != 0L) {
/*  735: 737 */         return jjStartNfaWithStates_0(5, 57, 36);
/*  736:     */       }
/*  737: 738 */       return jjMoveStringLiteralDfa6_0(active0, 0L, active1, 2L);
/*  738:     */     case 'T': 
/*  739:     */     case 't': 
/*  740: 741 */       if ((active0 & 0x0) != 0L) {
/*  741: 742 */         return jjStartNfaWithStates_0(5, 51, 36);
/*  742:     */       }
/*  743: 743 */       if ((active0 & 0x0) != 0L) {
/*  744: 744 */         return jjStartNfaWithStates_0(5, 52, 36);
/*  745:     */       }
/*  746: 745 */       if ((active0 & 0x0) != 0L) {
/*  747: 746 */         return jjStartNfaWithStates_0(5, 55, 36);
/*  748:     */       }
/*  749:     */       break;
/*  750:     */     }
/*  751: 751 */     return jjStartNfa_0(4, active0, active1);
/*  752:     */   }
/*  753:     */   
/*  754:     */   private int jjMoveStringLiteralDfa6_0(long old0, long active0, long old1, long active1)
/*  755:     */   {
/*  756: 755 */     if ((active0 &= old0 | active1 &= old1) == 0L) {
/*  757: 756 */       return jjStartNfa_0(4, old0, old1);
/*  758:     */     }
/*  759:     */     try
/*  760:     */     {
/*  761: 757 */       this.curChar = this.input_stream.readChar();
/*  762:     */     }
/*  763:     */     catch (IOException e)
/*  764:     */     {
/*  765: 759 */       jjStopStringLiteralDfa_0(5, active0, active1);
/*  766: 760 */       return 6;
/*  767:     */     }
/*  768: 762 */     switch (this.curChar)
/*  769:     */     {
/*  770:     */     case 'C': 
/*  771:     */     case 'c': 
/*  772: 766 */       return jjMoveStringLiteralDfa7_0(active0, 0L, active1, 1L);
/*  773:     */     case 'E': 
/*  774:     */     case 'e': 
/*  775: 769 */       if ((active0 & 0x0) != 0L) {
/*  776: 770 */         return jjStartNfaWithStates_0(6, 61, 36);
/*  777:     */       }
/*  778: 771 */       return jjMoveStringLiteralDfa7_0(active0, 0L, active1, 2L);
/*  779:     */     case 'L': 
/*  780:     */     case 'l': 
/*  781: 774 */       if ((active0 & 0x0) != 0L) {
/*  782: 775 */         return jjStartNfaWithStates_0(6, 60, 36);
/*  783:     */       }
/*  784:     */       break;
/*  785:     */     case 'N': 
/*  786:     */     case 'n': 
/*  787: 779 */       if ((active0 & 0x0) != 0L) {
/*  788: 780 */         return jjStartNfaWithStates_0(6, 62, 36);
/*  789:     */       }
/*  790:     */       break;
/*  791:     */     case 'T': 
/*  792:     */     case 't': 
/*  793: 784 */       return jjMoveStringLiteralDfa7_0(active0, -9223372036854775808L, active1, 0L);
/*  794:     */     case 'Y': 
/*  795:     */     case 'y': 
/*  796: 787 */       if ((active0 & 0x0) != 0L) {
/*  797: 788 */         return jjStartNfaWithStates_0(6, 59, 36);
/*  798:     */       }
/*  799:     */       break;
/*  800:     */     }
/*  801: 793 */     return jjStartNfa_0(5, active0, active1);
/*  802:     */   }
/*  803:     */   
/*  804:     */   private int jjMoveStringLiteralDfa7_0(long old0, long active0, long old1, long active1)
/*  805:     */   {
/*  806: 797 */     if ((active0 &= old0 | active1 &= old1) == 0L) {
/*  807: 798 */       return jjStartNfa_0(5, old0, old1);
/*  808:     */     }
/*  809:     */     try
/*  810:     */     {
/*  811: 799 */       this.curChar = this.input_stream.readChar();
/*  812:     */     }
/*  813:     */     catch (IOException e)
/*  814:     */     {
/*  815: 801 */       jjStopStringLiteralDfa_0(6, active0, active1);
/*  816: 802 */       return 7;
/*  817:     */     }
/*  818: 804 */     switch (this.curChar)
/*  819:     */     {
/*  820:     */     case 'C': 
/*  821:     */     case 'c': 
/*  822: 808 */       return jjMoveStringLiteralDfa8_0(active0, 0L, active1, 2L);
/*  823:     */     case 'E': 
/*  824:     */     case 'e': 
/*  825: 811 */       if ((active0 & 0x0) != 0L) {
/*  826: 812 */         return jjStartNfaWithStates_0(7, 63, 36);
/*  827:     */       }
/*  828:     */       break;
/*  829:     */     case 'T': 
/*  830:     */     case 't': 
/*  831: 816 */       if ((active1 & 1L) != 0L) {
/*  832: 817 */         return jjStartNfaWithStates_0(7, 64, 36);
/*  833:     */       }
/*  834:     */       break;
/*  835:     */     }
/*  836: 822 */     return jjStartNfa_0(6, active0, active1);
/*  837:     */   }
/*  838:     */   
/*  839:     */   private int jjMoveStringLiteralDfa8_0(long old0, long active0, long old1, long active1)
/*  840:     */   {
/*  841: 826 */     if ((active0 &= old0 | active1 &= old1) == 0L) {
/*  842: 827 */       return jjStartNfa_0(6, old0, old1);
/*  843:     */     }
/*  844:     */     try
/*  845:     */     {
/*  846: 828 */       this.curChar = this.input_stream.readChar();
/*  847:     */     }
/*  848:     */     catch (IOException e)
/*  849:     */     {
/*  850: 830 */       jjStopStringLiteralDfa_0(7, 0L, active1);
/*  851: 831 */       return 8;
/*  852:     */     }
/*  853: 833 */     switch (this.curChar)
/*  854:     */     {
/*  855:     */     case 'T': 
/*  856:     */     case 't': 
/*  857: 837 */       if ((active1 & 0x2) != 0L) {
/*  858: 838 */         return jjStartNfaWithStates_0(8, 65, 36);
/*  859:     */       }
/*  860:     */       break;
/*  861:     */     }
/*  862: 843 */     return jjStartNfa_0(7, 0L, active1);
/*  863:     */   }
/*  864:     */   
/*  865:     */   private int jjStartNfaWithStates_0(int pos, int kind, int state)
/*  866:     */   {
/*  867: 847 */     this.jjmatchedKind = kind;
/*  868: 848 */     this.jjmatchedPos = pos;
/*  869:     */     try
/*  870:     */     {
/*  871: 849 */       this.curChar = this.input_stream.readChar();
/*  872:     */     }
/*  873:     */     catch (IOException e)
/*  874:     */     {
/*  875: 850 */       return pos + 1;
/*  876:     */     }
/*  877: 851 */     return jjMoveNfa_0(state, pos + 1);
/*  878:     */   }
/*  879:     */   
/*  880: 853 */   static final long[] jjbitVec0 = { 0L, 0L, -1L, -1L };
/*  881:     */   
/*  882:     */   private int jjMoveNfa_0(int startState, int curPos)
/*  883:     */   {
/*  884: 858 */     int startsAt = 0;
/*  885: 859 */     this.jjnewStateCnt = 36;
/*  886: 860 */     int i = 1;
/*  887: 861 */     this.jjstateSet[0] = startState;
/*  888: 862 */     int kind = 2147483647;
/*  889:     */     for (;;)
/*  890:     */     {
/*  891: 865 */       if (++this.jjround == 2147483647) {
/*  892: 866 */         ReInitRounds();
/*  893:     */       }
/*  894: 867 */       if (this.curChar < '@')
/*  895:     */       {
/*  896: 869 */         long l = 1L << this.curChar;
/*  897:     */         do
/*  898:     */         {
/*  899: 872 */           switch (this.jjstateSet[(--i)])
/*  900:     */           {
/*  901:     */           case 16: 
/*  902:     */           case 36: 
/*  903: 876 */             if ((0x0 & l) != 0L)
/*  904:     */             {
/*  905: 878 */               if (kind > 71) {
/*  906: 879 */                 kind = 71;
/*  907:     */               }
/*  908: 880 */               jjCheckNAdd(16);
/*  909:     */             }
/*  910: 881 */             break;
/*  911:     */           case 7: 
/*  912: 883 */             if ((0x0 & l) != 0L)
/*  913:     */             {
/*  914: 885 */               if (kind > 67) {
/*  915: 886 */                 kind = 67;
/*  916:     */               }
/*  917: 887 */               jjCheckNAddStates(0, 5);
/*  918:     */             }
/*  919: 889 */             else if (this.curChar == '"')
/*  920:     */             {
/*  921: 890 */               jjCheckNAddTwoStates(23, 24);
/*  922:     */             }
/*  923: 891 */             else if (this.curChar == '\'')
/*  924:     */             {
/*  925: 892 */               jjCheckNAddTwoStates(18, 19);
/*  926:     */             }
/*  927: 893 */             else if (this.curChar == '/')
/*  928:     */             {
/*  929: 894 */               this.jjstateSet[(this.jjnewStateCnt++)] = 8;
/*  930:     */             }
/*  931: 895 */             else if (this.curChar == '-')
/*  932:     */             {
/*  933: 896 */               this.jjstateSet[(this.jjnewStateCnt++)] = 5;
/*  934:     */             }
/*  935: 897 */             else if (this.curChar == '.')
/*  936:     */             {
/*  937: 898 */               jjCheckNAdd(1);
/*  938:     */             }
/*  939:     */             break;
/*  940:     */           case 0: 
/*  941: 901 */             if (this.curChar == '.') {
/*  942: 902 */               jjCheckNAdd(1);
/*  943:     */             }
/*  944:     */             break;
/*  945:     */           case 1: 
/*  946: 905 */             if ((0x0 & l) != 0L)
/*  947:     */             {
/*  948: 907 */               if (kind > 66) {
/*  949: 908 */                 kind = 66;
/*  950:     */               }
/*  951: 909 */               jjCheckNAddTwoStates(1, 2);
/*  952:     */             }
/*  953: 910 */             break;
/*  954:     */           case 3: 
/*  955: 912 */             if ((0x0 & l) != 0L) {
/*  956: 913 */               jjCheckNAdd(4);
/*  957:     */             }
/*  958:     */             break;
/*  959:     */           case 4: 
/*  960: 916 */             if ((0x0 & l) != 0L)
/*  961:     */             {
/*  962: 918 */               if (kind > 66) {
/*  963: 919 */                 kind = 66;
/*  964:     */               }
/*  965: 920 */               jjCheckNAdd(4);
/*  966:     */             }
/*  967: 921 */             break;
/*  968:     */           case 5: 
/*  969: 923 */             if (this.curChar == '-')
/*  970:     */             {
/*  971: 925 */               if (kind > 69) {
/*  972: 926 */                 kind = 69;
/*  973:     */               }
/*  974: 927 */               jjCheckNAdd(6);
/*  975:     */             }
/*  976: 928 */             break;
/*  977:     */           case 6: 
/*  978: 930 */             if ((0xFFFFDBFF & l) != 0L)
/*  979:     */             {
/*  980: 932 */               if (kind > 69) {
/*  981: 933 */                 kind = 69;
/*  982:     */               }
/*  983: 934 */               jjCheckNAdd(6);
/*  984:     */             }
/*  985: 935 */             break;
/*  986:     */           case 8: 
/*  987: 937 */             if (this.curChar == '*') {
/*  988: 938 */               jjCheckNAddTwoStates(9, 10);
/*  989:     */             }
/*  990:     */             break;
/*  991:     */           case 9: 
/*  992: 941 */             if ((0xFFFFFFFF & l) != 0L) {
/*  993: 942 */               jjCheckNAddTwoStates(9, 10);
/*  994:     */             }
/*  995:     */             break;
/*  996:     */           case 10: 
/*  997: 945 */             if (this.curChar == '*') {
/*  998: 946 */               jjCheckNAddStates(6, 8);
/*  999:     */             }
/* 1000:     */             break;
/* 1001:     */           case 11: 
/* 1002: 949 */             if ((0xFFFFFFFF & l) != 0L) {
/* 1003: 950 */               jjCheckNAddTwoStates(12, 10);
/* 1004:     */             }
/* 1005:     */             break;
/* 1006:     */           case 12: 
/* 1007: 953 */             if ((0xFFFFFFFF & l) != 0L) {
/* 1008: 954 */               jjCheckNAddTwoStates(12, 10);
/* 1009:     */             }
/* 1010:     */             break;
/* 1011:     */           case 13: 
/* 1012: 957 */             if ((this.curChar == '/') && (kind > 70)) {
/* 1013: 958 */               kind = 70;
/* 1014:     */             }
/* 1015:     */             break;
/* 1016:     */           case 14: 
/* 1017: 961 */             if (this.curChar == '/') {
/* 1018: 962 */               this.jjstateSet[(this.jjnewStateCnt++)] = 8;
/* 1019:     */             }
/* 1020:     */             break;
/* 1021:     */           case 17: 
/* 1022: 965 */             if (this.curChar == '\'') {
/* 1023: 966 */               jjCheckNAddTwoStates(18, 19);
/* 1024:     */             }
/* 1025:     */             break;
/* 1026:     */           case 18: 
/* 1027: 969 */             if ((0xFFFFFFFF & l) != 0L) {
/* 1028: 970 */               jjCheckNAddTwoStates(18, 19);
/* 1029:     */             }
/* 1030:     */             break;
/* 1031:     */           case 19: 
/* 1032: 973 */             if (this.curChar == '\'')
/* 1033:     */             {
/* 1034: 975 */               if (kind > 74) {
/* 1035: 976 */                 kind = 74;
/* 1036:     */               }
/* 1037: 977 */               this.jjstateSet[(this.jjnewStateCnt++)] = 20;
/* 1038:     */             }
/* 1039: 978 */             break;
/* 1040:     */           case 20: 
/* 1041: 980 */             if (this.curChar == '\'') {
/* 1042: 981 */               jjCheckNAddTwoStates(21, 19);
/* 1043:     */             }
/* 1044:     */             break;
/* 1045:     */           case 21: 
/* 1046: 984 */             if ((0xFFFFFFFF & l) != 0L) {
/* 1047: 985 */               jjCheckNAddTwoStates(21, 19);
/* 1048:     */             }
/* 1049:     */             break;
/* 1050:     */           case 22: 
/* 1051: 988 */             if (this.curChar == '"') {
/* 1052: 989 */               jjCheckNAddTwoStates(23, 24);
/* 1053:     */             }
/* 1054:     */             break;
/* 1055:     */           case 23: 
/* 1056: 992 */             if ((0xFFFFDBFF & l) != 0L) {
/* 1057: 993 */               jjCheckNAddTwoStates(23, 24);
/* 1058:     */             }
/* 1059:     */             break;
/* 1060:     */           case 24: 
/* 1061: 996 */             if ((this.curChar == '"') && (kind > 75)) {
/* 1062: 997 */               kind = 75;
/* 1063:     */             }
/* 1064:     */             break;
/* 1065:     */           case 26: 
/* 1066:1000 */             if ((0xFFFFDBFF & l) != 0L) {
/* 1067:1001 */               jjAddStates(9, 10);
/* 1068:     */             }
/* 1069:     */             break;
/* 1070:     */           case 28: 
/* 1071:1004 */             if ((0x0 & l) != 0L)
/* 1072:     */             {
/* 1073:1006 */               if (kind > 67) {
/* 1074:1007 */                 kind = 67;
/* 1075:     */               }
/* 1076:1008 */               jjCheckNAddStates(0, 5);
/* 1077:     */             }
/* 1078:1009 */             break;
/* 1079:     */           case 29: 
/* 1080:1011 */             if ((0x0 & l) != 0L) {
/* 1081:1012 */               jjCheckNAddTwoStates(29, 0);
/* 1082:     */             }
/* 1083:     */             break;
/* 1084:     */           case 30: 
/* 1085:1015 */             if ((0x0 & l) != 0L) {
/* 1086:1016 */               jjCheckNAddStates(11, 13);
/* 1087:     */             }
/* 1088:     */             break;
/* 1089:     */           case 31: 
/* 1090:1019 */             if (this.curChar == '.') {
/* 1091:1020 */               jjCheckNAdd(32);
/* 1092:     */             }
/* 1093:     */             break;
/* 1094:     */           case 33: 
/* 1095:1023 */             if ((0x0 & l) != 0L) {
/* 1096:1024 */               jjCheckNAdd(34);
/* 1097:     */             }
/* 1098:     */             break;
/* 1099:     */           case 34: 
/* 1100:1027 */             if ((0x0 & l) != 0L)
/* 1101:     */             {
/* 1102:1029 */               if (kind > 66) {
/* 1103:1030 */                 kind = 66;
/* 1104:     */               }
/* 1105:1031 */               jjCheckNAdd(34);
/* 1106:     */             }
/* 1107:1032 */             break;
/* 1108:     */           case 35: 
/* 1109:1034 */             if ((0x0 & l) != 0L)
/* 1110:     */             {
/* 1111:1036 */               if (kind > 67) {
/* 1112:1037 */                 kind = 67;
/* 1113:     */               }
/* 1114:1038 */               jjCheckNAdd(35);
/* 1115:     */             }
/* 1116:     */             break;
/* 1117:     */           }
/* 1118:1042 */         } while (i != startsAt);
/* 1119:     */       }
/* 1120:1044 */       else if (this.curChar < '')
/* 1121:     */       {
/* 1122:1046 */         long l = 1L << (this.curChar & 0x3F);
/* 1123:     */         do
/* 1124:     */         {
/* 1125:1049 */           switch (this.jjstateSet[(--i)])
/* 1126:     */           {
/* 1127:     */           case 36: 
/* 1128:1052 */             if ((0x87FFFFFE & l) != 0L)
/* 1129:     */             {
/* 1130:1054 */               if (kind > 71) {
/* 1131:1055 */                 kind = 71;
/* 1132:     */               }
/* 1133:1056 */               jjCheckNAdd(16);
/* 1134:     */             }
/* 1135:1058 */             if ((0x87FFFFFE & l) != 0L)
/* 1136:     */             {
/* 1137:1060 */               if (kind > 71) {
/* 1138:1061 */                 kind = 71;
/* 1139:     */               }
/* 1140:1062 */               jjCheckNAddTwoStates(15, 16);
/* 1141:     */             }
/* 1142:     */             break;
/* 1143:     */           case 7: 
/* 1144:1066 */             if ((0x87FFFFFE & l) != 0L)
/* 1145:     */             {
/* 1146:1068 */               if (kind > 71) {
/* 1147:1069 */                 kind = 71;
/* 1148:     */               }
/* 1149:1070 */               jjCheckNAddTwoStates(15, 16);
/* 1150:     */             }
/* 1151:1072 */             else if (this.curChar == '`')
/* 1152:     */             {
/* 1153:1073 */               jjCheckNAddTwoStates(26, 27);
/* 1154:     */             }
/* 1155:     */             break;
/* 1156:     */           case 2: 
/* 1157:1076 */             if ((0x20 & l) != 0L) {
/* 1158:1077 */               jjAddStates(14, 15);
/* 1159:     */             }
/* 1160:     */             break;
/* 1161:     */           case 6: 
/* 1162:1080 */             if (kind > 69) {
/* 1163:1081 */               kind = 69;
/* 1164:     */             }
/* 1165:1082 */             this.jjstateSet[(this.jjnewStateCnt++)] = 6;
/* 1166:1083 */             break;
/* 1167:     */           case 9: 
/* 1168:1085 */             jjCheckNAddTwoStates(9, 10);
/* 1169:1086 */             break;
/* 1170:     */           case 11: 
/* 1171:     */           case 12: 
/* 1172:1089 */             jjCheckNAddTwoStates(12, 10);
/* 1173:1090 */             break;
/* 1174:     */           case 15: 
/* 1175:1092 */             if ((0x87FFFFFE & l) != 0L)
/* 1176:     */             {
/* 1177:1094 */               if (kind > 71) {
/* 1178:1095 */                 kind = 71;
/* 1179:     */               }
/* 1180:1096 */               jjCheckNAddTwoStates(15, 16);
/* 1181:     */             }
/* 1182:1097 */             break;
/* 1183:     */           case 16: 
/* 1184:1099 */             if ((0x87FFFFFE & l) != 0L)
/* 1185:     */             {
/* 1186:1101 */               if (kind > 71) {
/* 1187:1102 */                 kind = 71;
/* 1188:     */               }
/* 1189:1103 */               jjCheckNAdd(16);
/* 1190:     */             }
/* 1191:1104 */             break;
/* 1192:     */           case 18: 
/* 1193:1106 */             jjCheckNAddTwoStates(18, 19);
/* 1194:1107 */             break;
/* 1195:     */           case 21: 
/* 1196:1109 */             jjCheckNAddTwoStates(21, 19);
/* 1197:1110 */             break;
/* 1198:     */           case 23: 
/* 1199:1112 */             jjAddStates(16, 17);
/* 1200:1113 */             break;
/* 1201:     */           case 25: 
/* 1202:1115 */             if (this.curChar == '`') {
/* 1203:1116 */               jjCheckNAddTwoStates(26, 27);
/* 1204:     */             }
/* 1205:     */             break;
/* 1206:     */           case 26: 
/* 1207:1119 */             if ((0xFFFFFFFF & l) != 0L) {
/* 1208:1120 */               jjCheckNAddTwoStates(26, 27);
/* 1209:     */             }
/* 1210:     */             break;
/* 1211:     */           case 27: 
/* 1212:1123 */             if ((this.curChar == '`') && (kind > 75)) {
/* 1213:1124 */               kind = 75;
/* 1214:     */             }
/* 1215:     */             break;
/* 1216:     */           case 32: 
/* 1217:1127 */             if ((0x20 & l) != 0L) {
/* 1218:1128 */               jjAddStates(18, 19);
/* 1219:     */             }
/* 1220:     */             break;
/* 1221:     */           }
/* 1222:1132 */         } while (i != startsAt);
/* 1223:     */       }
/* 1224:     */       else
/* 1225:     */       {
/* 1226:1136 */         int i2 = (this.curChar & 0xFF) >> '\006';
/* 1227:1137 */         long l2 = 1L << (this.curChar & 0x3F);
/* 1228:     */         do
/* 1229:     */         {
/* 1230:1140 */           switch (this.jjstateSet[(--i)])
/* 1231:     */           {
/* 1232:     */           case 6: 
/* 1233:1143 */             if ((jjbitVec0[i2] & l2) != 0L)
/* 1234:     */             {
/* 1235:1145 */               if (kind > 69) {
/* 1236:1146 */                 kind = 69;
/* 1237:     */               }
/* 1238:1147 */               this.jjstateSet[(this.jjnewStateCnt++)] = 6;
/* 1239:     */             }
/* 1240:1148 */             break;
/* 1241:     */           case 9: 
/* 1242:1150 */             if ((jjbitVec0[i2] & l2) != 0L) {
/* 1243:1151 */               jjCheckNAddTwoStates(9, 10);
/* 1244:     */             }
/* 1245:     */             break;
/* 1246:     */           case 11: 
/* 1247:     */           case 12: 
/* 1248:1155 */             if ((jjbitVec0[i2] & l2) != 0L) {
/* 1249:1156 */               jjCheckNAddTwoStates(12, 10);
/* 1250:     */             }
/* 1251:     */             break;
/* 1252:     */           case 18: 
/* 1253:1159 */             if ((jjbitVec0[i2] & l2) != 0L) {
/* 1254:1160 */               jjCheckNAddTwoStates(18, 19);
/* 1255:     */             }
/* 1256:     */             break;
/* 1257:     */           case 21: 
/* 1258:1163 */             if ((jjbitVec0[i2] & l2) != 0L) {
/* 1259:1164 */               jjCheckNAddTwoStates(21, 19);
/* 1260:     */             }
/* 1261:     */             break;
/* 1262:     */           case 23: 
/* 1263:1167 */             if ((jjbitVec0[i2] & l2) != 0L) {
/* 1264:1168 */               jjAddStates(16, 17);
/* 1265:     */             }
/* 1266:     */             break;
/* 1267:     */           case 26: 
/* 1268:1171 */             if ((jjbitVec0[i2] & l2) != 0L) {
/* 1269:1172 */               jjAddStates(9, 10);
/* 1270:     */             }
/* 1271:     */             break;
/* 1272:     */           }
/* 1273:1176 */         } while (i != startsAt);
/* 1274:     */       }
/* 1275:1178 */       if (kind != 2147483647)
/* 1276:     */       {
/* 1277:1180 */         this.jjmatchedKind = kind;
/* 1278:1181 */         this.jjmatchedPos = curPos;
/* 1279:1182 */         kind = 2147483647;
/* 1280:     */       }
/* 1281:1184 */       curPos++;
/* 1282:1185 */       if ((i = this.jjnewStateCnt) == (startsAt = 36 - (this.jjnewStateCnt = startsAt))) {
/* 1283:1186 */         return curPos;
/* 1284:     */       }
/* 1285:     */       try
/* 1286:     */       {
/* 1287:1187 */         this.curChar = this.input_stream.readChar();
/* 1288:     */       }
/* 1289:     */       catch (IOException e) {}
/* 1290:     */     }
/* 1291:1188 */     return curPos;
/* 1292:     */   }
/* 1293:     */   
/* 1294:1191 */   static final int[] jjnextStates = { 29, 0, 30, 31, 32, 35, 10, 11, 13, 26, 27, 30, 31, 32, 3, 4, 23, 24, 33, 34 };
/* 1295:1197 */   public static final String[] jjstrLiteralImages = { "", null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, ";", "=", ",", "(", ")", ".", "*", "?", ">", "<", ">=", "<=", "<>", "!=", "@@", "||", "|", "&", "+", "-", "/", "^", null, "}", null, null, null };
/* 1296:1208 */   public static final String[] lexStateNames = { "DEFAULT" };
/* 1297:1211 */   static final long[] jjtoToken = { -31L, 549755813007L };
/* 1298:1214 */   static final long[] jjtoSkip = { 30L, 96L };
/* 1299:1217 */   static final long[] jjtoSpecial = { 0L, 96L };
/* 1300:     */   protected SimpleCharStream input_stream;
/* 1301:1221 */   private final int[] jjrounds = new int[36];
/* 1302:1222 */   private final int[] jjstateSet = new int[72];
/* 1303:     */   protected char curChar;
/* 1304:     */   
/* 1305:     */   public CCJSqlParserTokenManager(SimpleCharStream stream)
/* 1306:     */   {
/* 1307:1228 */     this.input_stream = stream;
/* 1308:     */   }
/* 1309:     */   
/* 1310:     */   public CCJSqlParserTokenManager(SimpleCharStream stream, int lexState)
/* 1311:     */   {
/* 1312:1233 */     this(stream);
/* 1313:1234 */     SwitchTo(lexState);
/* 1314:     */   }
/* 1315:     */   
/* 1316:     */   public void ReInit(SimpleCharStream stream)
/* 1317:     */   {
/* 1318:1240 */     this.jjmatchedPos = (this.jjnewStateCnt = 0);
/* 1319:1241 */     this.curLexState = this.defaultLexState;
/* 1320:1242 */     this.input_stream = stream;
/* 1321:1243 */     ReInitRounds();
/* 1322:     */   }
/* 1323:     */   
/* 1324:     */   private void ReInitRounds()
/* 1325:     */   {
/* 1326:1248 */     this.jjround = -2147483647;
/* 1327:1249 */     for (int i = 36; i-- > 0;) {
/* 1328:1250 */       this.jjrounds[i] = -2147483648;
/* 1329:     */     }
/* 1330:     */   }
/* 1331:     */   
/* 1332:     */   public void ReInit(SimpleCharStream stream, int lexState)
/* 1333:     */   {
/* 1334:1256 */     ReInit(stream);
/* 1335:1257 */     SwitchTo(lexState);
/* 1336:     */   }
/* 1337:     */   
/* 1338:     */   public void SwitchTo(int lexState)
/* 1339:     */   {
/* 1340:1263 */     if ((lexState >= 1) || (lexState < 0)) {
/* 1341:1264 */       throw new TokenMgrError("Error: Ignoring invalid lexical state : " + lexState + ". State unchanged.", 2);
/* 1342:     */     }
/* 1343:1266 */     this.curLexState = lexState;
/* 1344:     */   }
/* 1345:     */   
/* 1346:     */   protected Token jjFillToken()
/* 1347:     */   {
/* 1348:1277 */     String im = jjstrLiteralImages[this.jjmatchedKind];
/* 1349:1278 */     String curTokenImage = im == null ? this.input_stream.GetImage() : im;
/* 1350:1279 */     int beginLine = this.input_stream.getBeginLine();
/* 1351:1280 */     int beginColumn = this.input_stream.getBeginColumn();
/* 1352:1281 */     int endLine = this.input_stream.getEndLine();
/* 1353:1282 */     int endColumn = this.input_stream.getEndColumn();
/* 1354:1283 */     Token t = Token.newToken(this.jjmatchedKind, curTokenImage);
/* 1355:     */     
/* 1356:1285 */     t.beginLine = beginLine;
/* 1357:1286 */     t.endLine = endLine;
/* 1358:1287 */     t.beginColumn = beginColumn;
/* 1359:1288 */     t.endColumn = endColumn;
/* 1360:     */     
/* 1361:1290 */     return t;
/* 1362:     */   }
/* 1363:     */   
/* 1364:1293 */   int curLexState = 0;
/* 1365:1294 */   int defaultLexState = 0;
/* 1366:     */   int jjnewStateCnt;
/* 1367:     */   int jjround;
/* 1368:     */   int jjmatchedPos;
/* 1369:     */   int jjmatchedKind;
/* 1370:     */   
/* 1371:     */   public Token getNextToken()
/* 1372:     */   {
/* 1373:1303 */     Token specialToken = null;
/* 1374:     */     
/* 1375:1305 */     int curPos = 0;
/* 1376:     */     for (;;)
/* 1377:     */     {
/* 1378:     */       try
/* 1379:     */       {
/* 1380:1312 */         this.curChar = this.input_stream.BeginToken();
/* 1381:     */       }
/* 1382:     */       catch (IOException e)
/* 1383:     */       {
/* 1384:1316 */         this.jjmatchedKind = 0;
/* 1385:1317 */         Token matchedToken = jjFillToken();
/* 1386:1318 */         matchedToken.specialToken = specialToken;
/* 1387:1319 */         return matchedToken;
/* 1388:     */       }
/* 1389:     */       try
/* 1390:     */       {
/* 1391:1322 */         this.input_stream.backup(0);
/* 1392:1323 */         while ((this.curChar <= ' ') && ((0x2600 & 1L << this.curChar) != 0L)) {
/* 1393:1324 */           this.curChar = this.input_stream.BeginToken();
/* 1394:     */         }
/* 1395:     */       }
/* 1396:     */       catch (IOException e1) {}
/* 1397:1326 */       continue;
/* 1398:1327 */       this.jjmatchedKind = 2147483647;
/* 1399:1328 */       this.jjmatchedPos = 0;
/* 1400:1329 */       curPos = jjMoveStringLiteralDfa0_0();
/* 1401:1330 */       if (this.jjmatchedKind == 2147483647) {
/* 1402:     */         break;
/* 1403:     */       }
/* 1404:1332 */       if (this.jjmatchedPos + 1 < curPos) {
/* 1405:1333 */         this.input_stream.backup(curPos - this.jjmatchedPos - 1);
/* 1406:     */       }
/* 1407:1334 */       if ((jjtoToken[(this.jjmatchedKind >> 6)] & 1L << (this.jjmatchedKind & 0x3F)) != 0L)
/* 1408:     */       {
/* 1409:1336 */         Token matchedToken = jjFillToken();
/* 1410:1337 */         matchedToken.specialToken = specialToken;
/* 1411:1338 */         return matchedToken;
/* 1412:     */       }
/* 1413:1342 */       if ((jjtoSpecial[(this.jjmatchedKind >> 6)] & 1L << (this.jjmatchedKind & 0x3F)) != 0L)
/* 1414:     */       {
/* 1415:1344 */         Token matchedToken = jjFillToken();
/* 1416:1345 */         if (specialToken == null)
/* 1417:     */         {
/* 1418:1346 */           specialToken = matchedToken;
/* 1419:     */         }
/* 1420:     */         else
/* 1421:     */         {
/* 1422:1349 */           matchedToken.specialToken = specialToken;
/* 1423:1350 */           specialToken = specialToken.next = matchedToken;
/* 1424:     */         }
/* 1425:     */       }
/* 1426:     */     }
/* 1427:1356 */     int error_line = this.input_stream.getEndLine();
/* 1428:1357 */     int error_column = this.input_stream.getEndColumn();
/* 1429:1358 */     String error_after = null;
/* 1430:1359 */     boolean EOFSeen = false;
/* 1431:     */     try
/* 1432:     */     {
/* 1433:1360 */       this.input_stream.readChar();this.input_stream.backup(1);
/* 1434:     */     }
/* 1435:     */     catch (IOException e1)
/* 1436:     */     {
/* 1437:1362 */       EOFSeen = true;
/* 1438:1363 */       error_after = curPos <= 1 ? "" : this.input_stream.GetImage();
/* 1439:1364 */       if ((this.curChar == '\n') || (this.curChar == '\r'))
/* 1440:     */       {
/* 1441:1365 */         error_line++;
/* 1442:1366 */         error_column = 0;
/* 1443:     */       }
/* 1444:     */       else
/* 1445:     */       {
/* 1446:1369 */         error_column++;
/* 1447:     */       }
/* 1448:     */     }
/* 1449:1371 */     if (!EOFSeen)
/* 1450:     */     {
/* 1451:1372 */       this.input_stream.backup(1);
/* 1452:1373 */       error_after = curPos <= 1 ? "" : this.input_stream.GetImage();
/* 1453:     */     }
/* 1454:1375 */     throw new TokenMgrError(EOFSeen, this.curLexState, error_line, error_column, error_after, this.curChar, 0);
/* 1455:     */   }
/* 1456:     */   
/* 1457:     */   private void jjCheckNAdd(int state)
/* 1458:     */   {
/* 1459:1381 */     if (this.jjrounds[state] != this.jjround)
/* 1460:     */     {
/* 1461:1383 */       this.jjstateSet[(this.jjnewStateCnt++)] = state;
/* 1462:1384 */       this.jjrounds[state] = this.jjround;
/* 1463:     */     }
/* 1464:     */   }
/* 1465:     */   
/* 1466:     */   private void jjAddStates(int start, int end)
/* 1467:     */   {
/* 1468:     */     do
/* 1469:     */     {
/* 1470:1390 */       this.jjstateSet[(this.jjnewStateCnt++)] = jjnextStates[start];
/* 1471:1391 */     } while (start++ != end);
/* 1472:     */   }
/* 1473:     */   
/* 1474:     */   private void jjCheckNAddTwoStates(int state1, int state2)
/* 1475:     */   {
/* 1476:1395 */     jjCheckNAdd(state1);
/* 1477:1396 */     jjCheckNAdd(state2);
/* 1478:     */   }
/* 1479:     */   
/* 1480:     */   private void jjCheckNAddStates(int start, int end)
/* 1481:     */   {
/* 1482:     */     do
/* 1483:     */     {
/* 1484:1402 */       jjCheckNAdd(jjnextStates[start]);
/* 1485:1403 */     } while (start++ != end);
/* 1486:     */   }
/* 1487:     */ }


/* Location:           E:\workspace\java\db\lib\jsqlparser.jar
 * Qualified Name:     net.sf.jsqlparser.parser.CCJSqlParserTokenManager
 * JD-Core Version:    0.7.0.1
 */