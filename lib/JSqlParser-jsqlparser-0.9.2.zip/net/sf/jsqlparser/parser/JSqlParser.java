package net.sf.jsqlparser.parser;

import java.io.Reader;
import net.sf.jsqlparser.JSQLParserException;
import net.sf.jsqlparser.statement.Statement;

public abstract interface JSqlParser
{
  public abstract Statement parse(Reader paramReader)
    throws JSQLParserException;
}


/* Location:           E:\workspace\java\db\lib\jsqlparser.jar
 * Qualified Name:     net.sf.jsqlparser.parser.JSqlParser
 * JD-Core Version:    0.7.0.1
 */