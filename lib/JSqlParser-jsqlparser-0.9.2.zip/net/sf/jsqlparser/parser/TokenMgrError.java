/*   1:    */ package net.sf.jsqlparser.parser;
/*   2:    */ 
/*   3:    */ public class TokenMgrError
/*   4:    */   extends Error
/*   5:    */ {
/*   6:    */   private static final long serialVersionUID = 1L;
/*   7:    */   static final int LEXICAL_ERROR = 0;
/*   8:    */   static final int STATIC_LEXER_ERROR = 1;
/*   9:    */   static final int INVALID_LEXICAL_STATE = 2;
/*  10:    */   static final int LOOP_DETECTED = 3;
/*  11:    */   int errorCode;
/*  12:    */   
/*  13:    */   protected static final String addEscapes(String str)
/*  14:    */   {
/*  15: 74 */     StringBuffer retval = new StringBuffer();
/*  16: 76 */     for (int i = 0; i < str.length(); i++) {
/*  17: 77 */       switch (str.charAt(i))
/*  18:    */       {
/*  19:    */       case '\000': 
/*  20:    */         break;
/*  21:    */       case '\b': 
/*  22: 82 */         retval.append("\\b");
/*  23: 83 */         break;
/*  24:    */       case '\t': 
/*  25: 85 */         retval.append("\\t");
/*  26: 86 */         break;
/*  27:    */       case '\n': 
/*  28: 88 */         retval.append("\\n");
/*  29: 89 */         break;
/*  30:    */       case '\f': 
/*  31: 91 */         retval.append("\\f");
/*  32: 92 */         break;
/*  33:    */       case '\r': 
/*  34: 94 */         retval.append("\\r");
/*  35: 95 */         break;
/*  36:    */       case '"': 
/*  37: 97 */         retval.append("\\\"");
/*  38: 98 */         break;
/*  39:    */       case '\'': 
/*  40:100 */         retval.append("\\'");
/*  41:101 */         break;
/*  42:    */       case '\\': 
/*  43:103 */         retval.append("\\\\");
/*  44:104 */         break;
/*  45:    */       default: 
/*  46:    */         char ch;
/*  47:106 */         if (((ch = str.charAt(i)) < ' ') || (ch > '~'))
/*  48:    */         {
/*  49:107 */           String s = "0000" + Integer.toString(ch, 16);
/*  50:108 */           retval.append("\\u" + s.substring(s.length() - 4, s.length()));
/*  51:    */         }
/*  52:    */         else
/*  53:    */         {
/*  54:110 */           retval.append(ch);
/*  55:    */         }
/*  56:    */         break;
/*  57:    */       }
/*  58:    */     }
/*  59:115 */     return retval.toString();
/*  60:    */   }
/*  61:    */   
/*  62:    */   protected static String LexicalError(boolean EOFSeen, int lexState, int errorLine, int errorColumn, String errorAfter, char curChar)
/*  63:    */   {
/*  64:135 */     return "Lexical error at line " + errorLine + ", column " + errorColumn + ".  Encountered: " + (EOFSeen ? "<EOF> " : new StringBuilder().append("\"").append(addEscapes(String.valueOf(curChar))).append("\"").append(" (").append(curChar).append("), ").toString()) + "after : \"" + addEscapes(errorAfter) + "\"";
/*  65:    */   }
/*  66:    */   
/*  67:    */   public String getMessage()
/*  68:    */   {
/*  69:148 */     return super.getMessage();
/*  70:    */   }
/*  71:    */   
/*  72:    */   public TokenMgrError() {}
/*  73:    */   
/*  74:    */   public TokenMgrError(String message, int reason)
/*  75:    */   {
/*  76:161 */     super(message);
/*  77:162 */     this.errorCode = reason;
/*  78:    */   }
/*  79:    */   
/*  80:    */   public TokenMgrError(boolean EOFSeen, int lexState, int errorLine, int errorColumn, String errorAfter, char curChar, int reason)
/*  81:    */   {
/*  82:167 */     this(LexicalError(EOFSeen, lexState, errorLine, errorColumn, errorAfter, curChar), reason);
/*  83:    */   }
/*  84:    */ }


/* Location:           E:\workspace\java\db\lib\jsqlparser.jar
 * Qualified Name:     net.sf.jsqlparser.parser.TokenMgrError
 * JD-Core Version:    0.7.0.1
 */