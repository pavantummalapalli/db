/*   1:    */ package net.sf.jsqlparser.parser;
/*   2:    */ 
/*   3:    */ import java.io.Serializable;
/*   4:    */ 
/*   5:    */ public class Token
/*   6:    */   implements Serializable
/*   7:    */ {
/*   8:    */   private static final long serialVersionUID = 1L;
/*   9:    */   public int kind;
/*  10:    */   public int beginLine;
/*  11:    */   public int beginColumn;
/*  12:    */   public int endLine;
/*  13:    */   public int endColumn;
/*  14:    */   public String image;
/*  15:    */   public Token next;
/*  16:    */   public Token specialToken;
/*  17:    */   
/*  18:    */   public Object getValue()
/*  19:    */   {
/*  20: 95 */     return null;
/*  21:    */   }
/*  22:    */   
/*  23:    */   public Token() {}
/*  24:    */   
/*  25:    */   public Token(int kind)
/*  26:    */   {
/*  27:108 */     this(kind, null);
/*  28:    */   }
/*  29:    */   
/*  30:    */   public Token(int kind, String image)
/*  31:    */   {
/*  32:116 */     this.kind = kind;
/*  33:117 */     this.image = image;
/*  34:    */   }
/*  35:    */   
/*  36:    */   public String toString()
/*  37:    */   {
/*  38:125 */     return this.image;
/*  39:    */   }
/*  40:    */   
/*  41:    */   public static Token newToken(int ofKind, String image)
/*  42:    */   {
/*  43:142 */     switch (ofKind)
/*  44:    */     {
/*  45:    */     }
/*  46:144 */     return new Token(ofKind, image);
/*  47:    */   }
/*  48:    */   
/*  49:    */   public static Token newToken(int ofKind)
/*  50:    */   {
/*  51:150 */     return newToken(ofKind, null);
/*  52:    */   }
/*  53:    */ }


/* Location:           E:\workspace\java\db\lib\jsqlparser.jar
 * Qualified Name:     net.sf.jsqlparser.parser.Token
 * JD-Core Version:    0.7.0.1
 */