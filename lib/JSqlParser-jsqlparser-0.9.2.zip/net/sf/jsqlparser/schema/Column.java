/*  1:   */ package net.sf.jsqlparser.schema;
/*  2:   */ 
/*  3:   */ import net.sf.jsqlparser.expression.Expression;
/*  4:   */ import net.sf.jsqlparser.expression.ExpressionVisitor;
/*  5:   */ 
/*  6:   */ public class Column
/*  7:   */   implements Expression
/*  8:   */ {
/*  9:33 */   private String columnName = "";
/* 10:   */   private Table table;
/* 11:   */   
/* 12:   */   public Column() {}
/* 13:   */   
/* 14:   */   public Column(Table table, String columnName)
/* 15:   */   {
/* 16:40 */     this.table = table;
/* 17:41 */     this.columnName = columnName;
/* 18:   */   }
/* 19:   */   
/* 20:   */   public String getColumnName()
/* 21:   */   {
/* 22:45 */     return this.columnName;
/* 23:   */   }
/* 24:   */   
/* 25:   */   public Table getTable()
/* 26:   */   {
/* 27:49 */     return this.table;
/* 28:   */   }
/* 29:   */   
/* 30:   */   public void setColumnName(String string)
/* 31:   */   {
/* 32:53 */     this.columnName = string;
/* 33:   */   }
/* 34:   */   
/* 35:   */   public void setTable(Table table)
/* 36:   */   {
/* 37:57 */     this.table = table;
/* 38:   */   }
/* 39:   */   
/* 40:   */   public String getWholeColumnName()
/* 41:   */   {
/* 42:65 */     String columnWholeName = null;
/* 43:66 */     String tableWholeName = this.table.getWholeTableName();
/* 44:68 */     if ((tableWholeName != null) && (tableWholeName.length() != 0)) {
/* 45:69 */       columnWholeName = tableWholeName + "." + this.columnName;
/* 46:   */     } else {
/* 47:71 */       columnWholeName = this.columnName;
/* 48:   */     }
/* 49:74 */     return columnWholeName;
/* 50:   */   }
/* 51:   */   
/* 52:   */   public void accept(ExpressionVisitor expressionVisitor)
/* 53:   */   {
/* 54:79 */     expressionVisitor.visit(this);
/* 55:   */   }
/* 56:   */   
/* 57:   */   public String toString()
/* 58:   */   {
/* 59:83 */     return getWholeColumnName();
/* 60:   */   }
/* 61:   */ }


/* Location:           E:\workspace\java\db\lib\jsqlparser.jar
 * Qualified Name:     net.sf.jsqlparser.schema.Column
 * JD-Core Version:    0.7.0.1
 */