/*  1:   */ package net.sf.jsqlparser.schema;
/*  2:   */ 
/*  3:   */ import net.sf.jsqlparser.statement.select.FromItem;
/*  4:   */ import net.sf.jsqlparser.statement.select.FromItemVisitor;
/*  5:   */ import net.sf.jsqlparser.statement.select.IntoTableVisitor;
/*  6:   */ 
/*  7:   */ public class Table
/*  8:   */   implements FromItem
/*  9:   */ {
/* 10:   */   private String schemaName;
/* 11:   */   private String name;
/* 12:   */   private String alias;
/* 13:   */   
/* 14:   */   public Table() {}
/* 15:   */   
/* 16:   */   public Table(String schemaName, String name)
/* 17:   */   {
/* 18:42 */     this.schemaName = schemaName;
/* 19:43 */     this.name = name;
/* 20:   */   }
/* 21:   */   
/* 22:   */   public String getName()
/* 23:   */   {
/* 24:47 */     return this.name;
/* 25:   */   }
/* 26:   */   
/* 27:   */   public String getSchemaName()
/* 28:   */   {
/* 29:51 */     return this.schemaName;
/* 30:   */   }
/* 31:   */   
/* 32:   */   public void setName(String string)
/* 33:   */   {
/* 34:55 */     this.name = string;
/* 35:   */   }
/* 36:   */   
/* 37:   */   public void setSchemaName(String string)
/* 38:   */   {
/* 39:59 */     this.schemaName = string;
/* 40:   */   }
/* 41:   */   
/* 42:   */   public String getAlias()
/* 43:   */   {
/* 44:63 */     return this.alias;
/* 45:   */   }
/* 46:   */   
/* 47:   */   public void setAlias(String string)
/* 48:   */   {
/* 49:67 */     this.alias = string;
/* 50:   */   }
/* 51:   */   
/* 52:   */   public String getWholeTableName()
/* 53:   */   {
/* 54:72 */     String tableWholeName = null;
/* 55:73 */     if (this.name == null) {
/* 56:74 */       return null;
/* 57:   */     }
/* 58:76 */     if (this.schemaName != null) {
/* 59:77 */       tableWholeName = this.schemaName + "." + this.name;
/* 60:   */     } else {
/* 61:79 */       tableWholeName = this.name;
/* 62:   */     }
/* 63:82 */     return tableWholeName;
/* 64:   */   }
/* 65:   */   
/* 66:   */   public void accept(FromItemVisitor fromItemVisitor)
/* 67:   */   {
/* 68:87 */     fromItemVisitor.visit(this);
/* 69:   */   }
/* 70:   */   
/* 71:   */   public void accept(IntoTableVisitor intoTableVisitor)
/* 72:   */   {
/* 73:91 */     intoTableVisitor.visit(this);
/* 74:   */   }
/* 75:   */   
/* 76:   */   public String toString()
/* 77:   */   {
/* 78:96 */     return getWholeTableName() + (this.alias != null ? " AS " + this.alias : "");
/* 79:   */   }
/* 80:   */ }


/* Location:           E:\workspace\java\db\lib\jsqlparser.jar
 * Qualified Name:     net.sf.jsqlparser.schema.Table
 * JD-Core Version:    0.7.0.1
 */