/*  1:   */ 
/*  2:   */ 
/*  3:   */ java.io.PrintStream
/*  4:   */ java.io.PrintWriter
/*  5:   */ 
/*  6:   */ JSQLParserException
/*  7:   */   
/*  8:   */ 
/*  9:30 */   cause = 
/* 10:   */   
/* 11:   */   JSQLParserException {}
/* 12:   */   
/* 13:   */   JSQLParserException
/* 14:   */   
/* 15:37 */     
/* 16:   */   
/* 17:   */   
/* 18:   */   JSQLParserException
/* 19:   */   
/* 20:41 */     cause = arg0;
/* 21:   */   }
/* 22:   */   
/* 23:   */   public JSQLParserException(String arg0, Throwable arg1)
/* 24:   */   {
/* 25:45 */     super(arg0);
/* 26:46 */     this.cause = arg1;
/* 27:   */   }
/* 28:   */   
/* 29:   */   public Throwable getCause()
/* 30:   */   {
/* 31:50 */     return this.cause;
/* 32:   */   }
/* 33:   */   
/* 34:   */   public void printStackTrace()
/* 35:   */   {
/* 36:54 */     printStackTrace(System.err);
/* 37:   */   }
/* 38:   */   
/* 39:   */   public void printStackTrace(PrintWriter pw)
/* 40:   */   {
/* 41:58 */     super.printStackTrace(pw);
/* 42:59 */     if (this.cause != null)
/* 43:   */     {
/* 44:60 */       pw.println("Caused by:");
/* 45:61 */       this.cause.printStackTrace(pw);
/* 46:   */     }
/* 47:   */   }
/* 48:   */   
/* 49:   */   public void printStackTrace(PrintStream ps)
/* 50:   */   {
/* 51:66 */     super.printStackTrace(ps);
/* 52:67 */     if (this.cause != null)
/* 53:   */     {
/* 54:68 */       ps.println("Caused by:");
/* 55:69 */       this.cause.printStackTrace(ps);
/* 56:   */     }
/* 57:   */   }
/* 58:   */ }


/* Location:           E:\workspace\java\db\lib\jsqlparser.jar
 * Qualified Name:     net.sf.jsqlparser.JSQLParserException
 * JD-Core Version:    0.7.0.1
 */