select lnnvl( 2 > 1) from dual
