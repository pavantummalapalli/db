select * from sys.dual natural join sys.dual 

