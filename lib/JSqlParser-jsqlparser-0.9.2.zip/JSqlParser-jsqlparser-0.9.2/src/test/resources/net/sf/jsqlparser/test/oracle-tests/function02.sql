select set(x) from dual
