select * from (dual),  (dual d), (dual) d
