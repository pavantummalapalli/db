update table_name
set row = array_of_records(i)
where 1=1
      