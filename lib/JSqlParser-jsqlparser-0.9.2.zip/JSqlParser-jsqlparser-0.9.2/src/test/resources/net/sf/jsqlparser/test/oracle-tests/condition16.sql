select * from persons p
       where value(p) is of type(only employee_t)
       