update tab1
set c1 = 'x'
where current of c_cur1

