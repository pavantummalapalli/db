select * from dual where trim(sxhnode_key) is not null

