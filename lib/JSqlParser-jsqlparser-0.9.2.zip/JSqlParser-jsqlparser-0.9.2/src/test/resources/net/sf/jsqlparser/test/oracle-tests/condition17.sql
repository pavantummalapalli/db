delete from table_name
where current of cursor_name
