select a.* from dual
